var Ul = Object.defineProperty;
var un = (r) => {
  throw TypeError(r);
};
var Gl = (r, e, t) => e in r ? Ul(r, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : r[e] = t;
var _e = (r, e, t) => Gl(r, typeof e != "symbol" ? e + "" : e, t), Vl = (r, e, t) => e.has(r) || un("Cannot " + t);
var on = (r, e, t) => e.has(r) ? un("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(r) : e.set(r, t);
var mr = (r, e, t) => (Vl(r, e, "access private method"), t);
const {
  SvelteComponent: Wl,
  assign: Yl,
  children: jl,
  claim_element: Xl,
  create_slot: Zl,
  detach: cn,
  element: Kl,
  get_all_dirty_from_scope: Ql,
  get_slot_changes: Jl,
  get_spread_update: $l,
  init: es,
  insert_hydration: ts,
  safe_not_equal: rs,
  set_dynamic_element_data: hn,
  set_style: Ye,
  toggle_class: w0,
  transition_in: Mi,
  transition_out: Bi,
  update_slot_base: as
} = window.__gradio__svelte__internal;
function ns(r) {
  let e, t, a;
  const n = (
    /*#slots*/
    r[22].default
  ), i = Zl(
    n,
    r,
    /*$$scope*/
    r[21],
    null
  );
  let l = [
    { "data-testid": (
      /*test_id*/
      r[10]
    ) },
    { id: (
      /*elem_id*/
      r[5]
    ) },
    {
      class: t = "block " + /*elem_classes*/
      r[6].join(" ") + " svelte-1ezsyiy"
    }
  ], s = {};
  for (let o = 0; o < l.length; o += 1)
    s = Yl(s, l[o]);
  return {
    c() {
      e = Kl(
        /*tag*/
        r[18]
      ), i && i.c(), this.h();
    },
    l(o) {
      e = Xl(
        o,
        /*tag*/
        (r[18] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0
        }
      );
      var m = jl(e);
      i && i.l(m), m.forEach(cn), this.h();
    },
    h() {
      hn(
        /*tag*/
        r[18]
      )(e, s), w0(
        e,
        "hidden",
        /*visible*/
        r[13] === !1
      ), w0(
        e,
        "padded",
        /*padding*/
        r[9]
      ), w0(
        e,
        "flex",
        /*flex*/
        r[0]
      ), w0(
        e,
        "border_focus",
        /*border_mode*/
        r[8] === "focus"
      ), w0(
        e,
        "border_contrast",
        /*border_mode*/
        r[8] === "contrast"
      ), w0(e, "hide-container", !/*explicit_call*/
      r[11] && !/*container*/
      r[12]), Ye(
        e,
        "height",
        /*get_dimension*/
        r[19](
          /*height*/
          r[1]
        )
      ), Ye(
        e,
        "min-height",
        /*get_dimension*/
        r[19](
          /*min_height*/
          r[2]
        )
      ), Ye(
        e,
        "max-height",
        /*get_dimension*/
        r[19](
          /*max_height*/
          r[3]
        )
      ), Ye(e, "width", typeof /*width*/
      r[4] == "number" ? `calc(min(${/*width*/
      r[4]}px, 100%))` : (
        /*get_dimension*/
        r[19](
          /*width*/
          r[4]
        )
      )), Ye(
        e,
        "border-style",
        /*variant*/
        r[7]
      ), Ye(
        e,
        "overflow",
        /*allow_overflow*/
        r[14] ? (
          /*overflow_behavior*/
          r[15]
        ) : "hidden"
      ), Ye(
        e,
        "flex-grow",
        /*scale*/
        r[16]
      ), Ye(e, "min-width", `calc(min(${/*min_width*/
      r[17]}px, 100%))`), Ye(e, "border-width", "var(--block-border-width)");
    },
    m(o, m) {
      ts(o, e, m), i && i.m(e, null), a = !0;
    },
    p(o, m) {
      i && i.p && (!a || m & /*$$scope*/
      2097152) && as(
        i,
        n,
        o,
        /*$$scope*/
        o[21],
        a ? Jl(
          n,
          /*$$scope*/
          o[21],
          m,
          null
        ) : Ql(
          /*$$scope*/
          o[21]
        ),
        null
      ), hn(
        /*tag*/
        o[18]
      )(e, s = $l(l, [
        (!a || m & /*test_id*/
        1024) && { "data-testid": (
          /*test_id*/
          o[10]
        ) },
        (!a || m & /*elem_id*/
        32) && { id: (
          /*elem_id*/
          o[5]
        ) },
        (!a || m & /*elem_classes*/
        64 && t !== (t = "block " + /*elem_classes*/
        o[6].join(" ") + " svelte-1ezsyiy")) && { class: t }
      ])), w0(
        e,
        "hidden",
        /*visible*/
        o[13] === !1
      ), w0(
        e,
        "padded",
        /*padding*/
        o[9]
      ), w0(
        e,
        "flex",
        /*flex*/
        o[0]
      ), w0(
        e,
        "border_focus",
        /*border_mode*/
        o[8] === "focus"
      ), w0(
        e,
        "border_contrast",
        /*border_mode*/
        o[8] === "contrast"
      ), w0(e, "hide-container", !/*explicit_call*/
      o[11] && !/*container*/
      o[12]), m & /*height*/
      2 && Ye(
        e,
        "height",
        /*get_dimension*/
        o[19](
          /*height*/
          o[1]
        )
      ), m & /*min_height*/
      4 && Ye(
        e,
        "min-height",
        /*get_dimension*/
        o[19](
          /*min_height*/
          o[2]
        )
      ), m & /*max_height*/
      8 && Ye(
        e,
        "max-height",
        /*get_dimension*/
        o[19](
          /*max_height*/
          o[3]
        )
      ), m & /*width*/
      16 && Ye(e, "width", typeof /*width*/
      o[4] == "number" ? `calc(min(${/*width*/
      o[4]}px, 100%))` : (
        /*get_dimension*/
        o[19](
          /*width*/
          o[4]
        )
      )), m & /*variant*/
      128 && Ye(
        e,
        "border-style",
        /*variant*/
        o[7]
      ), m & /*allow_overflow, overflow_behavior*/
      49152 && Ye(
        e,
        "overflow",
        /*allow_overflow*/
        o[14] ? (
          /*overflow_behavior*/
          o[15]
        ) : "hidden"
      ), m & /*scale*/
      65536 && Ye(
        e,
        "flex-grow",
        /*scale*/
        o[16]
      ), m & /*min_width*/
      131072 && Ye(e, "min-width", `calc(min(${/*min_width*/
      o[17]}px, 100%))`);
    },
    i(o) {
      a || (Mi(i, o), a = !0);
    },
    o(o) {
      Bi(i, o), a = !1;
    },
    d(o) {
      o && cn(e), i && i.d(o);
    }
  };
}
function is(r) {
  let e, t = (
    /*tag*/
    r[18] && ns(r)
  );
  return {
    c() {
      t && t.c();
    },
    l(a) {
      t && t.l(a);
    },
    m(a, n) {
      t && t.m(a, n), e = !0;
    },
    p(a, [n]) {
      /*tag*/
      a[18] && t.p(a, n);
    },
    i(a) {
      e || (Mi(t, a), e = !0);
    },
    o(a) {
      Bi(t, a), e = !1;
    },
    d(a) {
      t && t.d(a);
    }
  };
}
function ls(r, e, t) {
  let { $$slots: a = {}, $$scope: n } = e, { height: i = void 0 } = e, { min_height: l = void 0 } = e, { max_height: s = void 0 } = e, { width: o = void 0 } = e, { elem_id: m = "" } = e, { elem_classes: f = [] } = e, { variant: p = "solid" } = e, { border_mode: g = "base" } = e, { padding: w = !0 } = e, { type: F = "normal" } = e, { test_id: E = void 0 } = e, { explicit_call: k = !1 } = e, { container: S = !0 } = e, { visible: y = !0 } = e, { allow_overflow: D = !0 } = e, { overflow_behavior: _ = "auto" } = e, { scale: C = null } = e, { min_width: M = 0 } = e, { flex: R = !1 } = e;
  y || (R = !1);
  let U = F === "fieldset" ? "fieldset" : "div";
  const I = (O) => {
    if (O !== void 0) {
      if (typeof O == "number")
        return O + "px";
      if (typeof O == "string")
        return O;
    }
  };
  return r.$$set = (O) => {
    "height" in O && t(1, i = O.height), "min_height" in O && t(2, l = O.min_height), "max_height" in O && t(3, s = O.max_height), "width" in O && t(4, o = O.width), "elem_id" in O && t(5, m = O.elem_id), "elem_classes" in O && t(6, f = O.elem_classes), "variant" in O && t(7, p = O.variant), "border_mode" in O && t(8, g = O.border_mode), "padding" in O && t(9, w = O.padding), "type" in O && t(20, F = O.type), "test_id" in O && t(10, E = O.test_id), "explicit_call" in O && t(11, k = O.explicit_call), "container" in O && t(12, S = O.container), "visible" in O && t(13, y = O.visible), "allow_overflow" in O && t(14, D = O.allow_overflow), "overflow_behavior" in O && t(15, _ = O.overflow_behavior), "scale" in O && t(16, C = O.scale), "min_width" in O && t(17, M = O.min_width), "flex" in O && t(0, R = O.flex), "$$scope" in O && t(21, n = O.$$scope);
  }, [
    R,
    i,
    l,
    s,
    o,
    m,
    f,
    p,
    g,
    w,
    E,
    k,
    S,
    y,
    D,
    _,
    C,
    M,
    U,
    I,
    F,
    n,
    a
  ];
}
class ss extends Wl {
  constructor(e) {
    super(), es(this, e, ls, is, rs, {
      height: 1,
      min_height: 2,
      max_height: 3,
      width: 4,
      elem_id: 5,
      elem_classes: 6,
      variant: 7,
      border_mode: 8,
      padding: 9,
      type: 20,
      test_id: 10,
      explicit_call: 11,
      container: 12,
      visible: 13,
      allow_overflow: 14,
      overflow_behavior: 15,
      scale: 16,
      min_width: 17,
      flex: 0
    });
  }
}
class xa {
  // The + prefix indicates that these fields aren't writeable
  // Lexer holding the input string.
  // Start offset, zero-based inclusive.
  // End offset, zero-based exclusive.
  constructor(e, t, a) {
    this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = a;
  }
  /**
   * Merges two `SourceLocation`s from location providers, given they are
   * provided in order of appearance.
   * - Returns the first one's location if only the first is provided.
   * - Returns a merged range of the first and the last if both are provided
   *   and their lexers match.
   * - Otherwise, returns null.
   */
  static range(e, t) {
    return t ? !e || !e.loc || !t.loc || e.loc.lexer !== t.loc.lexer ? null : new xa(e.loc.lexer, e.loc.start, t.loc.end) : e && e.loc;
  }
}
class Aa {
  // don't expand the token
  // used in \noexpand
  constructor(e, t) {
    this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
  }
  /**
   * Given a pair of tokens (this and endToken), compute a `Token` encompassing
   * the whole input range enclosed by these two.
   */
  range(e, t) {
    return new Aa(t, xa.range(this, e));
  }
}
class W {
  // Error start position based on passed-in Token or ParseNode.
  // Length of affected text based on passed-in Token or ParseNode.
  // The underlying error message without any context added.
  constructor(e, t) {
    this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
    var a = "KaTeX parse error: " + e, n, i, l = t && t.loc;
    if (l && l.start <= l.end) {
      var s = l.lexer.input;
      n = l.start, i = l.end, n === s.length ? a += " at end of input: " : a += " at position " + (n + 1) + ": ";
      var o = s.slice(n, i).replace(/[^]/g, "$&̲"), m;
      n > 15 ? m = "…" + s.slice(n - 15, n) : m = s.slice(0, n);
      var f;
      i + 15 < s.length ? f = s.slice(i, i + 15) + "…" : f = s.slice(i), a += m + o + f;
    }
    var p = new Error(a);
    return p.name = "ParseError", p.__proto__ = W.prototype, p.position = n, n != null && i != null && (p.length = i - n), p.rawMessage = e, p;
  }
}
W.prototype.__proto__ = Error.prototype;
var us = function(e, t) {
  return e.indexOf(t) !== -1;
}, os = function(e, t) {
  return e === void 0 ? t : e;
}, cs = /([A-Z])/g, hs = function(e) {
  return e.replace(cs, "-$1").toLowerCase();
}, ms = {
  "&": "&amp;",
  ">": "&gt;",
  "<": "&lt;",
  '"': "&quot;",
  "'": "&#x27;"
}, fs = /[&><"']/g;
function ds(r) {
  return String(r).replace(fs, (e) => ms[e]);
}
var zi = function r(e) {
  return e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? r(e.body[0]) : e : e.type === "font" ? r(e.body) : e;
}, ps = function(e) {
  var t = zi(e);
  return t.type === "mathord" || t.type === "textord" || t.type === "atom";
}, gs = function(e) {
  if (!e)
    throw new Error("Expected non-null, but got " + String(e));
  return e;
}, vs = function(e) {
  var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
  return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
}, j = {
  contains: us,
  deflt: os,
  escape: ds,
  hyphenate: hs,
  getBaseElem: zi,
  isCharacterBox: ps,
  protocolFromUrl: vs
};
class tt {
  constructor(e, t, a) {
    this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = a;
  }
  /**
   * Get the style of a superscript given a base in the current style.
   */
  sup() {
    return I0[bs[this.id]];
  }
  /**
   * Get the style of a subscript given a base in the current style.
   */
  sub() {
    return I0[ys[this.id]];
  }
  /**
   * Get the style of a fraction numerator given the fraction in the current
   * style.
   */
  fracNum() {
    return I0[ws[this.id]];
  }
  /**
   * Get the style of a fraction denominator given the fraction in the current
   * style.
   */
  fracDen() {
    return I0[ks[this.id]];
  }
  /**
   * Get the cramped version of a style (in particular, cramping a cramped style
   * doesn't change the style).
   */
  cramp() {
    return I0[Ds[this.id]];
  }
  /**
   * Get a text or display version of this style.
   */
  text() {
    return I0[xs[this.id]];
  }
  /**
   * Return true if this style is tightly spaced (scriptstyle/scriptscriptstyle)
   */
  isTight() {
    return this.size >= 2;
  }
}
var Sa = 0, _r = 1, Bt = 2, X0 = 3, er = 4, k0 = 5, zt = 6, e0 = 7, I0 = [new tt(Sa, 0, !1), new tt(_r, 0, !0), new tt(Bt, 1, !1), new tt(X0, 1, !0), new tt(er, 2, !1), new tt(k0, 2, !0), new tt(zt, 3, !1), new tt(e0, 3, !0)], bs = [er, k0, er, k0, zt, e0, zt, e0], ys = [k0, k0, k0, k0, e0, e0, e0, e0], ws = [Bt, X0, er, k0, zt, e0, zt, e0], ks = [X0, X0, k0, k0, e0, e0, e0, e0], Ds = [_r, _r, X0, X0, k0, k0, e0, e0], xs = [Sa, _r, Bt, X0, Bt, X0, Bt, X0], Z = {
  DISPLAY: I0[Sa],
  TEXT: I0[Bt],
  SCRIPT: I0[er],
  SCRIPTSCRIPT: I0[zt]
}, da = [{
  // Latin characters beyond the Latin-1 characters we have metrics for.
  // Needed for Czech, Hungarian and Turkish text, for example.
  name: "latin",
  blocks: [
    [256, 591],
    // Latin Extended-A and Latin Extended-B
    [768, 879]
    // Combining Diacritical marks
  ]
}, {
  // The Cyrillic script used by Russian and related languages.
  // A Cyrillic subset used to be supported as explicitly defined
  // symbols in symbols.js
  name: "cyrillic",
  blocks: [[1024, 1279]]
}, {
  // Armenian
  name: "armenian",
  blocks: [[1328, 1423]]
}, {
  // The Brahmic scripts of South and Southeast Asia
  // Devanagari (0900–097F)
  // Bengali (0980–09FF)
  // Gurmukhi (0A00–0A7F)
  // Gujarati (0A80–0AFF)
  // Oriya (0B00–0B7F)
  // Tamil (0B80–0BFF)
  // Telugu (0C00–0C7F)
  // Kannada (0C80–0CFF)
  // Malayalam (0D00–0D7F)
  // Sinhala (0D80–0DFF)
  // Thai (0E00–0E7F)
  // Lao (0E80–0EFF)
  // Tibetan (0F00–0FFF)
  // Myanmar (1000–109F)
  name: "brahmic",
  blocks: [[2304, 4255]]
}, {
  name: "georgian",
  blocks: [[4256, 4351]]
}, {
  // Chinese and Japanese.
  // The "k" in cjk is for Korean, but we've separated Korean out
  name: "cjk",
  blocks: [
    [12288, 12543],
    // CJK symbols and punctuation, Hiragana, Katakana
    [19968, 40879],
    // CJK ideograms
    [65280, 65376]
    // Fullwidth punctuation
    // TODO: add halfwidth Katakana and Romanji glyphs
  ]
}, {
  // Korean
  name: "hangul",
  blocks: [[44032, 55215]]
}];
function As(r) {
  for (var e = 0; e < da.length; e++)
    for (var t = da[e], a = 0; a < t.blocks.length; a++) {
      var n = t.blocks[a];
      if (r >= n[0] && r <= n[1])
        return t.name;
    }
  return null;
}
var Sr = [];
da.forEach((r) => r.blocks.forEach((e) => Sr.push(...e)));
function Ss(r) {
  for (var e = 0; e < Sr.length; e += 2)
    if (r >= Sr[e] && r <= Sr[e + 1])
      return !0;
  return !1;
}
var Tt = 80, Fs = function(e, t) {
  return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, _s = function(e, t) {
  return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, Es = function(e, t) {
  return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, Ts = function(e, t) {
  return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
}, Cs = function(e, t) {
  return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, Ms = function(e) {
  var t = e / 2;
  return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, Bs = function(e, t, a) {
  var n = a - 54 - t - e;
  return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + n + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
}, zs = function(e, t, a) {
  t = 1e3 * t;
  var n = "";
  switch (e) {
    case "sqrtMain":
      n = Fs(t, Tt);
      break;
    case "sqrtSize1":
      n = _s(t, Tt);
      break;
    case "sqrtSize2":
      n = Es(t, Tt);
      break;
    case "sqrtSize3":
      n = Ts(t, Tt);
      break;
    case "sqrtSize4":
      n = Cs(t, Tt);
      break;
    case "sqrtTall":
      n = Bs(t, Tt, a);
  }
  return n;
}, Rs = function(e, t) {
  switch (e) {
    case "⎜":
      return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
    case "∣":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
    case "∥":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
    case "⎟":
      return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
    case "⎢":
      return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
    case "⎥":
      return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
    case "⎪":
      return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
    case "⏐":
      return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
    case "‖":
      return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
    default:
      return "";
  }
}, mn = {
  // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
  doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
  // doublerightarrow is from glyph U+21D2 in font KaTeX Main
  doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
  // leftarrow is from glyph U+2190 in font KaTeX Main
  leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
  // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
  leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
  leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
  // overgroup is from the MnSymbol package (public domain)
  leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
  leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
  // Harpoons are from glyph U+21BD in font KaTeX Main
  leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
  leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
  leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
  leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
  // hook is from glyph U+21A9 in font KaTeX Main
  lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
  leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
  leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
  // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
  leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
  longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
  midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
  midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
  oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
  oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
  oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
  oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
  rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
  rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
  rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
  rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
  rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
  rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
  rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
  rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
  rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
  righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
  rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
  rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
  // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
  twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
  twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
  // tilde1 is a modified version of a glyph from the MnSymbol package
  tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
  // ditto tilde2, tilde3, & tilde4
  tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
  tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
  tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
  // vec is from glyph U+20D7 in font KaTeX Main
  vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
  // widehat1 is a modified version of a glyph from the MnSymbol package
  widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
  // ditto widehat2, widehat3, & widehat4
  widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  // widecheck paths are all inverted versions of widehat
  widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
  widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  // The next ten paths support reaction arrows from the mhchem package.
  // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
  // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
  baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
  // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
  rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
  // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
  // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
  baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
  rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
  shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
  shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
}, Ns = function(e, t) {
  switch (e) {
    case "lbrack":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 h84z";
    case "rbrack":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
    case "vert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
    case "doublevert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
    case "lfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "rfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "lceil":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
    case "rceil":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
    case "lparen":
      return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
    case "rparen":
      return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
    default:
      throw new Error("Unknown stretchy delimiter.");
  }
};
class rr {
  // HtmlDomNode
  // Never used; needed for satisfying interface.
  constructor(e) {
    this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
  }
  hasClass(e) {
    return j.contains(this.classes, e);
  }
  /** Convert the fragment into a node. */
  toNode() {
    for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++)
      e.appendChild(this.children[t].toNode());
    return e;
  }
  /** Convert the fragment into HTML markup. */
  toMarkup() {
    for (var e = "", t = 0; t < this.children.length; t++)
      e += this.children[t].toMarkup();
    return e;
  }
  /**
   * Converts the math node into a string, similar to innerText. Applies to
   * MathDomNode's only.
   */
  toText() {
    var e = (t) => t.toText();
    return this.children.map(e).join("");
  }
}
var j0 = {
  "AMS-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68889, 0, 0, 0.72222],
    66: [0, 0.68889, 0, 0, 0.66667],
    67: [0, 0.68889, 0, 0, 0.72222],
    68: [0, 0.68889, 0, 0, 0.72222],
    69: [0, 0.68889, 0, 0, 0.66667],
    70: [0, 0.68889, 0, 0, 0.61111],
    71: [0, 0.68889, 0, 0, 0.77778],
    72: [0, 0.68889, 0, 0, 0.77778],
    73: [0, 0.68889, 0, 0, 0.38889],
    74: [0.16667, 0.68889, 0, 0, 0.5],
    75: [0, 0.68889, 0, 0, 0.77778],
    76: [0, 0.68889, 0, 0, 0.66667],
    77: [0, 0.68889, 0, 0, 0.94445],
    78: [0, 0.68889, 0, 0, 0.72222],
    79: [0.16667, 0.68889, 0, 0, 0.77778],
    80: [0, 0.68889, 0, 0, 0.61111],
    81: [0.16667, 0.68889, 0, 0, 0.77778],
    82: [0, 0.68889, 0, 0, 0.72222],
    83: [0, 0.68889, 0, 0, 0.55556],
    84: [0, 0.68889, 0, 0, 0.66667],
    85: [0, 0.68889, 0, 0, 0.72222],
    86: [0, 0.68889, 0, 0, 0.72222],
    87: [0, 0.68889, 0, 0, 1],
    88: [0, 0.68889, 0, 0, 0.72222],
    89: [0, 0.68889, 0, 0, 0.72222],
    90: [0, 0.68889, 0, 0, 0.66667],
    107: [0, 0.68889, 0, 0, 0.55556],
    160: [0, 0, 0, 0, 0.25],
    165: [0, 0.675, 0.025, 0, 0.75],
    174: [0.15559, 0.69224, 0, 0, 0.94666],
    240: [0, 0.68889, 0, 0, 0.55556],
    295: [0, 0.68889, 0, 0, 0.54028],
    710: [0, 0.825, 0, 0, 2.33334],
    732: [0, 0.9, 0, 0, 2.33334],
    770: [0, 0.825, 0, 0, 2.33334],
    771: [0, 0.9, 0, 0, 2.33334],
    989: [0.08167, 0.58167, 0, 0, 0.77778],
    1008: [0, 0.43056, 0.04028, 0, 0.66667],
    8245: [0, 0.54986, 0, 0, 0.275],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8487: [0, 0.68889, 0, 0, 0.72222],
    8498: [0, 0.68889, 0, 0, 0.55556],
    8502: [0, 0.68889, 0, 0, 0.66667],
    8503: [0, 0.68889, 0, 0, 0.44445],
    8504: [0, 0.68889, 0, 0, 0.66667],
    8513: [0, 0.68889, 0, 0, 0.63889],
    8592: [-0.03598, 0.46402, 0, 0, 0.5],
    8594: [-0.03598, 0.46402, 0, 0, 0.5],
    8602: [-0.13313, 0.36687, 0, 0, 1],
    8603: [-0.13313, 0.36687, 0, 0, 1],
    8606: [0.01354, 0.52239, 0, 0, 1],
    8608: [0.01354, 0.52239, 0, 0, 1],
    8610: [0.01354, 0.52239, 0, 0, 1.11111],
    8611: [0.01354, 0.52239, 0, 0, 1.11111],
    8619: [0, 0.54986, 0, 0, 1],
    8620: [0, 0.54986, 0, 0, 1],
    8621: [-0.13313, 0.37788, 0, 0, 1.38889],
    8622: [-0.13313, 0.36687, 0, 0, 1],
    8624: [0, 0.69224, 0, 0, 0.5],
    8625: [0, 0.69224, 0, 0, 0.5],
    8630: [0, 0.43056, 0, 0, 1],
    8631: [0, 0.43056, 0, 0, 1],
    8634: [0.08198, 0.58198, 0, 0, 0.77778],
    8635: [0.08198, 0.58198, 0, 0, 0.77778],
    8638: [0.19444, 0.69224, 0, 0, 0.41667],
    8639: [0.19444, 0.69224, 0, 0, 0.41667],
    8642: [0.19444, 0.69224, 0, 0, 0.41667],
    8643: [0.19444, 0.69224, 0, 0, 0.41667],
    8644: [0.1808, 0.675, 0, 0, 1],
    8646: [0.1808, 0.675, 0, 0, 1],
    8647: [0.1808, 0.675, 0, 0, 1],
    8648: [0.19444, 0.69224, 0, 0, 0.83334],
    8649: [0.1808, 0.675, 0, 0, 1],
    8650: [0.19444, 0.69224, 0, 0, 0.83334],
    8651: [0.01354, 0.52239, 0, 0, 1],
    8652: [0.01354, 0.52239, 0, 0, 1],
    8653: [-0.13313, 0.36687, 0, 0, 1],
    8654: [-0.13313, 0.36687, 0, 0, 1],
    8655: [-0.13313, 0.36687, 0, 0, 1],
    8666: [0.13667, 0.63667, 0, 0, 1],
    8667: [0.13667, 0.63667, 0, 0, 1],
    8669: [-0.13313, 0.37788, 0, 0, 1],
    8672: [-0.064, 0.437, 0, 0, 1.334],
    8674: [-0.064, 0.437, 0, 0, 1.334],
    8705: [0, 0.825, 0, 0, 0.5],
    8708: [0, 0.68889, 0, 0, 0.55556],
    8709: [0.08167, 0.58167, 0, 0, 0.77778],
    8717: [0, 0.43056, 0, 0, 0.42917],
    8722: [-0.03598, 0.46402, 0, 0, 0.5],
    8724: [0.08198, 0.69224, 0, 0, 0.77778],
    8726: [0.08167, 0.58167, 0, 0, 0.77778],
    8733: [0, 0.69224, 0, 0, 0.77778],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8737: [0, 0.69224, 0, 0, 0.72222],
    8738: [0.03517, 0.52239, 0, 0, 0.72222],
    8739: [0.08167, 0.58167, 0, 0, 0.22222],
    8740: [0.25142, 0.74111, 0, 0, 0.27778],
    8741: [0.08167, 0.58167, 0, 0, 0.38889],
    8742: [0.25142, 0.74111, 0, 0, 0.5],
    8756: [0, 0.69224, 0, 0, 0.66667],
    8757: [0, 0.69224, 0, 0, 0.66667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8765: [-0.13313, 0.37788, 0, 0, 0.77778],
    8769: [-0.13313, 0.36687, 0, 0, 0.77778],
    8770: [-0.03625, 0.46375, 0, 0, 0.77778],
    8774: [0.30274, 0.79383, 0, 0, 0.77778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8778: [0.08167, 0.58167, 0, 0, 0.77778],
    8782: [0.06062, 0.54986, 0, 0, 0.77778],
    8783: [0.06062, 0.54986, 0, 0, 0.77778],
    8785: [0.08198, 0.58198, 0, 0, 0.77778],
    8786: [0.08198, 0.58198, 0, 0, 0.77778],
    8787: [0.08198, 0.58198, 0, 0, 0.77778],
    8790: [0, 0.69224, 0, 0, 0.77778],
    8791: [0.22958, 0.72958, 0, 0, 0.77778],
    8796: [0.08198, 0.91667, 0, 0, 0.77778],
    8806: [0.25583, 0.75583, 0, 0, 0.77778],
    8807: [0.25583, 0.75583, 0, 0, 0.77778],
    8808: [0.25142, 0.75726, 0, 0, 0.77778],
    8809: [0.25142, 0.75726, 0, 0, 0.77778],
    8812: [0.25583, 0.75583, 0, 0, 0.5],
    8814: [0.20576, 0.70576, 0, 0, 0.77778],
    8815: [0.20576, 0.70576, 0, 0, 0.77778],
    8816: [0.30274, 0.79383, 0, 0, 0.77778],
    8817: [0.30274, 0.79383, 0, 0, 0.77778],
    8818: [0.22958, 0.72958, 0, 0, 0.77778],
    8819: [0.22958, 0.72958, 0, 0, 0.77778],
    8822: [0.1808, 0.675, 0, 0, 0.77778],
    8823: [0.1808, 0.675, 0, 0, 0.77778],
    8828: [0.13667, 0.63667, 0, 0, 0.77778],
    8829: [0.13667, 0.63667, 0, 0, 0.77778],
    8830: [0.22958, 0.72958, 0, 0, 0.77778],
    8831: [0.22958, 0.72958, 0, 0, 0.77778],
    8832: [0.20576, 0.70576, 0, 0, 0.77778],
    8833: [0.20576, 0.70576, 0, 0, 0.77778],
    8840: [0.30274, 0.79383, 0, 0, 0.77778],
    8841: [0.30274, 0.79383, 0, 0, 0.77778],
    8842: [0.13597, 0.63597, 0, 0, 0.77778],
    8843: [0.13597, 0.63597, 0, 0, 0.77778],
    8847: [0.03517, 0.54986, 0, 0, 0.77778],
    8848: [0.03517, 0.54986, 0, 0, 0.77778],
    8858: [0.08198, 0.58198, 0, 0, 0.77778],
    8859: [0.08198, 0.58198, 0, 0, 0.77778],
    8861: [0.08198, 0.58198, 0, 0, 0.77778],
    8862: [0, 0.675, 0, 0, 0.77778],
    8863: [0, 0.675, 0, 0, 0.77778],
    8864: [0, 0.675, 0, 0, 0.77778],
    8865: [0, 0.675, 0, 0, 0.77778],
    8872: [0, 0.69224, 0, 0, 0.61111],
    8873: [0, 0.69224, 0, 0, 0.72222],
    8874: [0, 0.69224, 0, 0, 0.88889],
    8876: [0, 0.68889, 0, 0, 0.61111],
    8877: [0, 0.68889, 0, 0, 0.61111],
    8878: [0, 0.68889, 0, 0, 0.72222],
    8879: [0, 0.68889, 0, 0, 0.72222],
    8882: [0.03517, 0.54986, 0, 0, 0.77778],
    8883: [0.03517, 0.54986, 0, 0, 0.77778],
    8884: [0.13667, 0.63667, 0, 0, 0.77778],
    8885: [0.13667, 0.63667, 0, 0, 0.77778],
    8888: [0, 0.54986, 0, 0, 1.11111],
    8890: [0.19444, 0.43056, 0, 0, 0.55556],
    8891: [0.19444, 0.69224, 0, 0, 0.61111],
    8892: [0.19444, 0.69224, 0, 0, 0.61111],
    8901: [0, 0.54986, 0, 0, 0.27778],
    8903: [0.08167, 0.58167, 0, 0, 0.77778],
    8905: [0.08167, 0.58167, 0, 0, 0.77778],
    8906: [0.08167, 0.58167, 0, 0, 0.77778],
    8907: [0, 0.69224, 0, 0, 0.77778],
    8908: [0, 0.69224, 0, 0, 0.77778],
    8909: [-0.03598, 0.46402, 0, 0, 0.77778],
    8910: [0, 0.54986, 0, 0, 0.76042],
    8911: [0, 0.54986, 0, 0, 0.76042],
    8912: [0.03517, 0.54986, 0, 0, 0.77778],
    8913: [0.03517, 0.54986, 0, 0, 0.77778],
    8914: [0, 0.54986, 0, 0, 0.66667],
    8915: [0, 0.54986, 0, 0, 0.66667],
    8916: [0, 0.69224, 0, 0, 0.66667],
    8918: [0.0391, 0.5391, 0, 0, 0.77778],
    8919: [0.0391, 0.5391, 0, 0, 0.77778],
    8920: [0.03517, 0.54986, 0, 0, 1.33334],
    8921: [0.03517, 0.54986, 0, 0, 1.33334],
    8922: [0.38569, 0.88569, 0, 0, 0.77778],
    8923: [0.38569, 0.88569, 0, 0, 0.77778],
    8926: [0.13667, 0.63667, 0, 0, 0.77778],
    8927: [0.13667, 0.63667, 0, 0, 0.77778],
    8928: [0.30274, 0.79383, 0, 0, 0.77778],
    8929: [0.30274, 0.79383, 0, 0, 0.77778],
    8934: [0.23222, 0.74111, 0, 0, 0.77778],
    8935: [0.23222, 0.74111, 0, 0, 0.77778],
    8936: [0.23222, 0.74111, 0, 0, 0.77778],
    8937: [0.23222, 0.74111, 0, 0, 0.77778],
    8938: [0.20576, 0.70576, 0, 0, 0.77778],
    8939: [0.20576, 0.70576, 0, 0, 0.77778],
    8940: [0.30274, 0.79383, 0, 0, 0.77778],
    8941: [0.30274, 0.79383, 0, 0, 0.77778],
    8994: [0.19444, 0.69224, 0, 0, 0.77778],
    8995: [0.19444, 0.69224, 0, 0, 0.77778],
    9416: [0.15559, 0.69224, 0, 0, 0.90222],
    9484: [0, 0.69224, 0, 0, 0.5],
    9488: [0, 0.69224, 0, 0, 0.5],
    9492: [0, 0.37788, 0, 0, 0.5],
    9496: [0, 0.37788, 0, 0, 0.5],
    9585: [0.19444, 0.68889, 0, 0, 0.88889],
    9586: [0.19444, 0.74111, 0, 0, 0.88889],
    9632: [0, 0.675, 0, 0, 0.77778],
    9633: [0, 0.675, 0, 0, 0.77778],
    9650: [0, 0.54986, 0, 0, 0.72222],
    9651: [0, 0.54986, 0, 0, 0.72222],
    9654: [0.03517, 0.54986, 0, 0, 0.77778],
    9660: [0, 0.54986, 0, 0, 0.72222],
    9661: [0, 0.54986, 0, 0, 0.72222],
    9664: [0.03517, 0.54986, 0, 0, 0.77778],
    9674: [0.11111, 0.69224, 0, 0, 0.66667],
    9733: [0.19444, 0.69224, 0, 0, 0.94445],
    10003: [0, 0.69224, 0, 0, 0.83334],
    10016: [0, 0.69224, 0, 0, 0.83334],
    10731: [0.11111, 0.69224, 0, 0, 0.66667],
    10846: [0.19444, 0.75583, 0, 0, 0.61111],
    10877: [0.13667, 0.63667, 0, 0, 0.77778],
    10878: [0.13667, 0.63667, 0, 0, 0.77778],
    10885: [0.25583, 0.75583, 0, 0, 0.77778],
    10886: [0.25583, 0.75583, 0, 0, 0.77778],
    10887: [0.13597, 0.63597, 0, 0, 0.77778],
    10888: [0.13597, 0.63597, 0, 0, 0.77778],
    10889: [0.26167, 0.75726, 0, 0, 0.77778],
    10890: [0.26167, 0.75726, 0, 0, 0.77778],
    10891: [0.48256, 0.98256, 0, 0, 0.77778],
    10892: [0.48256, 0.98256, 0, 0, 0.77778],
    10901: [0.13667, 0.63667, 0, 0, 0.77778],
    10902: [0.13667, 0.63667, 0, 0, 0.77778],
    10933: [0.25142, 0.75726, 0, 0, 0.77778],
    10934: [0.25142, 0.75726, 0, 0, 0.77778],
    10935: [0.26167, 0.75726, 0, 0, 0.77778],
    10936: [0.26167, 0.75726, 0, 0, 0.77778],
    10937: [0.26167, 0.75726, 0, 0, 0.77778],
    10938: [0.26167, 0.75726, 0, 0, 0.77778],
    10949: [0.25583, 0.75583, 0, 0, 0.77778],
    10950: [0.25583, 0.75583, 0, 0, 0.77778],
    10955: [0.28481, 0.79383, 0, 0, 0.77778],
    10956: [0.28481, 0.79383, 0, 0, 0.77778],
    57350: [0.08167, 0.58167, 0, 0, 0.22222],
    57351: [0.08167, 0.58167, 0, 0, 0.38889],
    57352: [0.08167, 0.58167, 0, 0, 0.77778],
    57353: [0, 0.43056, 0.04028, 0, 0.66667],
    57356: [0.25142, 0.75726, 0, 0, 0.77778],
    57357: [0.25142, 0.75726, 0, 0, 0.77778],
    57358: [0.41951, 0.91951, 0, 0, 0.77778],
    57359: [0.30274, 0.79383, 0, 0, 0.77778],
    57360: [0.30274, 0.79383, 0, 0, 0.77778],
    57361: [0.41951, 0.91951, 0, 0, 0.77778],
    57366: [0.25142, 0.75726, 0, 0, 0.77778],
    57367: [0.25142, 0.75726, 0, 0, 0.77778],
    57368: [0.25142, 0.75726, 0, 0, 0.77778],
    57369: [0.25142, 0.75726, 0, 0, 0.77778],
    57370: [0.13597, 0.63597, 0, 0, 0.77778],
    57371: [0.13597, 0.63597, 0, 0, 0.77778]
  },
  "Caligraphic-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68333, 0, 0.19445, 0.79847],
    66: [0, 0.68333, 0.03041, 0.13889, 0.65681],
    67: [0, 0.68333, 0.05834, 0.13889, 0.52653],
    68: [0, 0.68333, 0.02778, 0.08334, 0.77139],
    69: [0, 0.68333, 0.08944, 0.11111, 0.52778],
    70: [0, 0.68333, 0.09931, 0.11111, 0.71875],
    71: [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
    72: [0, 0.68333, 965e-5, 0.11111, 0.84452],
    73: [0, 0.68333, 0.07382, 0, 0.54452],
    74: [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
    75: [0, 0.68333, 0.01445, 0.05556, 0.76195],
    76: [0, 0.68333, 0, 0.13889, 0.68972],
    77: [0, 0.68333, 0, 0.13889, 1.2009],
    78: [0, 0.68333, 0.14736, 0.08334, 0.82049],
    79: [0, 0.68333, 0.02778, 0.11111, 0.79611],
    80: [0, 0.68333, 0.08222, 0.08334, 0.69556],
    81: [0.09722, 0.68333, 0, 0.11111, 0.81667],
    82: [0, 0.68333, 0, 0.08334, 0.8475],
    83: [0, 0.68333, 0.075, 0.13889, 0.60556],
    84: [0, 0.68333, 0.25417, 0, 0.54464],
    85: [0, 0.68333, 0.09931, 0.08334, 0.62583],
    86: [0, 0.68333, 0.08222, 0, 0.61278],
    87: [0, 0.68333, 0.08222, 0.08334, 0.98778],
    88: [0, 0.68333, 0.14643, 0.13889, 0.7133],
    89: [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
    90: [0, 0.68333, 0.07944, 0.13889, 0.72473],
    160: [0, 0, 0, 0, 0.25]
  },
  "Fraktur-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69141, 0, 0, 0.29574],
    34: [0, 0.69141, 0, 0, 0.21471],
    38: [0, 0.69141, 0, 0, 0.73786],
    39: [0, 0.69141, 0, 0, 0.21201],
    40: [0.24982, 0.74947, 0, 0, 0.38865],
    41: [0.24982, 0.74947, 0, 0, 0.38865],
    42: [0, 0.62119, 0, 0, 0.27764],
    43: [0.08319, 0.58283, 0, 0, 0.75623],
    44: [0, 0.10803, 0, 0, 0.27764],
    45: [0.08319, 0.58283, 0, 0, 0.75623],
    46: [0, 0.10803, 0, 0, 0.27764],
    47: [0.24982, 0.74947, 0, 0, 0.50181],
    48: [0, 0.47534, 0, 0, 0.50181],
    49: [0, 0.47534, 0, 0, 0.50181],
    50: [0, 0.47534, 0, 0, 0.50181],
    51: [0.18906, 0.47534, 0, 0, 0.50181],
    52: [0.18906, 0.47534, 0, 0, 0.50181],
    53: [0.18906, 0.47534, 0, 0, 0.50181],
    54: [0, 0.69141, 0, 0, 0.50181],
    55: [0.18906, 0.47534, 0, 0, 0.50181],
    56: [0, 0.69141, 0, 0, 0.50181],
    57: [0.18906, 0.47534, 0, 0, 0.50181],
    58: [0, 0.47534, 0, 0, 0.21606],
    59: [0.12604, 0.47534, 0, 0, 0.21606],
    61: [-0.13099, 0.36866, 0, 0, 0.75623],
    63: [0, 0.69141, 0, 0, 0.36245],
    65: [0, 0.69141, 0, 0, 0.7176],
    66: [0, 0.69141, 0, 0, 0.88397],
    67: [0, 0.69141, 0, 0, 0.61254],
    68: [0, 0.69141, 0, 0, 0.83158],
    69: [0, 0.69141, 0, 0, 0.66278],
    70: [0.12604, 0.69141, 0, 0, 0.61119],
    71: [0, 0.69141, 0, 0, 0.78539],
    72: [0.06302, 0.69141, 0, 0, 0.7203],
    73: [0, 0.69141, 0, 0, 0.55448],
    74: [0.12604, 0.69141, 0, 0, 0.55231],
    75: [0, 0.69141, 0, 0, 0.66845],
    76: [0, 0.69141, 0, 0, 0.66602],
    77: [0, 0.69141, 0, 0, 1.04953],
    78: [0, 0.69141, 0, 0, 0.83212],
    79: [0, 0.69141, 0, 0, 0.82699],
    80: [0.18906, 0.69141, 0, 0, 0.82753],
    81: [0.03781, 0.69141, 0, 0, 0.82699],
    82: [0, 0.69141, 0, 0, 0.82807],
    83: [0, 0.69141, 0, 0, 0.82861],
    84: [0, 0.69141, 0, 0, 0.66899],
    85: [0, 0.69141, 0, 0, 0.64576],
    86: [0, 0.69141, 0, 0, 0.83131],
    87: [0, 0.69141, 0, 0, 1.04602],
    88: [0, 0.69141, 0, 0, 0.71922],
    89: [0.18906, 0.69141, 0, 0, 0.83293],
    90: [0.12604, 0.69141, 0, 0, 0.60201],
    91: [0.24982, 0.74947, 0, 0, 0.27764],
    93: [0.24982, 0.74947, 0, 0, 0.27764],
    94: [0, 0.69141, 0, 0, 0.49965],
    97: [0, 0.47534, 0, 0, 0.50046],
    98: [0, 0.69141, 0, 0, 0.51315],
    99: [0, 0.47534, 0, 0, 0.38946],
    100: [0, 0.62119, 0, 0, 0.49857],
    101: [0, 0.47534, 0, 0, 0.40053],
    102: [0.18906, 0.69141, 0, 0, 0.32626],
    103: [0.18906, 0.47534, 0, 0, 0.5037],
    104: [0.18906, 0.69141, 0, 0, 0.52126],
    105: [0, 0.69141, 0, 0, 0.27899],
    106: [0, 0.69141, 0, 0, 0.28088],
    107: [0, 0.69141, 0, 0, 0.38946],
    108: [0, 0.69141, 0, 0, 0.27953],
    109: [0, 0.47534, 0, 0, 0.76676],
    110: [0, 0.47534, 0, 0, 0.52666],
    111: [0, 0.47534, 0, 0, 0.48885],
    112: [0.18906, 0.52396, 0, 0, 0.50046],
    113: [0.18906, 0.47534, 0, 0, 0.48912],
    114: [0, 0.47534, 0, 0, 0.38919],
    115: [0, 0.47534, 0, 0, 0.44266],
    116: [0, 0.62119, 0, 0, 0.33301],
    117: [0, 0.47534, 0, 0, 0.5172],
    118: [0, 0.52396, 0, 0, 0.5118],
    119: [0, 0.52396, 0, 0, 0.77351],
    120: [0.18906, 0.47534, 0, 0, 0.38865],
    121: [0.18906, 0.47534, 0, 0, 0.49884],
    122: [0.18906, 0.47534, 0, 0, 0.39054],
    160: [0, 0, 0, 0, 0.25],
    8216: [0, 0.69141, 0, 0, 0.21471],
    8217: [0, 0.69141, 0, 0, 0.21471],
    58112: [0, 0.62119, 0, 0, 0.49749],
    58113: [0, 0.62119, 0, 0, 0.4983],
    58114: [0.18906, 0.69141, 0, 0, 0.33328],
    58115: [0.18906, 0.69141, 0, 0, 0.32923],
    58116: [0.18906, 0.47534, 0, 0, 0.50343],
    58117: [0, 0.69141, 0, 0, 0.33301],
    58118: [0, 0.62119, 0, 0, 0.33409],
    58119: [0, 0.47534, 0, 0, 0.50073]
  },
  "Main-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.35],
    34: [0, 0.69444, 0, 0, 0.60278],
    35: [0.19444, 0.69444, 0, 0, 0.95833],
    36: [0.05556, 0.75, 0, 0, 0.575],
    37: [0.05556, 0.75, 0, 0, 0.95833],
    38: [0, 0.69444, 0, 0, 0.89444],
    39: [0, 0.69444, 0, 0, 0.31944],
    40: [0.25, 0.75, 0, 0, 0.44722],
    41: [0.25, 0.75, 0, 0, 0.44722],
    42: [0, 0.75, 0, 0, 0.575],
    43: [0.13333, 0.63333, 0, 0, 0.89444],
    44: [0.19444, 0.15556, 0, 0, 0.31944],
    45: [0, 0.44444, 0, 0, 0.38333],
    46: [0, 0.15556, 0, 0, 0.31944],
    47: [0.25, 0.75, 0, 0, 0.575],
    48: [0, 0.64444, 0, 0, 0.575],
    49: [0, 0.64444, 0, 0, 0.575],
    50: [0, 0.64444, 0, 0, 0.575],
    51: [0, 0.64444, 0, 0, 0.575],
    52: [0, 0.64444, 0, 0, 0.575],
    53: [0, 0.64444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0, 0.64444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0, 0.64444, 0, 0, 0.575],
    58: [0, 0.44444, 0, 0, 0.31944],
    59: [0.19444, 0.44444, 0, 0, 0.31944],
    60: [0.08556, 0.58556, 0, 0, 0.89444],
    61: [-0.10889, 0.39111, 0, 0, 0.89444],
    62: [0.08556, 0.58556, 0, 0, 0.89444],
    63: [0, 0.69444, 0, 0, 0.54305],
    64: [0, 0.69444, 0, 0, 0.89444],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0, 0, 0.81805],
    67: [0, 0.68611, 0, 0, 0.83055],
    68: [0, 0.68611, 0, 0, 0.88194],
    69: [0, 0.68611, 0, 0, 0.75555],
    70: [0, 0.68611, 0, 0, 0.72361],
    71: [0, 0.68611, 0, 0, 0.90416],
    72: [0, 0.68611, 0, 0, 0.9],
    73: [0, 0.68611, 0, 0, 0.43611],
    74: [0, 0.68611, 0, 0, 0.59444],
    75: [0, 0.68611, 0, 0, 0.90138],
    76: [0, 0.68611, 0, 0, 0.69166],
    77: [0, 0.68611, 0, 0, 1.09166],
    78: [0, 0.68611, 0, 0, 0.9],
    79: [0, 0.68611, 0, 0, 0.86388],
    80: [0, 0.68611, 0, 0, 0.78611],
    81: [0.19444, 0.68611, 0, 0, 0.86388],
    82: [0, 0.68611, 0, 0, 0.8625],
    83: [0, 0.68611, 0, 0, 0.63889],
    84: [0, 0.68611, 0, 0, 0.8],
    85: [0, 0.68611, 0, 0, 0.88472],
    86: [0, 0.68611, 0.01597, 0, 0.86944],
    87: [0, 0.68611, 0.01597, 0, 1.18888],
    88: [0, 0.68611, 0, 0, 0.86944],
    89: [0, 0.68611, 0.02875, 0, 0.86944],
    90: [0, 0.68611, 0, 0, 0.70277],
    91: [0.25, 0.75, 0, 0, 0.31944],
    92: [0.25, 0.75, 0, 0, 0.575],
    93: [0.25, 0.75, 0, 0, 0.31944],
    94: [0, 0.69444, 0, 0, 0.575],
    95: [0.31, 0.13444, 0.03194, 0, 0.575],
    97: [0, 0.44444, 0, 0, 0.55902],
    98: [0, 0.69444, 0, 0, 0.63889],
    99: [0, 0.44444, 0, 0, 0.51111],
    100: [0, 0.69444, 0, 0, 0.63889],
    101: [0, 0.44444, 0, 0, 0.52708],
    102: [0, 0.69444, 0.10903, 0, 0.35139],
    103: [0.19444, 0.44444, 0.01597, 0, 0.575],
    104: [0, 0.69444, 0, 0, 0.63889],
    105: [0, 0.69444, 0, 0, 0.31944],
    106: [0.19444, 0.69444, 0, 0, 0.35139],
    107: [0, 0.69444, 0, 0, 0.60694],
    108: [0, 0.69444, 0, 0, 0.31944],
    109: [0, 0.44444, 0, 0, 0.95833],
    110: [0, 0.44444, 0, 0, 0.63889],
    111: [0, 0.44444, 0, 0, 0.575],
    112: [0.19444, 0.44444, 0, 0, 0.63889],
    113: [0.19444, 0.44444, 0, 0, 0.60694],
    114: [0, 0.44444, 0, 0, 0.47361],
    115: [0, 0.44444, 0, 0, 0.45361],
    116: [0, 0.63492, 0, 0, 0.44722],
    117: [0, 0.44444, 0, 0, 0.63889],
    118: [0, 0.44444, 0.01597, 0, 0.60694],
    119: [0, 0.44444, 0.01597, 0, 0.83055],
    120: [0, 0.44444, 0, 0, 0.60694],
    121: [0.19444, 0.44444, 0.01597, 0, 0.60694],
    122: [0, 0.44444, 0, 0, 0.51111],
    123: [0.25, 0.75, 0, 0, 0.575],
    124: [0.25, 0.75, 0, 0, 0.31944],
    125: [0.25, 0.75, 0, 0, 0.575],
    126: [0.35, 0.34444, 0, 0, 0.575],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.86853],
    168: [0, 0.69444, 0, 0, 0.575],
    172: [0, 0.44444, 0, 0, 0.76666],
    176: [0, 0.69444, 0, 0, 0.86944],
    177: [0.13333, 0.63333, 0, 0, 0.89444],
    184: [0.17014, 0, 0, 0, 0.51111],
    198: [0, 0.68611, 0, 0, 1.04166],
    215: [0.13333, 0.63333, 0, 0, 0.89444],
    216: [0.04861, 0.73472, 0, 0, 0.89444],
    223: [0, 0.69444, 0, 0, 0.59722],
    230: [0, 0.44444, 0, 0, 0.83055],
    247: [0.13333, 0.63333, 0, 0, 0.89444],
    248: [0.09722, 0.54167, 0, 0, 0.575],
    305: [0, 0.44444, 0, 0, 0.31944],
    338: [0, 0.68611, 0, 0, 1.16944],
    339: [0, 0.44444, 0, 0, 0.89444],
    567: [0.19444, 0.44444, 0, 0, 0.35139],
    710: [0, 0.69444, 0, 0, 0.575],
    711: [0, 0.63194, 0, 0, 0.575],
    713: [0, 0.59611, 0, 0, 0.575],
    714: [0, 0.69444, 0, 0, 0.575],
    715: [0, 0.69444, 0, 0, 0.575],
    728: [0, 0.69444, 0, 0, 0.575],
    729: [0, 0.69444, 0, 0, 0.31944],
    730: [0, 0.69444, 0, 0, 0.86944],
    732: [0, 0.69444, 0, 0, 0.575],
    733: [0, 0.69444, 0, 0, 0.575],
    915: [0, 0.68611, 0, 0, 0.69166],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0, 0, 0.89444],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0, 0, 0.76666],
    928: [0, 0.68611, 0, 0, 0.9],
    931: [0, 0.68611, 0, 0, 0.83055],
    933: [0, 0.68611, 0, 0, 0.89444],
    934: [0, 0.68611, 0, 0, 0.83055],
    936: [0, 0.68611, 0, 0, 0.89444],
    937: [0, 0.68611, 0, 0, 0.83055],
    8211: [0, 0.44444, 0.03194, 0, 0.575],
    8212: [0, 0.44444, 0.03194, 0, 1.14999],
    8216: [0, 0.69444, 0, 0, 0.31944],
    8217: [0, 0.69444, 0, 0, 0.31944],
    8220: [0, 0.69444, 0, 0, 0.60278],
    8221: [0, 0.69444, 0, 0, 0.60278],
    8224: [0.19444, 0.69444, 0, 0, 0.51111],
    8225: [0.19444, 0.69444, 0, 0, 0.51111],
    8242: [0, 0.55556, 0, 0, 0.34444],
    8407: [0, 0.72444, 0.15486, 0, 0.575],
    8463: [0, 0.69444, 0, 0, 0.66759],
    8465: [0, 0.69444, 0, 0, 0.83055],
    8467: [0, 0.69444, 0, 0, 0.47361],
    8472: [0.19444, 0.44444, 0, 0, 0.74027],
    8476: [0, 0.69444, 0, 0, 0.83055],
    8501: [0, 0.69444, 0, 0, 0.70277],
    8592: [-0.10889, 0.39111, 0, 0, 1.14999],
    8593: [0.19444, 0.69444, 0, 0, 0.575],
    8594: [-0.10889, 0.39111, 0, 0, 1.14999],
    8595: [0.19444, 0.69444, 0, 0, 0.575],
    8596: [-0.10889, 0.39111, 0, 0, 1.14999],
    8597: [0.25, 0.75, 0, 0, 0.575],
    8598: [0.19444, 0.69444, 0, 0, 1.14999],
    8599: [0.19444, 0.69444, 0, 0, 1.14999],
    8600: [0.19444, 0.69444, 0, 0, 1.14999],
    8601: [0.19444, 0.69444, 0, 0, 1.14999],
    8636: [-0.10889, 0.39111, 0, 0, 1.14999],
    8637: [-0.10889, 0.39111, 0, 0, 1.14999],
    8640: [-0.10889, 0.39111, 0, 0, 1.14999],
    8641: [-0.10889, 0.39111, 0, 0, 1.14999],
    8656: [-0.10889, 0.39111, 0, 0, 1.14999],
    8657: [0.19444, 0.69444, 0, 0, 0.70277],
    8658: [-0.10889, 0.39111, 0, 0, 1.14999],
    8659: [0.19444, 0.69444, 0, 0, 0.70277],
    8660: [-0.10889, 0.39111, 0, 0, 1.14999],
    8661: [0.25, 0.75, 0, 0, 0.70277],
    8704: [0, 0.69444, 0, 0, 0.63889],
    8706: [0, 0.69444, 0.06389, 0, 0.62847],
    8707: [0, 0.69444, 0, 0, 0.63889],
    8709: [0.05556, 0.75, 0, 0, 0.575],
    8711: [0, 0.68611, 0, 0, 0.95833],
    8712: [0.08556, 0.58556, 0, 0, 0.76666],
    8715: [0.08556, 0.58556, 0, 0, 0.76666],
    8722: [0.13333, 0.63333, 0, 0, 0.89444],
    8723: [0.13333, 0.63333, 0, 0, 0.89444],
    8725: [0.25, 0.75, 0, 0, 0.575],
    8726: [0.25, 0.75, 0, 0, 0.575],
    8727: [-0.02778, 0.47222, 0, 0, 0.575],
    8728: [-0.02639, 0.47361, 0, 0, 0.575],
    8729: [-0.02639, 0.47361, 0, 0, 0.575],
    8730: [0.18, 0.82, 0, 0, 0.95833],
    8733: [0, 0.44444, 0, 0, 0.89444],
    8734: [0, 0.44444, 0, 0, 1.14999],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.31944],
    8741: [0.25, 0.75, 0, 0, 0.575],
    8743: [0, 0.55556, 0, 0, 0.76666],
    8744: [0, 0.55556, 0, 0, 0.76666],
    8745: [0, 0.55556, 0, 0, 0.76666],
    8746: [0, 0.55556, 0, 0, 0.76666],
    8747: [0.19444, 0.69444, 0.12778, 0, 0.56875],
    8764: [-0.10889, 0.39111, 0, 0, 0.89444],
    8768: [0.19444, 0.69444, 0, 0, 0.31944],
    8771: [222e-5, 0.50222, 0, 0, 0.89444],
    8773: [0.027, 0.638, 0, 0, 0.894],
    8776: [0.02444, 0.52444, 0, 0, 0.89444],
    8781: [222e-5, 0.50222, 0, 0, 0.89444],
    8801: [222e-5, 0.50222, 0, 0, 0.89444],
    8804: [0.19667, 0.69667, 0, 0, 0.89444],
    8805: [0.19667, 0.69667, 0, 0, 0.89444],
    8810: [0.08556, 0.58556, 0, 0, 1.14999],
    8811: [0.08556, 0.58556, 0, 0, 1.14999],
    8826: [0.08556, 0.58556, 0, 0, 0.89444],
    8827: [0.08556, 0.58556, 0, 0, 0.89444],
    8834: [0.08556, 0.58556, 0, 0, 0.89444],
    8835: [0.08556, 0.58556, 0, 0, 0.89444],
    8838: [0.19667, 0.69667, 0, 0, 0.89444],
    8839: [0.19667, 0.69667, 0, 0, 0.89444],
    8846: [0, 0.55556, 0, 0, 0.76666],
    8849: [0.19667, 0.69667, 0, 0, 0.89444],
    8850: [0.19667, 0.69667, 0, 0, 0.89444],
    8851: [0, 0.55556, 0, 0, 0.76666],
    8852: [0, 0.55556, 0, 0, 0.76666],
    8853: [0.13333, 0.63333, 0, 0, 0.89444],
    8854: [0.13333, 0.63333, 0, 0, 0.89444],
    8855: [0.13333, 0.63333, 0, 0, 0.89444],
    8856: [0.13333, 0.63333, 0, 0, 0.89444],
    8857: [0.13333, 0.63333, 0, 0, 0.89444],
    8866: [0, 0.69444, 0, 0, 0.70277],
    8867: [0, 0.69444, 0, 0, 0.70277],
    8868: [0, 0.69444, 0, 0, 0.89444],
    8869: [0, 0.69444, 0, 0, 0.89444],
    8900: [-0.02639, 0.47361, 0, 0, 0.575],
    8901: [-0.02639, 0.47361, 0, 0, 0.31944],
    8902: [-0.02778, 0.47222, 0, 0, 0.575],
    8968: [0.25, 0.75, 0, 0, 0.51111],
    8969: [0.25, 0.75, 0, 0, 0.51111],
    8970: [0.25, 0.75, 0, 0, 0.51111],
    8971: [0.25, 0.75, 0, 0, 0.51111],
    8994: [-0.13889, 0.36111, 0, 0, 1.14999],
    8995: [-0.13889, 0.36111, 0, 0, 1.14999],
    9651: [0.19444, 0.69444, 0, 0, 1.02222],
    9657: [-0.02778, 0.47222, 0, 0, 0.575],
    9661: [0.19444, 0.69444, 0, 0, 1.02222],
    9667: [-0.02778, 0.47222, 0, 0, 0.575],
    9711: [0.19444, 0.69444, 0, 0, 1.14999],
    9824: [0.12963, 0.69444, 0, 0, 0.89444],
    9825: [0.12963, 0.69444, 0, 0, 0.89444],
    9826: [0.12963, 0.69444, 0, 0, 0.89444],
    9827: [0.12963, 0.69444, 0, 0, 0.89444],
    9837: [0, 0.75, 0, 0, 0.44722],
    9838: [0.19444, 0.69444, 0, 0, 0.44722],
    9839: [0.19444, 0.69444, 0, 0, 0.44722],
    10216: [0.25, 0.75, 0, 0, 0.44722],
    10217: [0.25, 0.75, 0, 0, 0.44722],
    10815: [0, 0.68611, 0, 0, 0.9],
    10927: [0.19667, 0.69667, 0, 0, 0.89444],
    10928: [0.19667, 0.69667, 0, 0, 0.89444],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Main-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.11417, 0, 0.38611],
    34: [0, 0.69444, 0.07939, 0, 0.62055],
    35: [0.19444, 0.69444, 0.06833, 0, 0.94444],
    37: [0.05556, 0.75, 0.12861, 0, 0.94444],
    38: [0, 0.69444, 0.08528, 0, 0.88555],
    39: [0, 0.69444, 0.12945, 0, 0.35555],
    40: [0.25, 0.75, 0.15806, 0, 0.47333],
    41: [0.25, 0.75, 0.03306, 0, 0.47333],
    42: [0, 0.75, 0.14333, 0, 0.59111],
    43: [0.10333, 0.60333, 0.03306, 0, 0.88555],
    44: [0.19444, 0.14722, 0, 0, 0.35555],
    45: [0, 0.44444, 0.02611, 0, 0.41444],
    46: [0, 0.14722, 0, 0, 0.35555],
    47: [0.25, 0.75, 0.15806, 0, 0.59111],
    48: [0, 0.64444, 0.13167, 0, 0.59111],
    49: [0, 0.64444, 0.13167, 0, 0.59111],
    50: [0, 0.64444, 0.13167, 0, 0.59111],
    51: [0, 0.64444, 0.13167, 0, 0.59111],
    52: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    53: [0, 0.64444, 0.13167, 0, 0.59111],
    54: [0, 0.64444, 0.13167, 0, 0.59111],
    55: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    56: [0, 0.64444, 0.13167, 0, 0.59111],
    57: [0, 0.64444, 0.13167, 0, 0.59111],
    58: [0, 0.44444, 0.06695, 0, 0.35555],
    59: [0.19444, 0.44444, 0.06695, 0, 0.35555],
    61: [-0.10889, 0.39111, 0.06833, 0, 0.88555],
    63: [0, 0.69444, 0.11472, 0, 0.59111],
    64: [0, 0.69444, 0.09208, 0, 0.88555],
    65: [0, 0.68611, 0, 0, 0.86555],
    66: [0, 0.68611, 0.0992, 0, 0.81666],
    67: [0, 0.68611, 0.14208, 0, 0.82666],
    68: [0, 0.68611, 0.09062, 0, 0.87555],
    69: [0, 0.68611, 0.11431, 0, 0.75666],
    70: [0, 0.68611, 0.12903, 0, 0.72722],
    71: [0, 0.68611, 0.07347, 0, 0.89527],
    72: [0, 0.68611, 0.17208, 0, 0.8961],
    73: [0, 0.68611, 0.15681, 0, 0.47166],
    74: [0, 0.68611, 0.145, 0, 0.61055],
    75: [0, 0.68611, 0.14208, 0, 0.89499],
    76: [0, 0.68611, 0, 0, 0.69777],
    77: [0, 0.68611, 0.17208, 0, 1.07277],
    78: [0, 0.68611, 0.17208, 0, 0.8961],
    79: [0, 0.68611, 0.09062, 0, 0.85499],
    80: [0, 0.68611, 0.0992, 0, 0.78721],
    81: [0.19444, 0.68611, 0.09062, 0, 0.85499],
    82: [0, 0.68611, 0.02559, 0, 0.85944],
    83: [0, 0.68611, 0.11264, 0, 0.64999],
    84: [0, 0.68611, 0.12903, 0, 0.7961],
    85: [0, 0.68611, 0.17208, 0, 0.88083],
    86: [0, 0.68611, 0.18625, 0, 0.86555],
    87: [0, 0.68611, 0.18625, 0, 1.15999],
    88: [0, 0.68611, 0.15681, 0, 0.86555],
    89: [0, 0.68611, 0.19803, 0, 0.86555],
    90: [0, 0.68611, 0.14208, 0, 0.70888],
    91: [0.25, 0.75, 0.1875, 0, 0.35611],
    93: [0.25, 0.75, 0.09972, 0, 0.35611],
    94: [0, 0.69444, 0.06709, 0, 0.59111],
    95: [0.31, 0.13444, 0.09811, 0, 0.59111],
    97: [0, 0.44444, 0.09426, 0, 0.59111],
    98: [0, 0.69444, 0.07861, 0, 0.53222],
    99: [0, 0.44444, 0.05222, 0, 0.53222],
    100: [0, 0.69444, 0.10861, 0, 0.59111],
    101: [0, 0.44444, 0.085, 0, 0.53222],
    102: [0.19444, 0.69444, 0.21778, 0, 0.4],
    103: [0.19444, 0.44444, 0.105, 0, 0.53222],
    104: [0, 0.69444, 0.09426, 0, 0.59111],
    105: [0, 0.69326, 0.11387, 0, 0.35555],
    106: [0.19444, 0.69326, 0.1672, 0, 0.35555],
    107: [0, 0.69444, 0.11111, 0, 0.53222],
    108: [0, 0.69444, 0.10861, 0, 0.29666],
    109: [0, 0.44444, 0.09426, 0, 0.94444],
    110: [0, 0.44444, 0.09426, 0, 0.64999],
    111: [0, 0.44444, 0.07861, 0, 0.59111],
    112: [0.19444, 0.44444, 0.07861, 0, 0.59111],
    113: [0.19444, 0.44444, 0.105, 0, 0.53222],
    114: [0, 0.44444, 0.11111, 0, 0.50167],
    115: [0, 0.44444, 0.08167, 0, 0.48694],
    116: [0, 0.63492, 0.09639, 0, 0.385],
    117: [0, 0.44444, 0.09426, 0, 0.62055],
    118: [0, 0.44444, 0.11111, 0, 0.53222],
    119: [0, 0.44444, 0.11111, 0, 0.76777],
    120: [0, 0.44444, 0.12583, 0, 0.56055],
    121: [0.19444, 0.44444, 0.105, 0, 0.56166],
    122: [0, 0.44444, 0.13889, 0, 0.49055],
    126: [0.35, 0.34444, 0.11472, 0, 0.59111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0.11473, 0, 0.59111],
    176: [0, 0.69444, 0, 0, 0.94888],
    184: [0.17014, 0, 0, 0, 0.53222],
    198: [0, 0.68611, 0.11431, 0, 1.02277],
    216: [0.04861, 0.73472, 0.09062, 0, 0.88555],
    223: [0.19444, 0.69444, 0.09736, 0, 0.665],
    230: [0, 0.44444, 0.085, 0, 0.82666],
    248: [0.09722, 0.54167, 0.09458, 0, 0.59111],
    305: [0, 0.44444, 0.09426, 0, 0.35555],
    338: [0, 0.68611, 0.11431, 0, 1.14054],
    339: [0, 0.44444, 0.085, 0, 0.82666],
    567: [0.19444, 0.44444, 0.04611, 0, 0.385],
    710: [0, 0.69444, 0.06709, 0, 0.59111],
    711: [0, 0.63194, 0.08271, 0, 0.59111],
    713: [0, 0.59444, 0.10444, 0, 0.59111],
    714: [0, 0.69444, 0.08528, 0, 0.59111],
    715: [0, 0.69444, 0, 0, 0.59111],
    728: [0, 0.69444, 0.10333, 0, 0.59111],
    729: [0, 0.69444, 0.12945, 0, 0.35555],
    730: [0, 0.69444, 0, 0, 0.94888],
    732: [0, 0.69444, 0.11472, 0, 0.59111],
    733: [0, 0.69444, 0.11472, 0, 0.59111],
    915: [0, 0.68611, 0.12903, 0, 0.69777],
    916: [0, 0.68611, 0, 0, 0.94444],
    920: [0, 0.68611, 0.09062, 0, 0.88555],
    923: [0, 0.68611, 0, 0, 0.80666],
    926: [0, 0.68611, 0.15092, 0, 0.76777],
    928: [0, 0.68611, 0.17208, 0, 0.8961],
    931: [0, 0.68611, 0.11431, 0, 0.82666],
    933: [0, 0.68611, 0.10778, 0, 0.88555],
    934: [0, 0.68611, 0.05632, 0, 0.82666],
    936: [0, 0.68611, 0.10778, 0, 0.88555],
    937: [0, 0.68611, 0.0992, 0, 0.82666],
    8211: [0, 0.44444, 0.09811, 0, 0.59111],
    8212: [0, 0.44444, 0.09811, 0, 1.18221],
    8216: [0, 0.69444, 0.12945, 0, 0.35555],
    8217: [0, 0.69444, 0.12945, 0, 0.35555],
    8220: [0, 0.69444, 0.16772, 0, 0.62055],
    8221: [0, 0.69444, 0.07939, 0, 0.62055]
  },
  "Main-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.12417, 0, 0.30667],
    34: [0, 0.69444, 0.06961, 0, 0.51444],
    35: [0.19444, 0.69444, 0.06616, 0, 0.81777],
    37: [0.05556, 0.75, 0.13639, 0, 0.81777],
    38: [0, 0.69444, 0.09694, 0, 0.76666],
    39: [0, 0.69444, 0.12417, 0, 0.30667],
    40: [0.25, 0.75, 0.16194, 0, 0.40889],
    41: [0.25, 0.75, 0.03694, 0, 0.40889],
    42: [0, 0.75, 0.14917, 0, 0.51111],
    43: [0.05667, 0.56167, 0.03694, 0, 0.76666],
    44: [0.19444, 0.10556, 0, 0, 0.30667],
    45: [0, 0.43056, 0.02826, 0, 0.35778],
    46: [0, 0.10556, 0, 0, 0.30667],
    47: [0.25, 0.75, 0.16194, 0, 0.51111],
    48: [0, 0.64444, 0.13556, 0, 0.51111],
    49: [0, 0.64444, 0.13556, 0, 0.51111],
    50: [0, 0.64444, 0.13556, 0, 0.51111],
    51: [0, 0.64444, 0.13556, 0, 0.51111],
    52: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    53: [0, 0.64444, 0.13556, 0, 0.51111],
    54: [0, 0.64444, 0.13556, 0, 0.51111],
    55: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    56: [0, 0.64444, 0.13556, 0, 0.51111],
    57: [0, 0.64444, 0.13556, 0, 0.51111],
    58: [0, 0.43056, 0.0582, 0, 0.30667],
    59: [0.19444, 0.43056, 0.0582, 0, 0.30667],
    61: [-0.13313, 0.36687, 0.06616, 0, 0.76666],
    63: [0, 0.69444, 0.1225, 0, 0.51111],
    64: [0, 0.69444, 0.09597, 0, 0.76666],
    65: [0, 0.68333, 0, 0, 0.74333],
    66: [0, 0.68333, 0.10257, 0, 0.70389],
    67: [0, 0.68333, 0.14528, 0, 0.71555],
    68: [0, 0.68333, 0.09403, 0, 0.755],
    69: [0, 0.68333, 0.12028, 0, 0.67833],
    70: [0, 0.68333, 0.13305, 0, 0.65277],
    71: [0, 0.68333, 0.08722, 0, 0.77361],
    72: [0, 0.68333, 0.16389, 0, 0.74333],
    73: [0, 0.68333, 0.15806, 0, 0.38555],
    74: [0, 0.68333, 0.14028, 0, 0.525],
    75: [0, 0.68333, 0.14528, 0, 0.76888],
    76: [0, 0.68333, 0, 0, 0.62722],
    77: [0, 0.68333, 0.16389, 0, 0.89666],
    78: [0, 0.68333, 0.16389, 0, 0.74333],
    79: [0, 0.68333, 0.09403, 0, 0.76666],
    80: [0, 0.68333, 0.10257, 0, 0.67833],
    81: [0.19444, 0.68333, 0.09403, 0, 0.76666],
    82: [0, 0.68333, 0.03868, 0, 0.72944],
    83: [0, 0.68333, 0.11972, 0, 0.56222],
    84: [0, 0.68333, 0.13305, 0, 0.71555],
    85: [0, 0.68333, 0.16389, 0, 0.74333],
    86: [0, 0.68333, 0.18361, 0, 0.74333],
    87: [0, 0.68333, 0.18361, 0, 0.99888],
    88: [0, 0.68333, 0.15806, 0, 0.74333],
    89: [0, 0.68333, 0.19383, 0, 0.74333],
    90: [0, 0.68333, 0.14528, 0, 0.61333],
    91: [0.25, 0.75, 0.1875, 0, 0.30667],
    93: [0.25, 0.75, 0.10528, 0, 0.30667],
    94: [0, 0.69444, 0.06646, 0, 0.51111],
    95: [0.31, 0.12056, 0.09208, 0, 0.51111],
    97: [0, 0.43056, 0.07671, 0, 0.51111],
    98: [0, 0.69444, 0.06312, 0, 0.46],
    99: [0, 0.43056, 0.05653, 0, 0.46],
    100: [0, 0.69444, 0.10333, 0, 0.51111],
    101: [0, 0.43056, 0.07514, 0, 0.46],
    102: [0.19444, 0.69444, 0.21194, 0, 0.30667],
    103: [0.19444, 0.43056, 0.08847, 0, 0.46],
    104: [0, 0.69444, 0.07671, 0, 0.51111],
    105: [0, 0.65536, 0.1019, 0, 0.30667],
    106: [0.19444, 0.65536, 0.14467, 0, 0.30667],
    107: [0, 0.69444, 0.10764, 0, 0.46],
    108: [0, 0.69444, 0.10333, 0, 0.25555],
    109: [0, 0.43056, 0.07671, 0, 0.81777],
    110: [0, 0.43056, 0.07671, 0, 0.56222],
    111: [0, 0.43056, 0.06312, 0, 0.51111],
    112: [0.19444, 0.43056, 0.06312, 0, 0.51111],
    113: [0.19444, 0.43056, 0.08847, 0, 0.46],
    114: [0, 0.43056, 0.10764, 0, 0.42166],
    115: [0, 0.43056, 0.08208, 0, 0.40889],
    116: [0, 0.61508, 0.09486, 0, 0.33222],
    117: [0, 0.43056, 0.07671, 0, 0.53666],
    118: [0, 0.43056, 0.10764, 0, 0.46],
    119: [0, 0.43056, 0.10764, 0, 0.66444],
    120: [0, 0.43056, 0.12042, 0, 0.46389],
    121: [0.19444, 0.43056, 0.08847, 0, 0.48555],
    122: [0, 0.43056, 0.12292, 0, 0.40889],
    126: [0.35, 0.31786, 0.11585, 0, 0.51111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.66786, 0.10474, 0, 0.51111],
    176: [0, 0.69444, 0, 0, 0.83129],
    184: [0.17014, 0, 0, 0, 0.46],
    198: [0, 0.68333, 0.12028, 0, 0.88277],
    216: [0.04861, 0.73194, 0.09403, 0, 0.76666],
    223: [0.19444, 0.69444, 0.10514, 0, 0.53666],
    230: [0, 0.43056, 0.07514, 0, 0.71555],
    248: [0.09722, 0.52778, 0.09194, 0, 0.51111],
    338: [0, 0.68333, 0.12028, 0, 0.98499],
    339: [0, 0.43056, 0.07514, 0, 0.71555],
    710: [0, 0.69444, 0.06646, 0, 0.51111],
    711: [0, 0.62847, 0.08295, 0, 0.51111],
    713: [0, 0.56167, 0.10333, 0, 0.51111],
    714: [0, 0.69444, 0.09694, 0, 0.51111],
    715: [0, 0.69444, 0, 0, 0.51111],
    728: [0, 0.69444, 0.10806, 0, 0.51111],
    729: [0, 0.66786, 0.11752, 0, 0.30667],
    730: [0, 0.69444, 0, 0, 0.83129],
    732: [0, 0.66786, 0.11585, 0, 0.51111],
    733: [0, 0.69444, 0.1225, 0, 0.51111],
    915: [0, 0.68333, 0.13305, 0, 0.62722],
    916: [0, 0.68333, 0, 0, 0.81777],
    920: [0, 0.68333, 0.09403, 0, 0.76666],
    923: [0, 0.68333, 0, 0, 0.69222],
    926: [0, 0.68333, 0.15294, 0, 0.66444],
    928: [0, 0.68333, 0.16389, 0, 0.74333],
    931: [0, 0.68333, 0.12028, 0, 0.71555],
    933: [0, 0.68333, 0.11111, 0, 0.76666],
    934: [0, 0.68333, 0.05986, 0, 0.71555],
    936: [0, 0.68333, 0.11111, 0, 0.76666],
    937: [0, 0.68333, 0.10257, 0, 0.71555],
    8211: [0, 0.43056, 0.09208, 0, 0.51111],
    8212: [0, 0.43056, 0.09208, 0, 1.02222],
    8216: [0, 0.69444, 0.12417, 0, 0.30667],
    8217: [0, 0.69444, 0.12417, 0, 0.30667],
    8220: [0, 0.69444, 0.1685, 0, 0.51444],
    8221: [0, 0.69444, 0.06961, 0, 0.51444],
    8463: [0, 0.68889, 0, 0, 0.54028]
  },
  "Main-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.27778],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.77778],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.19444, 0.10556, 0, 0, 0.27778],
    45: [0, 0.43056, 0, 0, 0.33333],
    46: [0, 0.10556, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.64444, 0, 0, 0.5],
    49: [0, 0.64444, 0, 0, 0.5],
    50: [0, 0.64444, 0, 0, 0.5],
    51: [0, 0.64444, 0, 0, 0.5],
    52: [0, 0.64444, 0, 0, 0.5],
    53: [0, 0.64444, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0, 0.64444, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0, 0.64444, 0, 0, 0.5],
    58: [0, 0.43056, 0, 0, 0.27778],
    59: [0.19444, 0.43056, 0, 0, 0.27778],
    60: [0.0391, 0.5391, 0, 0, 0.77778],
    61: [-0.13313, 0.36687, 0, 0, 0.77778],
    62: [0.0391, 0.5391, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.77778],
    65: [0, 0.68333, 0, 0, 0.75],
    66: [0, 0.68333, 0, 0, 0.70834],
    67: [0, 0.68333, 0, 0, 0.72222],
    68: [0, 0.68333, 0, 0, 0.76389],
    69: [0, 0.68333, 0, 0, 0.68056],
    70: [0, 0.68333, 0, 0, 0.65278],
    71: [0, 0.68333, 0, 0, 0.78472],
    72: [0, 0.68333, 0, 0, 0.75],
    73: [0, 0.68333, 0, 0, 0.36111],
    74: [0, 0.68333, 0, 0, 0.51389],
    75: [0, 0.68333, 0, 0, 0.77778],
    76: [0, 0.68333, 0, 0, 0.625],
    77: [0, 0.68333, 0, 0, 0.91667],
    78: [0, 0.68333, 0, 0, 0.75],
    79: [0, 0.68333, 0, 0, 0.77778],
    80: [0, 0.68333, 0, 0, 0.68056],
    81: [0.19444, 0.68333, 0, 0, 0.77778],
    82: [0, 0.68333, 0, 0, 0.73611],
    83: [0, 0.68333, 0, 0, 0.55556],
    84: [0, 0.68333, 0, 0, 0.72222],
    85: [0, 0.68333, 0, 0, 0.75],
    86: [0, 0.68333, 0.01389, 0, 0.75],
    87: [0, 0.68333, 0.01389, 0, 1.02778],
    88: [0, 0.68333, 0, 0, 0.75],
    89: [0, 0.68333, 0.025, 0, 0.75],
    90: [0, 0.68333, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.27778],
    92: [0.25, 0.75, 0, 0, 0.5],
    93: [0.25, 0.75, 0, 0, 0.27778],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.31, 0.12056, 0.02778, 0, 0.5],
    97: [0, 0.43056, 0, 0, 0.5],
    98: [0, 0.69444, 0, 0, 0.55556],
    99: [0, 0.43056, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.55556],
    101: [0, 0.43056, 0, 0, 0.44445],
    102: [0, 0.69444, 0.07778, 0, 0.30556],
    103: [0.19444, 0.43056, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.55556],
    105: [0, 0.66786, 0, 0, 0.27778],
    106: [0.19444, 0.66786, 0, 0, 0.30556],
    107: [0, 0.69444, 0, 0, 0.52778],
    108: [0, 0.69444, 0, 0, 0.27778],
    109: [0, 0.43056, 0, 0, 0.83334],
    110: [0, 0.43056, 0, 0, 0.55556],
    111: [0, 0.43056, 0, 0, 0.5],
    112: [0.19444, 0.43056, 0, 0, 0.55556],
    113: [0.19444, 0.43056, 0, 0, 0.52778],
    114: [0, 0.43056, 0, 0, 0.39167],
    115: [0, 0.43056, 0, 0, 0.39445],
    116: [0, 0.61508, 0, 0, 0.38889],
    117: [0, 0.43056, 0, 0, 0.55556],
    118: [0, 0.43056, 0.01389, 0, 0.52778],
    119: [0, 0.43056, 0.01389, 0, 0.72222],
    120: [0, 0.43056, 0, 0, 0.52778],
    121: [0.19444, 0.43056, 0.01389, 0, 0.52778],
    122: [0, 0.43056, 0, 0, 0.44445],
    123: [0.25, 0.75, 0, 0, 0.5],
    124: [0.25, 0.75, 0, 0, 0.27778],
    125: [0.25, 0.75, 0, 0, 0.5],
    126: [0.35, 0.31786, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.76909],
    167: [0.19444, 0.69444, 0, 0, 0.44445],
    168: [0, 0.66786, 0, 0, 0.5],
    172: [0, 0.43056, 0, 0, 0.66667],
    176: [0, 0.69444, 0, 0, 0.75],
    177: [0.08333, 0.58333, 0, 0, 0.77778],
    182: [0.19444, 0.69444, 0, 0, 0.61111],
    184: [0.17014, 0, 0, 0, 0.44445],
    198: [0, 0.68333, 0, 0, 0.90278],
    215: [0.08333, 0.58333, 0, 0, 0.77778],
    216: [0.04861, 0.73194, 0, 0, 0.77778],
    223: [0, 0.69444, 0, 0, 0.5],
    230: [0, 0.43056, 0, 0, 0.72222],
    247: [0.08333, 0.58333, 0, 0, 0.77778],
    248: [0.09722, 0.52778, 0, 0, 0.5],
    305: [0, 0.43056, 0, 0, 0.27778],
    338: [0, 0.68333, 0, 0, 1.01389],
    339: [0, 0.43056, 0, 0, 0.77778],
    567: [0.19444, 0.43056, 0, 0, 0.30556],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.62847, 0, 0, 0.5],
    713: [0, 0.56778, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.66786, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.75],
    732: [0, 0.66786, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.68333, 0, 0, 0.625],
    916: [0, 0.68333, 0, 0, 0.83334],
    920: [0, 0.68333, 0, 0, 0.77778],
    923: [0, 0.68333, 0, 0, 0.69445],
    926: [0, 0.68333, 0, 0, 0.66667],
    928: [0, 0.68333, 0, 0, 0.75],
    931: [0, 0.68333, 0, 0, 0.72222],
    933: [0, 0.68333, 0, 0, 0.77778],
    934: [0, 0.68333, 0, 0, 0.72222],
    936: [0, 0.68333, 0, 0, 0.77778],
    937: [0, 0.68333, 0, 0, 0.72222],
    8211: [0, 0.43056, 0.02778, 0, 0.5],
    8212: [0, 0.43056, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5],
    8224: [0.19444, 0.69444, 0, 0, 0.44445],
    8225: [0.19444, 0.69444, 0, 0, 0.44445],
    8230: [0, 0.123, 0, 0, 1.172],
    8242: [0, 0.55556, 0, 0, 0.275],
    8407: [0, 0.71444, 0.15382, 0, 0.5],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8465: [0, 0.69444, 0, 0, 0.72222],
    8467: [0, 0.69444, 0, 0.11111, 0.41667],
    8472: [0.19444, 0.43056, 0, 0.11111, 0.63646],
    8476: [0, 0.69444, 0, 0, 0.72222],
    8501: [0, 0.69444, 0, 0, 0.61111],
    8592: [-0.13313, 0.36687, 0, 0, 1],
    8593: [0.19444, 0.69444, 0, 0, 0.5],
    8594: [-0.13313, 0.36687, 0, 0, 1],
    8595: [0.19444, 0.69444, 0, 0, 0.5],
    8596: [-0.13313, 0.36687, 0, 0, 1],
    8597: [0.25, 0.75, 0, 0, 0.5],
    8598: [0.19444, 0.69444, 0, 0, 1],
    8599: [0.19444, 0.69444, 0, 0, 1],
    8600: [0.19444, 0.69444, 0, 0, 1],
    8601: [0.19444, 0.69444, 0, 0, 1],
    8614: [0.011, 0.511, 0, 0, 1],
    8617: [0.011, 0.511, 0, 0, 1.126],
    8618: [0.011, 0.511, 0, 0, 1.126],
    8636: [-0.13313, 0.36687, 0, 0, 1],
    8637: [-0.13313, 0.36687, 0, 0, 1],
    8640: [-0.13313, 0.36687, 0, 0, 1],
    8641: [-0.13313, 0.36687, 0, 0, 1],
    8652: [0.011, 0.671, 0, 0, 1],
    8656: [-0.13313, 0.36687, 0, 0, 1],
    8657: [0.19444, 0.69444, 0, 0, 0.61111],
    8658: [-0.13313, 0.36687, 0, 0, 1],
    8659: [0.19444, 0.69444, 0, 0, 0.61111],
    8660: [-0.13313, 0.36687, 0, 0, 1],
    8661: [0.25, 0.75, 0, 0, 0.61111],
    8704: [0, 0.69444, 0, 0, 0.55556],
    8706: [0, 0.69444, 0.05556, 0.08334, 0.5309],
    8707: [0, 0.69444, 0, 0, 0.55556],
    8709: [0.05556, 0.75, 0, 0, 0.5],
    8711: [0, 0.68333, 0, 0, 0.83334],
    8712: [0.0391, 0.5391, 0, 0, 0.66667],
    8715: [0.0391, 0.5391, 0, 0, 0.66667],
    8722: [0.08333, 0.58333, 0, 0, 0.77778],
    8723: [0.08333, 0.58333, 0, 0, 0.77778],
    8725: [0.25, 0.75, 0, 0, 0.5],
    8726: [0.25, 0.75, 0, 0, 0.5],
    8727: [-0.03472, 0.46528, 0, 0, 0.5],
    8728: [-0.05555, 0.44445, 0, 0, 0.5],
    8729: [-0.05555, 0.44445, 0, 0, 0.5],
    8730: [0.2, 0.8, 0, 0, 0.83334],
    8733: [0, 0.43056, 0, 0, 0.77778],
    8734: [0, 0.43056, 0, 0, 1],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.27778],
    8741: [0.25, 0.75, 0, 0, 0.5],
    8743: [0, 0.55556, 0, 0, 0.66667],
    8744: [0, 0.55556, 0, 0, 0.66667],
    8745: [0, 0.55556, 0, 0, 0.66667],
    8746: [0, 0.55556, 0, 0, 0.66667],
    8747: [0.19444, 0.69444, 0.11111, 0, 0.41667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8768: [0.19444, 0.69444, 0, 0, 0.27778],
    8771: [-0.03625, 0.46375, 0, 0, 0.77778],
    8773: [-0.022, 0.589, 0, 0, 0.778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8781: [-0.03625, 0.46375, 0, 0, 0.77778],
    8784: [-0.133, 0.673, 0, 0, 0.778],
    8801: [-0.03625, 0.46375, 0, 0, 0.77778],
    8804: [0.13597, 0.63597, 0, 0, 0.77778],
    8805: [0.13597, 0.63597, 0, 0, 0.77778],
    8810: [0.0391, 0.5391, 0, 0, 1],
    8811: [0.0391, 0.5391, 0, 0, 1],
    8826: [0.0391, 0.5391, 0, 0, 0.77778],
    8827: [0.0391, 0.5391, 0, 0, 0.77778],
    8834: [0.0391, 0.5391, 0, 0, 0.77778],
    8835: [0.0391, 0.5391, 0, 0, 0.77778],
    8838: [0.13597, 0.63597, 0, 0, 0.77778],
    8839: [0.13597, 0.63597, 0, 0, 0.77778],
    8846: [0, 0.55556, 0, 0, 0.66667],
    8849: [0.13597, 0.63597, 0, 0, 0.77778],
    8850: [0.13597, 0.63597, 0, 0, 0.77778],
    8851: [0, 0.55556, 0, 0, 0.66667],
    8852: [0, 0.55556, 0, 0, 0.66667],
    8853: [0.08333, 0.58333, 0, 0, 0.77778],
    8854: [0.08333, 0.58333, 0, 0, 0.77778],
    8855: [0.08333, 0.58333, 0, 0, 0.77778],
    8856: [0.08333, 0.58333, 0, 0, 0.77778],
    8857: [0.08333, 0.58333, 0, 0, 0.77778],
    8866: [0, 0.69444, 0, 0, 0.61111],
    8867: [0, 0.69444, 0, 0, 0.61111],
    8868: [0, 0.69444, 0, 0, 0.77778],
    8869: [0, 0.69444, 0, 0, 0.77778],
    8872: [0.249, 0.75, 0, 0, 0.867],
    8900: [-0.05555, 0.44445, 0, 0, 0.5],
    8901: [-0.05555, 0.44445, 0, 0, 0.27778],
    8902: [-0.03472, 0.46528, 0, 0, 0.5],
    8904: [5e-3, 0.505, 0, 0, 0.9],
    8942: [0.03, 0.903, 0, 0, 0.278],
    8943: [-0.19, 0.313, 0, 0, 1.172],
    8945: [-0.1, 0.823, 0, 0, 1.282],
    8968: [0.25, 0.75, 0, 0, 0.44445],
    8969: [0.25, 0.75, 0, 0, 0.44445],
    8970: [0.25, 0.75, 0, 0, 0.44445],
    8971: [0.25, 0.75, 0, 0, 0.44445],
    8994: [-0.14236, 0.35764, 0, 0, 1],
    8995: [-0.14236, 0.35764, 0, 0, 1],
    9136: [0.244, 0.744, 0, 0, 0.412],
    9137: [0.244, 0.745, 0, 0, 0.412],
    9651: [0.19444, 0.69444, 0, 0, 0.88889],
    9657: [-0.03472, 0.46528, 0, 0, 0.5],
    9661: [0.19444, 0.69444, 0, 0, 0.88889],
    9667: [-0.03472, 0.46528, 0, 0, 0.5],
    9711: [0.19444, 0.69444, 0, 0, 1],
    9824: [0.12963, 0.69444, 0, 0, 0.77778],
    9825: [0.12963, 0.69444, 0, 0, 0.77778],
    9826: [0.12963, 0.69444, 0, 0, 0.77778],
    9827: [0.12963, 0.69444, 0, 0, 0.77778],
    9837: [0, 0.75, 0, 0, 0.38889],
    9838: [0.19444, 0.69444, 0, 0, 0.38889],
    9839: [0.19444, 0.69444, 0, 0, 0.38889],
    10216: [0.25, 0.75, 0, 0, 0.38889],
    10217: [0.25, 0.75, 0, 0, 0.38889],
    10222: [0.244, 0.744, 0, 0, 0.412],
    10223: [0.244, 0.745, 0, 0, 0.412],
    10229: [0.011, 0.511, 0, 0, 1.609],
    10230: [0.011, 0.511, 0, 0, 1.638],
    10231: [0.011, 0.511, 0, 0, 1.859],
    10232: [0.024, 0.525, 0, 0, 1.609],
    10233: [0.024, 0.525, 0, 0, 1.638],
    10234: [0.024, 0.525, 0, 0, 1.858],
    10236: [0.011, 0.511, 0, 0, 1.638],
    10815: [0, 0.68333, 0, 0, 0.75],
    10927: [0.13597, 0.63597, 0, 0, 0.77778],
    10928: [0.13597, 0.63597, 0, 0, 0.77778],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Math-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.44444, 0, 0, 0.575],
    49: [0, 0.44444, 0, 0, 0.575],
    50: [0, 0.44444, 0, 0, 0.575],
    51: [0.19444, 0.44444, 0, 0, 0.575],
    52: [0.19444, 0.44444, 0, 0, 0.575],
    53: [0.19444, 0.44444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0.19444, 0.44444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0.19444, 0.44444, 0, 0, 0.575],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0.04835, 0, 0.8664],
    67: [0, 0.68611, 0.06979, 0, 0.81694],
    68: [0, 0.68611, 0.03194, 0, 0.93812],
    69: [0, 0.68611, 0.05451, 0, 0.81007],
    70: [0, 0.68611, 0.15972, 0, 0.68889],
    71: [0, 0.68611, 0, 0, 0.88673],
    72: [0, 0.68611, 0.08229, 0, 0.98229],
    73: [0, 0.68611, 0.07778, 0, 0.51111],
    74: [0, 0.68611, 0.10069, 0, 0.63125],
    75: [0, 0.68611, 0.06979, 0, 0.97118],
    76: [0, 0.68611, 0, 0, 0.75555],
    77: [0, 0.68611, 0.11424, 0, 1.14201],
    78: [0, 0.68611, 0.11424, 0, 0.95034],
    79: [0, 0.68611, 0.03194, 0, 0.83666],
    80: [0, 0.68611, 0.15972, 0, 0.72309],
    81: [0.19444, 0.68611, 0, 0, 0.86861],
    82: [0, 0.68611, 421e-5, 0, 0.87235],
    83: [0, 0.68611, 0.05382, 0, 0.69271],
    84: [0, 0.68611, 0.15972, 0, 0.63663],
    85: [0, 0.68611, 0.11424, 0, 0.80027],
    86: [0, 0.68611, 0.25555, 0, 0.67778],
    87: [0, 0.68611, 0.15972, 0, 1.09305],
    88: [0, 0.68611, 0.07778, 0, 0.94722],
    89: [0, 0.68611, 0.25555, 0, 0.67458],
    90: [0, 0.68611, 0.06979, 0, 0.77257],
    97: [0, 0.44444, 0, 0, 0.63287],
    98: [0, 0.69444, 0, 0, 0.52083],
    99: [0, 0.44444, 0, 0, 0.51342],
    100: [0, 0.69444, 0, 0, 0.60972],
    101: [0, 0.44444, 0, 0, 0.55361],
    102: [0.19444, 0.69444, 0.11042, 0, 0.56806],
    103: [0.19444, 0.44444, 0.03704, 0, 0.5449],
    104: [0, 0.69444, 0, 0, 0.66759],
    105: [0, 0.69326, 0, 0, 0.4048],
    106: [0.19444, 0.69326, 0.0622, 0, 0.47083],
    107: [0, 0.69444, 0.01852, 0, 0.6037],
    108: [0, 0.69444, 88e-4, 0, 0.34815],
    109: [0, 0.44444, 0, 0, 1.0324],
    110: [0, 0.44444, 0, 0, 0.71296],
    111: [0, 0.44444, 0, 0, 0.58472],
    112: [0.19444, 0.44444, 0, 0, 0.60092],
    113: [0.19444, 0.44444, 0.03704, 0, 0.54213],
    114: [0, 0.44444, 0.03194, 0, 0.5287],
    115: [0, 0.44444, 0, 0, 0.53125],
    116: [0, 0.63492, 0, 0, 0.41528],
    117: [0, 0.44444, 0, 0, 0.68102],
    118: [0, 0.44444, 0.03704, 0, 0.56666],
    119: [0, 0.44444, 0.02778, 0, 0.83148],
    120: [0, 0.44444, 0, 0, 0.65903],
    121: [0.19444, 0.44444, 0.03704, 0, 0.59028],
    122: [0, 0.44444, 0.04213, 0, 0.55509],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68611, 0.15972, 0, 0.65694],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0.03194, 0, 0.86722],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0.07458, 0, 0.84125],
    928: [0, 0.68611, 0.08229, 0, 0.98229],
    931: [0, 0.68611, 0.05451, 0, 0.88507],
    933: [0, 0.68611, 0.15972, 0, 0.67083],
    934: [0, 0.68611, 0, 0, 0.76666],
    936: [0, 0.68611, 0.11653, 0, 0.71402],
    937: [0, 0.68611, 0.04835, 0, 0.8789],
    945: [0, 0.44444, 0, 0, 0.76064],
    946: [0.19444, 0.69444, 0.03403, 0, 0.65972],
    947: [0.19444, 0.44444, 0.06389, 0, 0.59003],
    948: [0, 0.69444, 0.03819, 0, 0.52222],
    949: [0, 0.44444, 0, 0, 0.52882],
    950: [0.19444, 0.69444, 0.06215, 0, 0.50833],
    951: [0.19444, 0.44444, 0.03704, 0, 0.6],
    952: [0, 0.69444, 0.03194, 0, 0.5618],
    953: [0, 0.44444, 0, 0, 0.41204],
    954: [0, 0.44444, 0, 0, 0.66759],
    955: [0, 0.69444, 0, 0, 0.67083],
    956: [0.19444, 0.44444, 0, 0, 0.70787],
    957: [0, 0.44444, 0.06898, 0, 0.57685],
    958: [0.19444, 0.69444, 0.03021, 0, 0.50833],
    959: [0, 0.44444, 0, 0, 0.58472],
    960: [0, 0.44444, 0.03704, 0, 0.68241],
    961: [0.19444, 0.44444, 0, 0, 0.6118],
    962: [0.09722, 0.44444, 0.07917, 0, 0.42361],
    963: [0, 0.44444, 0.03704, 0, 0.68588],
    964: [0, 0.44444, 0.13472, 0, 0.52083],
    965: [0, 0.44444, 0.03704, 0, 0.63055],
    966: [0.19444, 0.44444, 0, 0, 0.74722],
    967: [0.19444, 0.44444, 0, 0, 0.71805],
    968: [0.19444, 0.69444, 0.03704, 0, 0.75833],
    969: [0, 0.44444, 0.03704, 0, 0.71782],
    977: [0, 0.69444, 0, 0, 0.69155],
    981: [0.19444, 0.69444, 0, 0, 0.7125],
    982: [0, 0.44444, 0.03194, 0, 0.975],
    1009: [0.19444, 0.44444, 0, 0, 0.6118],
    1013: [0, 0.44444, 0, 0, 0.48333],
    57649: [0, 0.44444, 0, 0, 0.39352],
    57911: [0.19444, 0.44444, 0, 0, 0.43889]
  },
  "Math-Italic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.43056, 0, 0, 0.5],
    49: [0, 0.43056, 0, 0, 0.5],
    50: [0, 0.43056, 0, 0, 0.5],
    51: [0.19444, 0.43056, 0, 0, 0.5],
    52: [0.19444, 0.43056, 0, 0, 0.5],
    53: [0.19444, 0.43056, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0.19444, 0.43056, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0.19444, 0.43056, 0, 0, 0.5],
    65: [0, 0.68333, 0, 0.13889, 0.75],
    66: [0, 0.68333, 0.05017, 0.08334, 0.75851],
    67: [0, 0.68333, 0.07153, 0.08334, 0.71472],
    68: [0, 0.68333, 0.02778, 0.05556, 0.82792],
    69: [0, 0.68333, 0.05764, 0.08334, 0.7382],
    70: [0, 0.68333, 0.13889, 0.08334, 0.64306],
    71: [0, 0.68333, 0, 0.08334, 0.78625],
    72: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    73: [0, 0.68333, 0.07847, 0.11111, 0.43958],
    74: [0, 0.68333, 0.09618, 0.16667, 0.55451],
    75: [0, 0.68333, 0.07153, 0.05556, 0.84931],
    76: [0, 0.68333, 0, 0.02778, 0.68056],
    77: [0, 0.68333, 0.10903, 0.08334, 0.97014],
    78: [0, 0.68333, 0.10903, 0.08334, 0.80347],
    79: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    80: [0, 0.68333, 0.13889, 0.08334, 0.64201],
    81: [0.19444, 0.68333, 0, 0.08334, 0.79056],
    82: [0, 0.68333, 773e-5, 0.08334, 0.75929],
    83: [0, 0.68333, 0.05764, 0.08334, 0.6132],
    84: [0, 0.68333, 0.13889, 0.08334, 0.58438],
    85: [0, 0.68333, 0.10903, 0.02778, 0.68278],
    86: [0, 0.68333, 0.22222, 0, 0.58333],
    87: [0, 0.68333, 0.13889, 0, 0.94445],
    88: [0, 0.68333, 0.07847, 0.08334, 0.82847],
    89: [0, 0.68333, 0.22222, 0, 0.58056],
    90: [0, 0.68333, 0.07153, 0.08334, 0.68264],
    97: [0, 0.43056, 0, 0, 0.52859],
    98: [0, 0.69444, 0, 0, 0.42917],
    99: [0, 0.43056, 0, 0.05556, 0.43276],
    100: [0, 0.69444, 0, 0.16667, 0.52049],
    101: [0, 0.43056, 0, 0.05556, 0.46563],
    102: [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
    103: [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
    104: [0, 0.69444, 0, 0, 0.57616],
    105: [0, 0.65952, 0, 0, 0.34451],
    106: [0.19444, 0.65952, 0.05724, 0, 0.41181],
    107: [0, 0.69444, 0.03148, 0, 0.5206],
    108: [0, 0.69444, 0.01968, 0.08334, 0.29838],
    109: [0, 0.43056, 0, 0, 0.87801],
    110: [0, 0.43056, 0, 0, 0.60023],
    111: [0, 0.43056, 0, 0.05556, 0.48472],
    112: [0.19444, 0.43056, 0, 0.08334, 0.50313],
    113: [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
    114: [0, 0.43056, 0.02778, 0.05556, 0.45116],
    115: [0, 0.43056, 0, 0.05556, 0.46875],
    116: [0, 0.61508, 0, 0.08334, 0.36111],
    117: [0, 0.43056, 0, 0.02778, 0.57246],
    118: [0, 0.43056, 0.03588, 0.02778, 0.48472],
    119: [0, 0.43056, 0.02691, 0.08334, 0.71592],
    120: [0, 0.43056, 0, 0.02778, 0.57153],
    121: [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
    122: [0, 0.43056, 0.04398, 0.05556, 0.46505],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68333, 0.13889, 0.08334, 0.61528],
    916: [0, 0.68333, 0, 0.16667, 0.83334],
    920: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    923: [0, 0.68333, 0, 0.16667, 0.69445],
    926: [0, 0.68333, 0.07569, 0.08334, 0.74236],
    928: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    931: [0, 0.68333, 0.05764, 0.08334, 0.77986],
    933: [0, 0.68333, 0.13889, 0.05556, 0.58333],
    934: [0, 0.68333, 0, 0.08334, 0.66667],
    936: [0, 0.68333, 0.11, 0.05556, 0.61222],
    937: [0, 0.68333, 0.05017, 0.08334, 0.7724],
    945: [0, 0.43056, 37e-4, 0.02778, 0.6397],
    946: [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
    947: [0.19444, 0.43056, 0.05556, 0, 0.51773],
    948: [0, 0.69444, 0.03785, 0.05556, 0.44444],
    949: [0, 0.43056, 0, 0.08334, 0.46632],
    950: [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
    951: [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
    952: [0, 0.69444, 0.02778, 0.08334, 0.46944],
    953: [0, 0.43056, 0, 0.05556, 0.35394],
    954: [0, 0.43056, 0, 0, 0.57616],
    955: [0, 0.69444, 0, 0, 0.58334],
    956: [0.19444, 0.43056, 0, 0.02778, 0.60255],
    957: [0, 0.43056, 0.06366, 0.02778, 0.49398],
    958: [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
    959: [0, 0.43056, 0, 0.05556, 0.48472],
    960: [0, 0.43056, 0.03588, 0, 0.57003],
    961: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    962: [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
    963: [0, 0.43056, 0.03588, 0, 0.57141],
    964: [0, 0.43056, 0.1132, 0.02778, 0.43715],
    965: [0, 0.43056, 0.03588, 0.02778, 0.54028],
    966: [0.19444, 0.43056, 0, 0.08334, 0.65417],
    967: [0.19444, 0.43056, 0, 0.05556, 0.62569],
    968: [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
    969: [0, 0.43056, 0.03588, 0, 0.62245],
    977: [0, 0.69444, 0, 0.08334, 0.59144],
    981: [0.19444, 0.69444, 0, 0.08334, 0.59583],
    982: [0, 0.43056, 0.02778, 0, 0.82813],
    1009: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    1013: [0, 0.43056, 0, 0.05556, 0.4059],
    57649: [0, 0.43056, 0, 0.02778, 0.32246],
    57911: [0.19444, 0.43056, 0, 0.08334, 0.38403]
  },
  "SansSerif-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.36667],
    34: [0, 0.69444, 0, 0, 0.55834],
    35: [0.19444, 0.69444, 0, 0, 0.91667],
    36: [0.05556, 0.75, 0, 0, 0.55],
    37: [0.05556, 0.75, 0, 0, 1.02912],
    38: [0, 0.69444, 0, 0, 0.83056],
    39: [0, 0.69444, 0, 0, 0.30556],
    40: [0.25, 0.75, 0, 0, 0.42778],
    41: [0.25, 0.75, 0, 0, 0.42778],
    42: [0, 0.75, 0, 0, 0.55],
    43: [0.11667, 0.61667, 0, 0, 0.85556],
    44: [0.10556, 0.13056, 0, 0, 0.30556],
    45: [0, 0.45833, 0, 0, 0.36667],
    46: [0, 0.13056, 0, 0, 0.30556],
    47: [0.25, 0.75, 0, 0, 0.55],
    48: [0, 0.69444, 0, 0, 0.55],
    49: [0, 0.69444, 0, 0, 0.55],
    50: [0, 0.69444, 0, 0, 0.55],
    51: [0, 0.69444, 0, 0, 0.55],
    52: [0, 0.69444, 0, 0, 0.55],
    53: [0, 0.69444, 0, 0, 0.55],
    54: [0, 0.69444, 0, 0, 0.55],
    55: [0, 0.69444, 0, 0, 0.55],
    56: [0, 0.69444, 0, 0, 0.55],
    57: [0, 0.69444, 0, 0, 0.55],
    58: [0, 0.45833, 0, 0, 0.30556],
    59: [0.10556, 0.45833, 0, 0, 0.30556],
    61: [-0.09375, 0.40625, 0, 0, 0.85556],
    63: [0, 0.69444, 0, 0, 0.51945],
    64: [0, 0.69444, 0, 0, 0.73334],
    65: [0, 0.69444, 0, 0, 0.73334],
    66: [0, 0.69444, 0, 0, 0.73334],
    67: [0, 0.69444, 0, 0, 0.70278],
    68: [0, 0.69444, 0, 0, 0.79445],
    69: [0, 0.69444, 0, 0, 0.64167],
    70: [0, 0.69444, 0, 0, 0.61111],
    71: [0, 0.69444, 0, 0, 0.73334],
    72: [0, 0.69444, 0, 0, 0.79445],
    73: [0, 0.69444, 0, 0, 0.33056],
    74: [0, 0.69444, 0, 0, 0.51945],
    75: [0, 0.69444, 0, 0, 0.76389],
    76: [0, 0.69444, 0, 0, 0.58056],
    77: [0, 0.69444, 0, 0, 0.97778],
    78: [0, 0.69444, 0, 0, 0.79445],
    79: [0, 0.69444, 0, 0, 0.79445],
    80: [0, 0.69444, 0, 0, 0.70278],
    81: [0.10556, 0.69444, 0, 0, 0.79445],
    82: [0, 0.69444, 0, 0, 0.70278],
    83: [0, 0.69444, 0, 0, 0.61111],
    84: [0, 0.69444, 0, 0, 0.73334],
    85: [0, 0.69444, 0, 0, 0.76389],
    86: [0, 0.69444, 0.01528, 0, 0.73334],
    87: [0, 0.69444, 0.01528, 0, 1.03889],
    88: [0, 0.69444, 0, 0, 0.73334],
    89: [0, 0.69444, 0.0275, 0, 0.73334],
    90: [0, 0.69444, 0, 0, 0.67223],
    91: [0.25, 0.75, 0, 0, 0.34306],
    93: [0.25, 0.75, 0, 0, 0.34306],
    94: [0, 0.69444, 0, 0, 0.55],
    95: [0.35, 0.10833, 0.03056, 0, 0.55],
    97: [0, 0.45833, 0, 0, 0.525],
    98: [0, 0.69444, 0, 0, 0.56111],
    99: [0, 0.45833, 0, 0, 0.48889],
    100: [0, 0.69444, 0, 0, 0.56111],
    101: [0, 0.45833, 0, 0, 0.51111],
    102: [0, 0.69444, 0.07639, 0, 0.33611],
    103: [0.19444, 0.45833, 0.01528, 0, 0.55],
    104: [0, 0.69444, 0, 0, 0.56111],
    105: [0, 0.69444, 0, 0, 0.25556],
    106: [0.19444, 0.69444, 0, 0, 0.28611],
    107: [0, 0.69444, 0, 0, 0.53056],
    108: [0, 0.69444, 0, 0, 0.25556],
    109: [0, 0.45833, 0, 0, 0.86667],
    110: [0, 0.45833, 0, 0, 0.56111],
    111: [0, 0.45833, 0, 0, 0.55],
    112: [0.19444, 0.45833, 0, 0, 0.56111],
    113: [0.19444, 0.45833, 0, 0, 0.56111],
    114: [0, 0.45833, 0.01528, 0, 0.37222],
    115: [0, 0.45833, 0, 0, 0.42167],
    116: [0, 0.58929, 0, 0, 0.40417],
    117: [0, 0.45833, 0, 0, 0.56111],
    118: [0, 0.45833, 0.01528, 0, 0.5],
    119: [0, 0.45833, 0.01528, 0, 0.74445],
    120: [0, 0.45833, 0, 0, 0.5],
    121: [0.19444, 0.45833, 0.01528, 0, 0.5],
    122: [0, 0.45833, 0, 0, 0.47639],
    126: [0.35, 0.34444, 0, 0, 0.55],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0, 0, 0.55],
    176: [0, 0.69444, 0, 0, 0.73334],
    180: [0, 0.69444, 0, 0, 0.55],
    184: [0.17014, 0, 0, 0, 0.48889],
    305: [0, 0.45833, 0, 0, 0.25556],
    567: [0.19444, 0.45833, 0, 0, 0.28611],
    710: [0, 0.69444, 0, 0, 0.55],
    711: [0, 0.63542, 0, 0, 0.55],
    713: [0, 0.63778, 0, 0, 0.55],
    728: [0, 0.69444, 0, 0, 0.55],
    729: [0, 0.69444, 0, 0, 0.30556],
    730: [0, 0.69444, 0, 0, 0.73334],
    732: [0, 0.69444, 0, 0, 0.55],
    733: [0, 0.69444, 0, 0, 0.55],
    915: [0, 0.69444, 0, 0, 0.58056],
    916: [0, 0.69444, 0, 0, 0.91667],
    920: [0, 0.69444, 0, 0, 0.85556],
    923: [0, 0.69444, 0, 0, 0.67223],
    926: [0, 0.69444, 0, 0, 0.73334],
    928: [0, 0.69444, 0, 0, 0.79445],
    931: [0, 0.69444, 0, 0, 0.79445],
    933: [0, 0.69444, 0, 0, 0.85556],
    934: [0, 0.69444, 0, 0, 0.79445],
    936: [0, 0.69444, 0, 0, 0.85556],
    937: [0, 0.69444, 0, 0, 0.79445],
    8211: [0, 0.45833, 0.03056, 0, 0.55],
    8212: [0, 0.45833, 0.03056, 0, 1.10001],
    8216: [0, 0.69444, 0, 0, 0.30556],
    8217: [0, 0.69444, 0, 0, 0.30556],
    8220: [0, 0.69444, 0, 0, 0.55834],
    8221: [0, 0.69444, 0, 0, 0.55834]
  },
  "SansSerif-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.05733, 0, 0.31945],
    34: [0, 0.69444, 316e-5, 0, 0.5],
    35: [0.19444, 0.69444, 0.05087, 0, 0.83334],
    36: [0.05556, 0.75, 0.11156, 0, 0.5],
    37: [0.05556, 0.75, 0.03126, 0, 0.83334],
    38: [0, 0.69444, 0.03058, 0, 0.75834],
    39: [0, 0.69444, 0.07816, 0, 0.27778],
    40: [0.25, 0.75, 0.13164, 0, 0.38889],
    41: [0.25, 0.75, 0.02536, 0, 0.38889],
    42: [0, 0.75, 0.11775, 0, 0.5],
    43: [0.08333, 0.58333, 0.02536, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0.01946, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0.13164, 0, 0.5],
    48: [0, 0.65556, 0.11156, 0, 0.5],
    49: [0, 0.65556, 0.11156, 0, 0.5],
    50: [0, 0.65556, 0.11156, 0, 0.5],
    51: [0, 0.65556, 0.11156, 0, 0.5],
    52: [0, 0.65556, 0.11156, 0, 0.5],
    53: [0, 0.65556, 0.11156, 0, 0.5],
    54: [0, 0.65556, 0.11156, 0, 0.5],
    55: [0, 0.65556, 0.11156, 0, 0.5],
    56: [0, 0.65556, 0.11156, 0, 0.5],
    57: [0, 0.65556, 0.11156, 0, 0.5],
    58: [0, 0.44444, 0.02502, 0, 0.27778],
    59: [0.125, 0.44444, 0.02502, 0, 0.27778],
    61: [-0.13, 0.37, 0.05087, 0, 0.77778],
    63: [0, 0.69444, 0.11809, 0, 0.47222],
    64: [0, 0.69444, 0.07555, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0.08293, 0, 0.66667],
    67: [0, 0.69444, 0.11983, 0, 0.63889],
    68: [0, 0.69444, 0.07555, 0, 0.72223],
    69: [0, 0.69444, 0.11983, 0, 0.59722],
    70: [0, 0.69444, 0.13372, 0, 0.56945],
    71: [0, 0.69444, 0.11983, 0, 0.66667],
    72: [0, 0.69444, 0.08094, 0, 0.70834],
    73: [0, 0.69444, 0.13372, 0, 0.27778],
    74: [0, 0.69444, 0.08094, 0, 0.47222],
    75: [0, 0.69444, 0.11983, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0.08094, 0, 0.875],
    78: [0, 0.69444, 0.08094, 0, 0.70834],
    79: [0, 0.69444, 0.07555, 0, 0.73611],
    80: [0, 0.69444, 0.08293, 0, 0.63889],
    81: [0.125, 0.69444, 0.07555, 0, 0.73611],
    82: [0, 0.69444, 0.08293, 0, 0.64584],
    83: [0, 0.69444, 0.09205, 0, 0.55556],
    84: [0, 0.69444, 0.13372, 0, 0.68056],
    85: [0, 0.69444, 0.08094, 0, 0.6875],
    86: [0, 0.69444, 0.1615, 0, 0.66667],
    87: [0, 0.69444, 0.1615, 0, 0.94445],
    88: [0, 0.69444, 0.13372, 0, 0.66667],
    89: [0, 0.69444, 0.17261, 0, 0.66667],
    90: [0, 0.69444, 0.11983, 0, 0.61111],
    91: [0.25, 0.75, 0.15942, 0, 0.28889],
    93: [0.25, 0.75, 0.08719, 0, 0.28889],
    94: [0, 0.69444, 0.0799, 0, 0.5],
    95: [0.35, 0.09444, 0.08616, 0, 0.5],
    97: [0, 0.44444, 981e-5, 0, 0.48056],
    98: [0, 0.69444, 0.03057, 0, 0.51667],
    99: [0, 0.44444, 0.08336, 0, 0.44445],
    100: [0, 0.69444, 0.09483, 0, 0.51667],
    101: [0, 0.44444, 0.06778, 0, 0.44445],
    102: [0, 0.69444, 0.21705, 0, 0.30556],
    103: [0.19444, 0.44444, 0.10836, 0, 0.5],
    104: [0, 0.69444, 0.01778, 0, 0.51667],
    105: [0, 0.67937, 0.09718, 0, 0.23889],
    106: [0.19444, 0.67937, 0.09162, 0, 0.26667],
    107: [0, 0.69444, 0.08336, 0, 0.48889],
    108: [0, 0.69444, 0.09483, 0, 0.23889],
    109: [0, 0.44444, 0.01778, 0, 0.79445],
    110: [0, 0.44444, 0.01778, 0, 0.51667],
    111: [0, 0.44444, 0.06613, 0, 0.5],
    112: [0.19444, 0.44444, 0.0389, 0, 0.51667],
    113: [0.19444, 0.44444, 0.04169, 0, 0.51667],
    114: [0, 0.44444, 0.10836, 0, 0.34167],
    115: [0, 0.44444, 0.0778, 0, 0.38333],
    116: [0, 0.57143, 0.07225, 0, 0.36111],
    117: [0, 0.44444, 0.04169, 0, 0.51667],
    118: [0, 0.44444, 0.10836, 0, 0.46111],
    119: [0, 0.44444, 0.10836, 0, 0.68334],
    120: [0, 0.44444, 0.09169, 0, 0.46111],
    121: [0.19444, 0.44444, 0.10836, 0, 0.46111],
    122: [0, 0.44444, 0.08752, 0, 0.43472],
    126: [0.35, 0.32659, 0.08826, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0.06385, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.73752],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0.04169, 0, 0.23889],
    567: [0.19444, 0.44444, 0.04169, 0, 0.26667],
    710: [0, 0.69444, 0.0799, 0, 0.5],
    711: [0, 0.63194, 0.08432, 0, 0.5],
    713: [0, 0.60889, 0.08776, 0, 0.5],
    714: [0, 0.69444, 0.09205, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0.09483, 0, 0.5],
    729: [0, 0.67937, 0.07774, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.73752],
    732: [0, 0.67659, 0.08826, 0, 0.5],
    733: [0, 0.69444, 0.09205, 0, 0.5],
    915: [0, 0.69444, 0.13372, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0.07555, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0.12816, 0, 0.66667],
    928: [0, 0.69444, 0.08094, 0, 0.70834],
    931: [0, 0.69444, 0.11983, 0, 0.72222],
    933: [0, 0.69444, 0.09031, 0, 0.77778],
    934: [0, 0.69444, 0.04603, 0, 0.72222],
    936: [0, 0.69444, 0.09031, 0, 0.77778],
    937: [0, 0.69444, 0.08293, 0, 0.72222],
    8211: [0, 0.44444, 0.08616, 0, 0.5],
    8212: [0, 0.44444, 0.08616, 0, 1],
    8216: [0, 0.69444, 0.07816, 0, 0.27778],
    8217: [0, 0.69444, 0.07816, 0, 0.27778],
    8220: [0, 0.69444, 0.14205, 0, 0.5],
    8221: [0, 0.69444, 316e-5, 0, 0.5]
  },
  "SansSerif-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.31945],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.75834],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.65556, 0, 0, 0.5],
    49: [0, 0.65556, 0, 0, 0.5],
    50: [0, 0.65556, 0, 0, 0.5],
    51: [0, 0.65556, 0, 0, 0.5],
    52: [0, 0.65556, 0, 0, 0.5],
    53: [0, 0.65556, 0, 0, 0.5],
    54: [0, 0.65556, 0, 0, 0.5],
    55: [0, 0.65556, 0, 0, 0.5],
    56: [0, 0.65556, 0, 0, 0.5],
    57: [0, 0.65556, 0, 0, 0.5],
    58: [0, 0.44444, 0, 0, 0.27778],
    59: [0.125, 0.44444, 0, 0, 0.27778],
    61: [-0.13, 0.37, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0, 0, 0.66667],
    67: [0, 0.69444, 0, 0, 0.63889],
    68: [0, 0.69444, 0, 0, 0.72223],
    69: [0, 0.69444, 0, 0, 0.59722],
    70: [0, 0.69444, 0, 0, 0.56945],
    71: [0, 0.69444, 0, 0, 0.66667],
    72: [0, 0.69444, 0, 0, 0.70834],
    73: [0, 0.69444, 0, 0, 0.27778],
    74: [0, 0.69444, 0, 0, 0.47222],
    75: [0, 0.69444, 0, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0, 0, 0.875],
    78: [0, 0.69444, 0, 0, 0.70834],
    79: [0, 0.69444, 0, 0, 0.73611],
    80: [0, 0.69444, 0, 0, 0.63889],
    81: [0.125, 0.69444, 0, 0, 0.73611],
    82: [0, 0.69444, 0, 0, 0.64584],
    83: [0, 0.69444, 0, 0, 0.55556],
    84: [0, 0.69444, 0, 0, 0.68056],
    85: [0, 0.69444, 0, 0, 0.6875],
    86: [0, 0.69444, 0.01389, 0, 0.66667],
    87: [0, 0.69444, 0.01389, 0, 0.94445],
    88: [0, 0.69444, 0, 0, 0.66667],
    89: [0, 0.69444, 0.025, 0, 0.66667],
    90: [0, 0.69444, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.28889],
    93: [0.25, 0.75, 0, 0, 0.28889],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.35, 0.09444, 0.02778, 0, 0.5],
    97: [0, 0.44444, 0, 0, 0.48056],
    98: [0, 0.69444, 0, 0, 0.51667],
    99: [0, 0.44444, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.51667],
    101: [0, 0.44444, 0, 0, 0.44445],
    102: [0, 0.69444, 0.06944, 0, 0.30556],
    103: [0.19444, 0.44444, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.51667],
    105: [0, 0.67937, 0, 0, 0.23889],
    106: [0.19444, 0.67937, 0, 0, 0.26667],
    107: [0, 0.69444, 0, 0, 0.48889],
    108: [0, 0.69444, 0, 0, 0.23889],
    109: [0, 0.44444, 0, 0, 0.79445],
    110: [0, 0.44444, 0, 0, 0.51667],
    111: [0, 0.44444, 0, 0, 0.5],
    112: [0.19444, 0.44444, 0, 0, 0.51667],
    113: [0.19444, 0.44444, 0, 0, 0.51667],
    114: [0, 0.44444, 0.01389, 0, 0.34167],
    115: [0, 0.44444, 0, 0, 0.38333],
    116: [0, 0.57143, 0, 0, 0.36111],
    117: [0, 0.44444, 0, 0, 0.51667],
    118: [0, 0.44444, 0.01389, 0, 0.46111],
    119: [0, 0.44444, 0.01389, 0, 0.68334],
    120: [0, 0.44444, 0, 0, 0.46111],
    121: [0.19444, 0.44444, 0.01389, 0, 0.46111],
    122: [0, 0.44444, 0, 0, 0.43472],
    126: [0.35, 0.32659, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.66667],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0, 0, 0.23889],
    567: [0.19444, 0.44444, 0, 0, 0.26667],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.63194, 0, 0, 0.5],
    713: [0, 0.60889, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.67937, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.66667],
    732: [0, 0.67659, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.69444, 0, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0, 0, 0.66667],
    928: [0, 0.69444, 0, 0, 0.70834],
    931: [0, 0.69444, 0, 0, 0.72222],
    933: [0, 0.69444, 0, 0, 0.77778],
    934: [0, 0.69444, 0, 0, 0.72222],
    936: [0, 0.69444, 0, 0, 0.77778],
    937: [0, 0.69444, 0, 0, 0.72222],
    8211: [0, 0.44444, 0.02778, 0, 0.5],
    8212: [0, 0.44444, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5]
  },
  "Script-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.7, 0.22925, 0, 0.80253],
    66: [0, 0.7, 0.04087, 0, 0.90757],
    67: [0, 0.7, 0.1689, 0, 0.66619],
    68: [0, 0.7, 0.09371, 0, 0.77443],
    69: [0, 0.7, 0.18583, 0, 0.56162],
    70: [0, 0.7, 0.13634, 0, 0.89544],
    71: [0, 0.7, 0.17322, 0, 0.60961],
    72: [0, 0.7, 0.29694, 0, 0.96919],
    73: [0, 0.7, 0.19189, 0, 0.80907],
    74: [0.27778, 0.7, 0.19189, 0, 1.05159],
    75: [0, 0.7, 0.31259, 0, 0.91364],
    76: [0, 0.7, 0.19189, 0, 0.87373],
    77: [0, 0.7, 0.15981, 0, 1.08031],
    78: [0, 0.7, 0.3525, 0, 0.9015],
    79: [0, 0.7, 0.08078, 0, 0.73787],
    80: [0, 0.7, 0.08078, 0, 1.01262],
    81: [0, 0.7, 0.03305, 0, 0.88282],
    82: [0, 0.7, 0.06259, 0, 0.85],
    83: [0, 0.7, 0.19189, 0, 0.86767],
    84: [0, 0.7, 0.29087, 0, 0.74697],
    85: [0, 0.7, 0.25815, 0, 0.79996],
    86: [0, 0.7, 0.27523, 0, 0.62204],
    87: [0, 0.7, 0.27523, 0, 0.80532],
    88: [0, 0.7, 0.26006, 0, 0.94445],
    89: [0, 0.7, 0.2939, 0, 0.70961],
    90: [0, 0.7, 0.24037, 0, 0.8212],
    160: [0, 0, 0, 0, 0.25]
  },
  "Size1-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.35001, 0.85, 0, 0, 0.45834],
    41: [0.35001, 0.85, 0, 0, 0.45834],
    47: [0.35001, 0.85, 0, 0, 0.57778],
    91: [0.35001, 0.85, 0, 0, 0.41667],
    92: [0.35001, 0.85, 0, 0, 0.57778],
    93: [0.35001, 0.85, 0, 0, 0.41667],
    123: [0.35001, 0.85, 0, 0, 0.58334],
    125: [0.35001, 0.85, 0, 0, 0.58334],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.72222, 0, 0, 0.55556],
    732: [0, 0.72222, 0, 0, 0.55556],
    770: [0, 0.72222, 0, 0, 0.55556],
    771: [0, 0.72222, 0, 0, 0.55556],
    8214: [-99e-5, 0.601, 0, 0, 0.77778],
    8593: [1e-5, 0.6, 0, 0, 0.66667],
    8595: [1e-5, 0.6, 0, 0, 0.66667],
    8657: [1e-5, 0.6, 0, 0, 0.77778],
    8659: [1e-5, 0.6, 0, 0, 0.77778],
    8719: [0.25001, 0.75, 0, 0, 0.94445],
    8720: [0.25001, 0.75, 0, 0, 0.94445],
    8721: [0.25001, 0.75, 0, 0, 1.05556],
    8730: [0.35001, 0.85, 0, 0, 1],
    8739: [-599e-5, 0.606, 0, 0, 0.33333],
    8741: [-599e-5, 0.606, 0, 0, 0.55556],
    8747: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8748: [0.306, 0.805, 0.19445, 0, 0.47222],
    8749: [0.306, 0.805, 0.19445, 0, 0.47222],
    8750: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8896: [0.25001, 0.75, 0, 0, 0.83334],
    8897: [0.25001, 0.75, 0, 0, 0.83334],
    8898: [0.25001, 0.75, 0, 0, 0.83334],
    8899: [0.25001, 0.75, 0, 0, 0.83334],
    8968: [0.35001, 0.85, 0, 0, 0.47222],
    8969: [0.35001, 0.85, 0, 0, 0.47222],
    8970: [0.35001, 0.85, 0, 0, 0.47222],
    8971: [0.35001, 0.85, 0, 0, 0.47222],
    9168: [-99e-5, 0.601, 0, 0, 0.66667],
    10216: [0.35001, 0.85, 0, 0, 0.47222],
    10217: [0.35001, 0.85, 0, 0, 0.47222],
    10752: [0.25001, 0.75, 0, 0, 1.11111],
    10753: [0.25001, 0.75, 0, 0, 1.11111],
    10754: [0.25001, 0.75, 0, 0, 1.11111],
    10756: [0.25001, 0.75, 0, 0, 0.83334],
    10758: [0.25001, 0.75, 0, 0, 0.83334]
  },
  "Size2-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.65002, 1.15, 0, 0, 0.59722],
    41: [0.65002, 1.15, 0, 0, 0.59722],
    47: [0.65002, 1.15, 0, 0, 0.81111],
    91: [0.65002, 1.15, 0, 0, 0.47222],
    92: [0.65002, 1.15, 0, 0, 0.81111],
    93: [0.65002, 1.15, 0, 0, 0.47222],
    123: [0.65002, 1.15, 0, 0, 0.66667],
    125: [0.65002, 1.15, 0, 0, 0.66667],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1],
    732: [0, 0.75, 0, 0, 1],
    770: [0, 0.75, 0, 0, 1],
    771: [0, 0.75, 0, 0, 1],
    8719: [0.55001, 1.05, 0, 0, 1.27778],
    8720: [0.55001, 1.05, 0, 0, 1.27778],
    8721: [0.55001, 1.05, 0, 0, 1.44445],
    8730: [0.65002, 1.15, 0, 0, 1],
    8747: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8748: [0.862, 1.36, 0.44445, 0, 0.55556],
    8749: [0.862, 1.36, 0.44445, 0, 0.55556],
    8750: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8896: [0.55001, 1.05, 0, 0, 1.11111],
    8897: [0.55001, 1.05, 0, 0, 1.11111],
    8898: [0.55001, 1.05, 0, 0, 1.11111],
    8899: [0.55001, 1.05, 0, 0, 1.11111],
    8968: [0.65002, 1.15, 0, 0, 0.52778],
    8969: [0.65002, 1.15, 0, 0, 0.52778],
    8970: [0.65002, 1.15, 0, 0, 0.52778],
    8971: [0.65002, 1.15, 0, 0, 0.52778],
    10216: [0.65002, 1.15, 0, 0, 0.61111],
    10217: [0.65002, 1.15, 0, 0, 0.61111],
    10752: [0.55001, 1.05, 0, 0, 1.51112],
    10753: [0.55001, 1.05, 0, 0, 1.51112],
    10754: [0.55001, 1.05, 0, 0, 1.51112],
    10756: [0.55001, 1.05, 0, 0, 1.11111],
    10758: [0.55001, 1.05, 0, 0, 1.11111]
  },
  "Size3-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.95003, 1.45, 0, 0, 0.73611],
    41: [0.95003, 1.45, 0, 0, 0.73611],
    47: [0.95003, 1.45, 0, 0, 1.04445],
    91: [0.95003, 1.45, 0, 0, 0.52778],
    92: [0.95003, 1.45, 0, 0, 1.04445],
    93: [0.95003, 1.45, 0, 0, 0.52778],
    123: [0.95003, 1.45, 0, 0, 0.75],
    125: [0.95003, 1.45, 0, 0, 0.75],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1.44445],
    732: [0, 0.75, 0, 0, 1.44445],
    770: [0, 0.75, 0, 0, 1.44445],
    771: [0, 0.75, 0, 0, 1.44445],
    8730: [0.95003, 1.45, 0, 0, 1],
    8968: [0.95003, 1.45, 0, 0, 0.58334],
    8969: [0.95003, 1.45, 0, 0, 0.58334],
    8970: [0.95003, 1.45, 0, 0, 0.58334],
    8971: [0.95003, 1.45, 0, 0, 0.58334],
    10216: [0.95003, 1.45, 0, 0, 0.75],
    10217: [0.95003, 1.45, 0, 0, 0.75]
  },
  "Size4-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [1.25003, 1.75, 0, 0, 0.79167],
    41: [1.25003, 1.75, 0, 0, 0.79167],
    47: [1.25003, 1.75, 0, 0, 1.27778],
    91: [1.25003, 1.75, 0, 0, 0.58334],
    92: [1.25003, 1.75, 0, 0, 1.27778],
    93: [1.25003, 1.75, 0, 0, 0.58334],
    123: [1.25003, 1.75, 0, 0, 0.80556],
    125: [1.25003, 1.75, 0, 0, 0.80556],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.825, 0, 0, 1.8889],
    732: [0, 0.825, 0, 0, 1.8889],
    770: [0, 0.825, 0, 0, 1.8889],
    771: [0, 0.825, 0, 0, 1.8889],
    8730: [1.25003, 1.75, 0, 0, 1],
    8968: [1.25003, 1.75, 0, 0, 0.63889],
    8969: [1.25003, 1.75, 0, 0, 0.63889],
    8970: [1.25003, 1.75, 0, 0, 0.63889],
    8971: [1.25003, 1.75, 0, 0, 0.63889],
    9115: [0.64502, 1.155, 0, 0, 0.875],
    9116: [1e-5, 0.6, 0, 0, 0.875],
    9117: [0.64502, 1.155, 0, 0, 0.875],
    9118: [0.64502, 1.155, 0, 0, 0.875],
    9119: [1e-5, 0.6, 0, 0, 0.875],
    9120: [0.64502, 1.155, 0, 0, 0.875],
    9121: [0.64502, 1.155, 0, 0, 0.66667],
    9122: [-99e-5, 0.601, 0, 0, 0.66667],
    9123: [0.64502, 1.155, 0, 0, 0.66667],
    9124: [0.64502, 1.155, 0, 0, 0.66667],
    9125: [-99e-5, 0.601, 0, 0, 0.66667],
    9126: [0.64502, 1.155, 0, 0, 0.66667],
    9127: [1e-5, 0.9, 0, 0, 0.88889],
    9128: [0.65002, 1.15, 0, 0, 0.88889],
    9129: [0.90001, 0, 0, 0, 0.88889],
    9130: [0, 0.3, 0, 0, 0.88889],
    9131: [1e-5, 0.9, 0, 0, 0.88889],
    9132: [0.65002, 1.15, 0, 0, 0.88889],
    9133: [0.90001, 0, 0, 0, 0.88889],
    9143: [0.88502, 0.915, 0, 0, 1.05556],
    10216: [1.25003, 1.75, 0, 0, 0.80556],
    10217: [1.25003, 1.75, 0, 0, 0.80556],
    57344: [-499e-5, 0.605, 0, 0, 1.05556],
    57345: [-499e-5, 0.605, 0, 0, 1.05556],
    57680: [0, 0.12, 0, 0, 0.45],
    57681: [0, 0.12, 0, 0, 0.45],
    57682: [0, 0.12, 0, 0, 0.45],
    57683: [0, 0.12, 0, 0, 0.45]
  },
  "Typewriter-Regular": {
    32: [0, 0, 0, 0, 0.525],
    33: [0, 0.61111, 0, 0, 0.525],
    34: [0, 0.61111, 0, 0, 0.525],
    35: [0, 0.61111, 0, 0, 0.525],
    36: [0.08333, 0.69444, 0, 0, 0.525],
    37: [0.08333, 0.69444, 0, 0, 0.525],
    38: [0, 0.61111, 0, 0, 0.525],
    39: [0, 0.61111, 0, 0, 0.525],
    40: [0.08333, 0.69444, 0, 0, 0.525],
    41: [0.08333, 0.69444, 0, 0, 0.525],
    42: [0, 0.52083, 0, 0, 0.525],
    43: [-0.08056, 0.53055, 0, 0, 0.525],
    44: [0.13889, 0.125, 0, 0, 0.525],
    45: [-0.08056, 0.53055, 0, 0, 0.525],
    46: [0, 0.125, 0, 0, 0.525],
    47: [0.08333, 0.69444, 0, 0, 0.525],
    48: [0, 0.61111, 0, 0, 0.525],
    49: [0, 0.61111, 0, 0, 0.525],
    50: [0, 0.61111, 0, 0, 0.525],
    51: [0, 0.61111, 0, 0, 0.525],
    52: [0, 0.61111, 0, 0, 0.525],
    53: [0, 0.61111, 0, 0, 0.525],
    54: [0, 0.61111, 0, 0, 0.525],
    55: [0, 0.61111, 0, 0, 0.525],
    56: [0, 0.61111, 0, 0, 0.525],
    57: [0, 0.61111, 0, 0, 0.525],
    58: [0, 0.43056, 0, 0, 0.525],
    59: [0.13889, 0.43056, 0, 0, 0.525],
    60: [-0.05556, 0.55556, 0, 0, 0.525],
    61: [-0.19549, 0.41562, 0, 0, 0.525],
    62: [-0.05556, 0.55556, 0, 0, 0.525],
    63: [0, 0.61111, 0, 0, 0.525],
    64: [0, 0.61111, 0, 0, 0.525],
    65: [0, 0.61111, 0, 0, 0.525],
    66: [0, 0.61111, 0, 0, 0.525],
    67: [0, 0.61111, 0, 0, 0.525],
    68: [0, 0.61111, 0, 0, 0.525],
    69: [0, 0.61111, 0, 0, 0.525],
    70: [0, 0.61111, 0, 0, 0.525],
    71: [0, 0.61111, 0, 0, 0.525],
    72: [0, 0.61111, 0, 0, 0.525],
    73: [0, 0.61111, 0, 0, 0.525],
    74: [0, 0.61111, 0, 0, 0.525],
    75: [0, 0.61111, 0, 0, 0.525],
    76: [0, 0.61111, 0, 0, 0.525],
    77: [0, 0.61111, 0, 0, 0.525],
    78: [0, 0.61111, 0, 0, 0.525],
    79: [0, 0.61111, 0, 0, 0.525],
    80: [0, 0.61111, 0, 0, 0.525],
    81: [0.13889, 0.61111, 0, 0, 0.525],
    82: [0, 0.61111, 0, 0, 0.525],
    83: [0, 0.61111, 0, 0, 0.525],
    84: [0, 0.61111, 0, 0, 0.525],
    85: [0, 0.61111, 0, 0, 0.525],
    86: [0, 0.61111, 0, 0, 0.525],
    87: [0, 0.61111, 0, 0, 0.525],
    88: [0, 0.61111, 0, 0, 0.525],
    89: [0, 0.61111, 0, 0, 0.525],
    90: [0, 0.61111, 0, 0, 0.525],
    91: [0.08333, 0.69444, 0, 0, 0.525],
    92: [0.08333, 0.69444, 0, 0, 0.525],
    93: [0.08333, 0.69444, 0, 0, 0.525],
    94: [0, 0.61111, 0, 0, 0.525],
    95: [0.09514, 0, 0, 0, 0.525],
    96: [0, 0.61111, 0, 0, 0.525],
    97: [0, 0.43056, 0, 0, 0.525],
    98: [0, 0.61111, 0, 0, 0.525],
    99: [0, 0.43056, 0, 0, 0.525],
    100: [0, 0.61111, 0, 0, 0.525],
    101: [0, 0.43056, 0, 0, 0.525],
    102: [0, 0.61111, 0, 0, 0.525],
    103: [0.22222, 0.43056, 0, 0, 0.525],
    104: [0, 0.61111, 0, 0, 0.525],
    105: [0, 0.61111, 0, 0, 0.525],
    106: [0.22222, 0.61111, 0, 0, 0.525],
    107: [0, 0.61111, 0, 0, 0.525],
    108: [0, 0.61111, 0, 0, 0.525],
    109: [0, 0.43056, 0, 0, 0.525],
    110: [0, 0.43056, 0, 0, 0.525],
    111: [0, 0.43056, 0, 0, 0.525],
    112: [0.22222, 0.43056, 0, 0, 0.525],
    113: [0.22222, 0.43056, 0, 0, 0.525],
    114: [0, 0.43056, 0, 0, 0.525],
    115: [0, 0.43056, 0, 0, 0.525],
    116: [0, 0.55358, 0, 0, 0.525],
    117: [0, 0.43056, 0, 0, 0.525],
    118: [0, 0.43056, 0, 0, 0.525],
    119: [0, 0.43056, 0, 0, 0.525],
    120: [0, 0.43056, 0, 0, 0.525],
    121: [0.22222, 0.43056, 0, 0, 0.525],
    122: [0, 0.43056, 0, 0, 0.525],
    123: [0.08333, 0.69444, 0, 0, 0.525],
    124: [0.08333, 0.69444, 0, 0, 0.525],
    125: [0.08333, 0.69444, 0, 0, 0.525],
    126: [0, 0.61111, 0, 0, 0.525],
    127: [0, 0.61111, 0, 0, 0.525],
    160: [0, 0, 0, 0, 0.525],
    176: [0, 0.61111, 0, 0, 0.525],
    184: [0.19445, 0, 0, 0, 0.525],
    305: [0, 0.43056, 0, 0, 0.525],
    567: [0.22222, 0.43056, 0, 0, 0.525],
    711: [0, 0.56597, 0, 0, 0.525],
    713: [0, 0.56555, 0, 0, 0.525],
    714: [0, 0.61111, 0, 0, 0.525],
    715: [0, 0.61111, 0, 0, 0.525],
    728: [0, 0.61111, 0, 0, 0.525],
    730: [0, 0.61111, 0, 0, 0.525],
    770: [0, 0.61111, 0, 0, 0.525],
    771: [0, 0.61111, 0, 0, 0.525],
    776: [0, 0.61111, 0, 0, 0.525],
    915: [0, 0.61111, 0, 0, 0.525],
    916: [0, 0.61111, 0, 0, 0.525],
    920: [0, 0.61111, 0, 0, 0.525],
    923: [0, 0.61111, 0, 0, 0.525],
    926: [0, 0.61111, 0, 0, 0.525],
    928: [0, 0.61111, 0, 0, 0.525],
    931: [0, 0.61111, 0, 0, 0.525],
    933: [0, 0.61111, 0, 0, 0.525],
    934: [0, 0.61111, 0, 0, 0.525],
    936: [0, 0.61111, 0, 0, 0.525],
    937: [0, 0.61111, 0, 0, 0.525],
    8216: [0, 0.61111, 0, 0, 0.525],
    8217: [0, 0.61111, 0, 0, 0.525],
    8242: [0, 0.61111, 0, 0, 0.525],
    9251: [0.11111, 0.21944, 0, 0, 0.525]
  }
}, fn = {
  // Latin-1
  Å: "A",
  Ð: "D",
  Þ: "o",
  å: "a",
  ð: "d",
  þ: "o",
  // Cyrillic
  А: "A",
  Б: "B",
  В: "B",
  Г: "F",
  Д: "A",
  Е: "E",
  Ж: "K",
  З: "3",
  И: "N",
  Й: "N",
  К: "K",
  Л: "N",
  М: "M",
  Н: "H",
  О: "O",
  П: "N",
  Р: "P",
  С: "C",
  Т: "T",
  У: "y",
  Ф: "O",
  Х: "X",
  Ц: "U",
  Ч: "h",
  Ш: "W",
  Щ: "W",
  Ъ: "B",
  Ы: "X",
  Ь: "B",
  Э: "3",
  Ю: "X",
  Я: "R",
  а: "a",
  б: "b",
  в: "a",
  г: "r",
  д: "y",
  е: "e",
  ж: "m",
  з: "e",
  и: "n",
  й: "n",
  к: "n",
  л: "n",
  м: "m",
  н: "n",
  о: "o",
  п: "n",
  р: "p",
  с: "c",
  т: "o",
  у: "y",
  ф: "b",
  х: "x",
  ц: "n",
  ч: "n",
  ш: "w",
  щ: "w",
  ъ: "a",
  ы: "m",
  ь: "a",
  э: "e",
  ю: "m",
  я: "r"
};
function Fa(r, e, t) {
  if (!j0[e])
    throw new Error("Font metrics not found for font: " + e + ".");
  var a = r.charCodeAt(0), n = j0[e][a];
  if (!n && r[0] in fn && (a = fn[r[0]].charCodeAt(0), n = j0[e][a]), !n && t === "text" && Ss(a) && (n = j0[e][77]), n)
    return {
      depth: n[0],
      height: n[1],
      italic: n[2],
      skew: n[3],
      width: n[4]
    };
}
var pa = {
  // https://en.wikibooks.org/wiki/LaTeX/Lengths and
  // https://tex.stackexchange.com/a/8263
  pt: 1,
  // TeX point
  mm: 7227 / 2540,
  // millimeter
  cm: 7227 / 254,
  // centimeter
  in: 72.27,
  // inch
  bp: 803 / 800,
  // big (PostScript) points
  pc: 12,
  // pica
  dd: 1238 / 1157,
  // didot
  cc: 14856 / 1157,
  // cicero (12 didot)
  nd: 685 / 642,
  // new didot
  nc: 1370 / 107,
  // new cicero (12 new didot)
  sp: 1 / 65536,
  // scaled point (TeX's internal smallest unit)
  // https://tex.stackexchange.com/a/41371
  px: 803 / 800
  // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
}, Is = {
  ex: !0,
  em: !0,
  mu: !0
}, Ls = function(e) {
  return typeof e != "string" && (e = e.unit), e in pa || e in Is || e === "ex";
}, ze = function(e, t) {
  var a;
  if (e.unit in pa)
    a = pa[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
  else if (e.unit === "mu")
    a = t.fontMetrics().cssEmPerMu;
  else {
    var n;
    if (t.style.isTight() ? n = t.havingStyle(t.style.text()) : n = t, e.unit === "ex")
      a = n.fontMetrics().xHeight;
    else if (e.unit === "em")
      a = n.fontMetrics().quad;
    else
      throw new W("Invalid unit: '" + e.unit + "'");
    n !== t && (a *= n.sizeMultiplier / t.sizeMultiplier);
  }
  return Math.min(e.number * a, t.maxSize);
}, q = function(e) {
  return +e.toFixed(4) + "em";
}, at = function(e) {
  return e.filter((t) => t).join(" ");
}, Ri = function(e, t, a) {
  if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = a || {}, t) {
    t.style.isTight() && this.classes.push("mtight");
    var n = t.getColor();
    n && (this.style.color = n);
  }
}, Ni = function(e) {
  var t = document.createElement(e);
  t.className = at(this.classes);
  for (var a in this.style)
    this.style.hasOwnProperty(a) && (t.style[a] = this.style[a]);
  for (var n in this.attributes)
    this.attributes.hasOwnProperty(n) && t.setAttribute(n, this.attributes[n]);
  for (var i = 0; i < this.children.length; i++)
    t.appendChild(this.children[i].toNode());
  return t;
}, Ii = function(e) {
  var t = "<" + e;
  this.classes.length && (t += ' class="' + j.escape(at(this.classes)) + '"');
  var a = "";
  for (var n in this.style)
    this.style.hasOwnProperty(n) && (a += j.hyphenate(n) + ":" + this.style[n] + ";");
  a && (t += ' style="' + j.escape(a) + '"');
  for (var i in this.attributes)
    this.attributes.hasOwnProperty(i) && (t += " " + i + '="' + j.escape(this.attributes[i]) + '"');
  t += ">";
  for (var l = 0; l < this.children.length; l++)
    t += this.children[l].toMarkup();
  return t += "</" + e + ">", t;
};
class qr {
  constructor(e, t, a, n) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, Ri.call(this, e, a, n), this.children = t || [];
  }
  /**
   * Sets an arbitrary attribute on the span. Warning: use this wisely. Not
   * all browsers support attributes the same, and having too many custom
   * attributes is probably bad.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return j.contains(this.classes, e);
  }
  toNode() {
    return Ni.call(this, "span");
  }
  toMarkup() {
    return Ii.call(this, "span");
  }
}
class Li {
  constructor(e, t, a, n) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, Ri.call(this, t, n), this.children = a || [], this.setAttribute("href", e);
  }
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return j.contains(this.classes, e);
  }
  toNode() {
    return Ni.call(this, "a");
  }
  toMarkup() {
    return Ii.call(this, "a");
  }
}
class Os {
  constructor(e, t, a) {
    this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.style = a;
  }
  hasClass(e) {
    return j.contains(this.classes, e);
  }
  toNode() {
    var e = document.createElement("img");
    e.src = this.src, e.alt = this.alt, e.className = "mord";
    for (var t in this.style)
      this.style.hasOwnProperty(t) && (e.style[t] = this.style[t]);
    return e;
  }
  toMarkup() {
    var e = '<img src="' + j.escape(this.src) + '"' + (' alt="' + j.escape(this.alt) + '"'), t = "";
    for (var a in this.style)
      this.style.hasOwnProperty(a) && (t += j.hyphenate(a) + ":" + this.style[a] + ";");
    return t && (e += ' style="' + j.escape(t) + '"'), e += "'/>", e;
  }
}
var qs = {
  î: "ı̂",
  ï: "ı̈",
  í: "ı́",
  // 'ī': '\u0131\u0304', // enable when we add Extended Latin
  ì: "ı̀"
};
class P0 {
  constructor(e, t, a, n, i, l, s, o) {
    this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = a || 0, this.italic = n || 0, this.skew = i || 0, this.width = l || 0, this.classes = s || [], this.style = o || {}, this.maxFontSize = 0;
    var m = As(this.text.charCodeAt(0));
    m && this.classes.push(m + "_fallback"), /[îïíì]/.test(this.text) && (this.text = qs[this.text]);
  }
  hasClass(e) {
    return j.contains(this.classes, e);
  }
  /**
   * Creates a text node or span from a symbol node. Note that a span is only
   * created if it is needed.
   */
  toNode() {
    var e = document.createTextNode(this.text), t = null;
    this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = q(this.italic)), this.classes.length > 0 && (t = t || document.createElement("span"), t.className = at(this.classes));
    for (var a in this.style)
      this.style.hasOwnProperty(a) && (t = t || document.createElement("span"), t.style[a] = this.style[a]);
    return t ? (t.appendChild(e), t) : e;
  }
  /**
   * Creates markup for a symbol node.
   */
  toMarkup() {
    var e = !1, t = "<span";
    this.classes.length && (e = !0, t += ' class="', t += j.escape(at(this.classes)), t += '"');
    var a = "";
    this.italic > 0 && (a += "margin-right:" + this.italic + "em;");
    for (var n in this.style)
      this.style.hasOwnProperty(n) && (a += j.hyphenate(n) + ":" + this.style[n] + ";");
    a && (e = !0, t += ' style="' + j.escape(a) + '"');
    var i = j.escape(this.text);
    return e ? (t += ">", t += i, t += "</span>", t) : i;
  }
}
class nt {
  constructor(e, t) {
    this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "svg");
    for (var a in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, a) && t.setAttribute(a, this.attributes[a]);
    for (var n = 0; n < this.children.length; n++)
      t.appendChild(this.children[n].toNode());
    return t;
  }
  toMarkup() {
    var e = '<svg xmlns="http://www.w3.org/2000/svg"';
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + j.escape(this.attributes[t]) + '"');
    e += ">";
    for (var a = 0; a < this.children.length; a++)
      e += this.children[a].toMarkup();
    return e += "</svg>", e;
  }
}
class gt {
  constructor(e, t) {
    this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "path");
    return this.alternate ? t.setAttribute("d", this.alternate) : t.setAttribute("d", mn[this.pathName]), t;
  }
  toMarkup() {
    return this.alternate ? '<path d="' + j.escape(this.alternate) + '"/>' : '<path d="' + j.escape(mn[this.pathName]) + '"/>';
  }
}
class dn {
  constructor(e) {
    this.attributes = void 0, this.attributes = e || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "line");
    for (var a in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, a) && t.setAttribute(a, this.attributes[a]);
    return t;
  }
  toMarkup() {
    var e = "<line";
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + j.escape(this.attributes[t]) + '"');
    return e += "/>", e;
  }
}
function pn(r) {
  if (r instanceof P0)
    return r;
  throw new Error("Expected symbolNode but got " + String(r) + ".");
}
function Ps(r) {
  if (r instanceof qr)
    return r;
  throw new Error("Expected span<HtmlDomNode> but got " + String(r) + ".");
}
var Hs = {
  "accent-token": 1,
  mathord: 1,
  "op-token": 1,
  spacing: 1,
  textord: 1
}, qe = {
  math: {},
  text: {}
};
function u(r, e, t, a, n, i) {
  qe[r][n] = {
    font: e,
    group: t,
    replace: a
  }, i && a && (qe[r][a] = qe[r][n]);
}
var c = "math", z = "text", h = "main", v = "ams", Ce = "accent-token", H = "bin", r0 = "close", It = "inner", Y = "mathord", He = "op-token", v0 = "open", Pr = "punct", b = "rel", Q0 = "spacing", x = "textord";
u(c, h, b, "≡", "\\equiv", !0);
u(c, h, b, "≺", "\\prec", !0);
u(c, h, b, "≻", "\\succ", !0);
u(c, h, b, "∼", "\\sim", !0);
u(c, h, b, "⊥", "\\perp");
u(c, h, b, "⪯", "\\preceq", !0);
u(c, h, b, "⪰", "\\succeq", !0);
u(c, h, b, "≃", "\\simeq", !0);
u(c, h, b, "∣", "\\mid", !0);
u(c, h, b, "≪", "\\ll", !0);
u(c, h, b, "≫", "\\gg", !0);
u(c, h, b, "≍", "\\asymp", !0);
u(c, h, b, "∥", "\\parallel");
u(c, h, b, "⋈", "\\bowtie", !0);
u(c, h, b, "⌣", "\\smile", !0);
u(c, h, b, "⊑", "\\sqsubseteq", !0);
u(c, h, b, "⊒", "\\sqsupseteq", !0);
u(c, h, b, "≐", "\\doteq", !0);
u(c, h, b, "⌢", "\\frown", !0);
u(c, h, b, "∋", "\\ni", !0);
u(c, h, b, "∝", "\\propto", !0);
u(c, h, b, "⊢", "\\vdash", !0);
u(c, h, b, "⊣", "\\dashv", !0);
u(c, h, b, "∋", "\\owns");
u(c, h, Pr, ".", "\\ldotp");
u(c, h, Pr, "⋅", "\\cdotp");
u(c, h, x, "#", "\\#");
u(z, h, x, "#", "\\#");
u(c, h, x, "&", "\\&");
u(z, h, x, "&", "\\&");
u(c, h, x, "ℵ", "\\aleph", !0);
u(c, h, x, "∀", "\\forall", !0);
u(c, h, x, "ℏ", "\\hbar", !0);
u(c, h, x, "∃", "\\exists", !0);
u(c, h, x, "∇", "\\nabla", !0);
u(c, h, x, "♭", "\\flat", !0);
u(c, h, x, "ℓ", "\\ell", !0);
u(c, h, x, "♮", "\\natural", !0);
u(c, h, x, "♣", "\\clubsuit", !0);
u(c, h, x, "℘", "\\wp", !0);
u(c, h, x, "♯", "\\sharp", !0);
u(c, h, x, "♢", "\\diamondsuit", !0);
u(c, h, x, "ℜ", "\\Re", !0);
u(c, h, x, "♡", "\\heartsuit", !0);
u(c, h, x, "ℑ", "\\Im", !0);
u(c, h, x, "♠", "\\spadesuit", !0);
u(c, h, x, "§", "\\S", !0);
u(z, h, x, "§", "\\S");
u(c, h, x, "¶", "\\P", !0);
u(z, h, x, "¶", "\\P");
u(c, h, x, "†", "\\dag");
u(z, h, x, "†", "\\dag");
u(z, h, x, "†", "\\textdagger");
u(c, h, x, "‡", "\\ddag");
u(z, h, x, "‡", "\\ddag");
u(z, h, x, "‡", "\\textdaggerdbl");
u(c, h, r0, "⎱", "\\rmoustache", !0);
u(c, h, v0, "⎰", "\\lmoustache", !0);
u(c, h, r0, "⟯", "\\rgroup", !0);
u(c, h, v0, "⟮", "\\lgroup", !0);
u(c, h, H, "∓", "\\mp", !0);
u(c, h, H, "⊖", "\\ominus", !0);
u(c, h, H, "⊎", "\\uplus", !0);
u(c, h, H, "⊓", "\\sqcap", !0);
u(c, h, H, "∗", "\\ast");
u(c, h, H, "⊔", "\\sqcup", !0);
u(c, h, H, "◯", "\\bigcirc", !0);
u(c, h, H, "∙", "\\bullet", !0);
u(c, h, H, "‡", "\\ddagger");
u(c, h, H, "≀", "\\wr", !0);
u(c, h, H, "⨿", "\\amalg");
u(c, h, H, "&", "\\And");
u(c, h, b, "⟵", "\\longleftarrow", !0);
u(c, h, b, "⇐", "\\Leftarrow", !0);
u(c, h, b, "⟸", "\\Longleftarrow", !0);
u(c, h, b, "⟶", "\\longrightarrow", !0);
u(c, h, b, "⇒", "\\Rightarrow", !0);
u(c, h, b, "⟹", "\\Longrightarrow", !0);
u(c, h, b, "↔", "\\leftrightarrow", !0);
u(c, h, b, "⟷", "\\longleftrightarrow", !0);
u(c, h, b, "⇔", "\\Leftrightarrow", !0);
u(c, h, b, "⟺", "\\Longleftrightarrow", !0);
u(c, h, b, "↦", "\\mapsto", !0);
u(c, h, b, "⟼", "\\longmapsto", !0);
u(c, h, b, "↗", "\\nearrow", !0);
u(c, h, b, "↩", "\\hookleftarrow", !0);
u(c, h, b, "↪", "\\hookrightarrow", !0);
u(c, h, b, "↘", "\\searrow", !0);
u(c, h, b, "↼", "\\leftharpoonup", !0);
u(c, h, b, "⇀", "\\rightharpoonup", !0);
u(c, h, b, "↙", "\\swarrow", !0);
u(c, h, b, "↽", "\\leftharpoondown", !0);
u(c, h, b, "⇁", "\\rightharpoondown", !0);
u(c, h, b, "↖", "\\nwarrow", !0);
u(c, h, b, "⇌", "\\rightleftharpoons", !0);
u(c, v, b, "≮", "\\nless", !0);
u(c, v, b, "", "\\@nleqslant");
u(c, v, b, "", "\\@nleqq");
u(c, v, b, "⪇", "\\lneq", !0);
u(c, v, b, "≨", "\\lneqq", !0);
u(c, v, b, "", "\\@lvertneqq");
u(c, v, b, "⋦", "\\lnsim", !0);
u(c, v, b, "⪉", "\\lnapprox", !0);
u(c, v, b, "⊀", "\\nprec", !0);
u(c, v, b, "⋠", "\\npreceq", !0);
u(c, v, b, "⋨", "\\precnsim", !0);
u(c, v, b, "⪹", "\\precnapprox", !0);
u(c, v, b, "≁", "\\nsim", !0);
u(c, v, b, "", "\\@nshortmid");
u(c, v, b, "∤", "\\nmid", !0);
u(c, v, b, "⊬", "\\nvdash", !0);
u(c, v, b, "⊭", "\\nvDash", !0);
u(c, v, b, "⋪", "\\ntriangleleft");
u(c, v, b, "⋬", "\\ntrianglelefteq", !0);
u(c, v, b, "⊊", "\\subsetneq", !0);
u(c, v, b, "", "\\@varsubsetneq");
u(c, v, b, "⫋", "\\subsetneqq", !0);
u(c, v, b, "", "\\@varsubsetneqq");
u(c, v, b, "≯", "\\ngtr", !0);
u(c, v, b, "", "\\@ngeqslant");
u(c, v, b, "", "\\@ngeqq");
u(c, v, b, "⪈", "\\gneq", !0);
u(c, v, b, "≩", "\\gneqq", !0);
u(c, v, b, "", "\\@gvertneqq");
u(c, v, b, "⋧", "\\gnsim", !0);
u(c, v, b, "⪊", "\\gnapprox", !0);
u(c, v, b, "⊁", "\\nsucc", !0);
u(c, v, b, "⋡", "\\nsucceq", !0);
u(c, v, b, "⋩", "\\succnsim", !0);
u(c, v, b, "⪺", "\\succnapprox", !0);
u(c, v, b, "≆", "\\ncong", !0);
u(c, v, b, "", "\\@nshortparallel");
u(c, v, b, "∦", "\\nparallel", !0);
u(c, v, b, "⊯", "\\nVDash", !0);
u(c, v, b, "⋫", "\\ntriangleright");
u(c, v, b, "⋭", "\\ntrianglerighteq", !0);
u(c, v, b, "", "\\@nsupseteqq");
u(c, v, b, "⊋", "\\supsetneq", !0);
u(c, v, b, "", "\\@varsupsetneq");
u(c, v, b, "⫌", "\\supsetneqq", !0);
u(c, v, b, "", "\\@varsupsetneqq");
u(c, v, b, "⊮", "\\nVdash", !0);
u(c, v, b, "⪵", "\\precneqq", !0);
u(c, v, b, "⪶", "\\succneqq", !0);
u(c, v, b, "", "\\@nsubseteqq");
u(c, v, H, "⊴", "\\unlhd");
u(c, v, H, "⊵", "\\unrhd");
u(c, v, b, "↚", "\\nleftarrow", !0);
u(c, v, b, "↛", "\\nrightarrow", !0);
u(c, v, b, "⇍", "\\nLeftarrow", !0);
u(c, v, b, "⇏", "\\nRightarrow", !0);
u(c, v, b, "↮", "\\nleftrightarrow", !0);
u(c, v, b, "⇎", "\\nLeftrightarrow", !0);
u(c, v, b, "△", "\\vartriangle");
u(c, v, x, "ℏ", "\\hslash");
u(c, v, x, "▽", "\\triangledown");
u(c, v, x, "◊", "\\lozenge");
u(c, v, x, "Ⓢ", "\\circledS");
u(c, v, x, "®", "\\circledR");
u(z, v, x, "®", "\\circledR");
u(c, v, x, "∡", "\\measuredangle", !0);
u(c, v, x, "∄", "\\nexists");
u(c, v, x, "℧", "\\mho");
u(c, v, x, "Ⅎ", "\\Finv", !0);
u(c, v, x, "⅁", "\\Game", !0);
u(c, v, x, "‵", "\\backprime");
u(c, v, x, "▲", "\\blacktriangle");
u(c, v, x, "▼", "\\blacktriangledown");
u(c, v, x, "■", "\\blacksquare");
u(c, v, x, "⧫", "\\blacklozenge");
u(c, v, x, "★", "\\bigstar");
u(c, v, x, "∢", "\\sphericalangle", !0);
u(c, v, x, "∁", "\\complement", !0);
u(c, v, x, "ð", "\\eth", !0);
u(z, h, x, "ð", "ð");
u(c, v, x, "╱", "\\diagup");
u(c, v, x, "╲", "\\diagdown");
u(c, v, x, "□", "\\square");
u(c, v, x, "□", "\\Box");
u(c, v, x, "◊", "\\Diamond");
u(c, v, x, "¥", "\\yen", !0);
u(z, v, x, "¥", "\\yen", !0);
u(c, v, x, "✓", "\\checkmark", !0);
u(z, v, x, "✓", "\\checkmark");
u(c, v, x, "ℶ", "\\beth", !0);
u(c, v, x, "ℸ", "\\daleth", !0);
u(c, v, x, "ℷ", "\\gimel", !0);
u(c, v, x, "ϝ", "\\digamma", !0);
u(c, v, x, "ϰ", "\\varkappa");
u(c, v, v0, "┌", "\\@ulcorner", !0);
u(c, v, r0, "┐", "\\@urcorner", !0);
u(c, v, v0, "└", "\\@llcorner", !0);
u(c, v, r0, "┘", "\\@lrcorner", !0);
u(c, v, b, "≦", "\\leqq", !0);
u(c, v, b, "⩽", "\\leqslant", !0);
u(c, v, b, "⪕", "\\eqslantless", !0);
u(c, v, b, "≲", "\\lesssim", !0);
u(c, v, b, "⪅", "\\lessapprox", !0);
u(c, v, b, "≊", "\\approxeq", !0);
u(c, v, H, "⋖", "\\lessdot");
u(c, v, b, "⋘", "\\lll", !0);
u(c, v, b, "≶", "\\lessgtr", !0);
u(c, v, b, "⋚", "\\lesseqgtr", !0);
u(c, v, b, "⪋", "\\lesseqqgtr", !0);
u(c, v, b, "≑", "\\doteqdot");
u(c, v, b, "≓", "\\risingdotseq", !0);
u(c, v, b, "≒", "\\fallingdotseq", !0);
u(c, v, b, "∽", "\\backsim", !0);
u(c, v, b, "⋍", "\\backsimeq", !0);
u(c, v, b, "⫅", "\\subseteqq", !0);
u(c, v, b, "⋐", "\\Subset", !0);
u(c, v, b, "⊏", "\\sqsubset", !0);
u(c, v, b, "≼", "\\preccurlyeq", !0);
u(c, v, b, "⋞", "\\curlyeqprec", !0);
u(c, v, b, "≾", "\\precsim", !0);
u(c, v, b, "⪷", "\\precapprox", !0);
u(c, v, b, "⊲", "\\vartriangleleft");
u(c, v, b, "⊴", "\\trianglelefteq");
u(c, v, b, "⊨", "\\vDash", !0);
u(c, v, b, "⊪", "\\Vvdash", !0);
u(c, v, b, "⌣", "\\smallsmile");
u(c, v, b, "⌢", "\\smallfrown");
u(c, v, b, "≏", "\\bumpeq", !0);
u(c, v, b, "≎", "\\Bumpeq", !0);
u(c, v, b, "≧", "\\geqq", !0);
u(c, v, b, "⩾", "\\geqslant", !0);
u(c, v, b, "⪖", "\\eqslantgtr", !0);
u(c, v, b, "≳", "\\gtrsim", !0);
u(c, v, b, "⪆", "\\gtrapprox", !0);
u(c, v, H, "⋗", "\\gtrdot");
u(c, v, b, "⋙", "\\ggg", !0);
u(c, v, b, "≷", "\\gtrless", !0);
u(c, v, b, "⋛", "\\gtreqless", !0);
u(c, v, b, "⪌", "\\gtreqqless", !0);
u(c, v, b, "≖", "\\eqcirc", !0);
u(c, v, b, "≗", "\\circeq", !0);
u(c, v, b, "≜", "\\triangleq", !0);
u(c, v, b, "∼", "\\thicksim");
u(c, v, b, "≈", "\\thickapprox");
u(c, v, b, "⫆", "\\supseteqq", !0);
u(c, v, b, "⋑", "\\Supset", !0);
u(c, v, b, "⊐", "\\sqsupset", !0);
u(c, v, b, "≽", "\\succcurlyeq", !0);
u(c, v, b, "⋟", "\\curlyeqsucc", !0);
u(c, v, b, "≿", "\\succsim", !0);
u(c, v, b, "⪸", "\\succapprox", !0);
u(c, v, b, "⊳", "\\vartriangleright");
u(c, v, b, "⊵", "\\trianglerighteq");
u(c, v, b, "⊩", "\\Vdash", !0);
u(c, v, b, "∣", "\\shortmid");
u(c, v, b, "∥", "\\shortparallel");
u(c, v, b, "≬", "\\between", !0);
u(c, v, b, "⋔", "\\pitchfork", !0);
u(c, v, b, "∝", "\\varpropto");
u(c, v, b, "◀", "\\blacktriangleleft");
u(c, v, b, "∴", "\\therefore", !0);
u(c, v, b, "∍", "\\backepsilon");
u(c, v, b, "▶", "\\blacktriangleright");
u(c, v, b, "∵", "\\because", !0);
u(c, v, b, "⋘", "\\llless");
u(c, v, b, "⋙", "\\gggtr");
u(c, v, H, "⊲", "\\lhd");
u(c, v, H, "⊳", "\\rhd");
u(c, v, b, "≂", "\\eqsim", !0);
u(c, h, b, "⋈", "\\Join");
u(c, v, b, "≑", "\\Doteq", !0);
u(c, v, H, "∔", "\\dotplus", !0);
u(c, v, H, "∖", "\\smallsetminus");
u(c, v, H, "⋒", "\\Cap", !0);
u(c, v, H, "⋓", "\\Cup", !0);
u(c, v, H, "⩞", "\\doublebarwedge", !0);
u(c, v, H, "⊟", "\\boxminus", !0);
u(c, v, H, "⊞", "\\boxplus", !0);
u(c, v, H, "⋇", "\\divideontimes", !0);
u(c, v, H, "⋉", "\\ltimes", !0);
u(c, v, H, "⋊", "\\rtimes", !0);
u(c, v, H, "⋋", "\\leftthreetimes", !0);
u(c, v, H, "⋌", "\\rightthreetimes", !0);
u(c, v, H, "⋏", "\\curlywedge", !0);
u(c, v, H, "⋎", "\\curlyvee", !0);
u(c, v, H, "⊝", "\\circleddash", !0);
u(c, v, H, "⊛", "\\circledast", !0);
u(c, v, H, "⋅", "\\centerdot");
u(c, v, H, "⊺", "\\intercal", !0);
u(c, v, H, "⋒", "\\doublecap");
u(c, v, H, "⋓", "\\doublecup");
u(c, v, H, "⊠", "\\boxtimes", !0);
u(c, v, b, "⇢", "\\dashrightarrow", !0);
u(c, v, b, "⇠", "\\dashleftarrow", !0);
u(c, v, b, "⇇", "\\leftleftarrows", !0);
u(c, v, b, "⇆", "\\leftrightarrows", !0);
u(c, v, b, "⇚", "\\Lleftarrow", !0);
u(c, v, b, "↞", "\\twoheadleftarrow", !0);
u(c, v, b, "↢", "\\leftarrowtail", !0);
u(c, v, b, "↫", "\\looparrowleft", !0);
u(c, v, b, "⇋", "\\leftrightharpoons", !0);
u(c, v, b, "↶", "\\curvearrowleft", !0);
u(c, v, b, "↺", "\\circlearrowleft", !0);
u(c, v, b, "↰", "\\Lsh", !0);
u(c, v, b, "⇈", "\\upuparrows", !0);
u(c, v, b, "↿", "\\upharpoonleft", !0);
u(c, v, b, "⇃", "\\downharpoonleft", !0);
u(c, h, b, "⊶", "\\origof", !0);
u(c, h, b, "⊷", "\\imageof", !0);
u(c, v, b, "⊸", "\\multimap", !0);
u(c, v, b, "↭", "\\leftrightsquigarrow", !0);
u(c, v, b, "⇉", "\\rightrightarrows", !0);
u(c, v, b, "⇄", "\\rightleftarrows", !0);
u(c, v, b, "↠", "\\twoheadrightarrow", !0);
u(c, v, b, "↣", "\\rightarrowtail", !0);
u(c, v, b, "↬", "\\looparrowright", !0);
u(c, v, b, "↷", "\\curvearrowright", !0);
u(c, v, b, "↻", "\\circlearrowright", !0);
u(c, v, b, "↱", "\\Rsh", !0);
u(c, v, b, "⇊", "\\downdownarrows", !0);
u(c, v, b, "↾", "\\upharpoonright", !0);
u(c, v, b, "⇂", "\\downharpoonright", !0);
u(c, v, b, "⇝", "\\rightsquigarrow", !0);
u(c, v, b, "⇝", "\\leadsto");
u(c, v, b, "⇛", "\\Rrightarrow", !0);
u(c, v, b, "↾", "\\restriction");
u(c, h, x, "‘", "`");
u(c, h, x, "$", "\\$");
u(z, h, x, "$", "\\$");
u(z, h, x, "$", "\\textdollar");
u(c, h, x, "%", "\\%");
u(z, h, x, "%", "\\%");
u(c, h, x, "_", "\\_");
u(z, h, x, "_", "\\_");
u(z, h, x, "_", "\\textunderscore");
u(c, h, x, "∠", "\\angle", !0);
u(c, h, x, "∞", "\\infty", !0);
u(c, h, x, "′", "\\prime");
u(c, h, x, "△", "\\triangle");
u(c, h, x, "Γ", "\\Gamma", !0);
u(c, h, x, "Δ", "\\Delta", !0);
u(c, h, x, "Θ", "\\Theta", !0);
u(c, h, x, "Λ", "\\Lambda", !0);
u(c, h, x, "Ξ", "\\Xi", !0);
u(c, h, x, "Π", "\\Pi", !0);
u(c, h, x, "Σ", "\\Sigma", !0);
u(c, h, x, "Υ", "\\Upsilon", !0);
u(c, h, x, "Φ", "\\Phi", !0);
u(c, h, x, "Ψ", "\\Psi", !0);
u(c, h, x, "Ω", "\\Omega", !0);
u(c, h, x, "A", "Α");
u(c, h, x, "B", "Β");
u(c, h, x, "E", "Ε");
u(c, h, x, "Z", "Ζ");
u(c, h, x, "H", "Η");
u(c, h, x, "I", "Ι");
u(c, h, x, "K", "Κ");
u(c, h, x, "M", "Μ");
u(c, h, x, "N", "Ν");
u(c, h, x, "O", "Ο");
u(c, h, x, "P", "Ρ");
u(c, h, x, "T", "Τ");
u(c, h, x, "X", "Χ");
u(c, h, x, "¬", "\\neg", !0);
u(c, h, x, "¬", "\\lnot");
u(c, h, x, "⊤", "\\top");
u(c, h, x, "⊥", "\\bot");
u(c, h, x, "∅", "\\emptyset");
u(c, v, x, "∅", "\\varnothing");
u(c, h, Y, "α", "\\alpha", !0);
u(c, h, Y, "β", "\\beta", !0);
u(c, h, Y, "γ", "\\gamma", !0);
u(c, h, Y, "δ", "\\delta", !0);
u(c, h, Y, "ϵ", "\\epsilon", !0);
u(c, h, Y, "ζ", "\\zeta", !0);
u(c, h, Y, "η", "\\eta", !0);
u(c, h, Y, "θ", "\\theta", !0);
u(c, h, Y, "ι", "\\iota", !0);
u(c, h, Y, "κ", "\\kappa", !0);
u(c, h, Y, "λ", "\\lambda", !0);
u(c, h, Y, "μ", "\\mu", !0);
u(c, h, Y, "ν", "\\nu", !0);
u(c, h, Y, "ξ", "\\xi", !0);
u(c, h, Y, "ο", "\\omicron", !0);
u(c, h, Y, "π", "\\pi", !0);
u(c, h, Y, "ρ", "\\rho", !0);
u(c, h, Y, "σ", "\\sigma", !0);
u(c, h, Y, "τ", "\\tau", !0);
u(c, h, Y, "υ", "\\upsilon", !0);
u(c, h, Y, "ϕ", "\\phi", !0);
u(c, h, Y, "χ", "\\chi", !0);
u(c, h, Y, "ψ", "\\psi", !0);
u(c, h, Y, "ω", "\\omega", !0);
u(c, h, Y, "ε", "\\varepsilon", !0);
u(c, h, Y, "ϑ", "\\vartheta", !0);
u(c, h, Y, "ϖ", "\\varpi", !0);
u(c, h, Y, "ϱ", "\\varrho", !0);
u(c, h, Y, "ς", "\\varsigma", !0);
u(c, h, Y, "φ", "\\varphi", !0);
u(c, h, H, "∗", "*", !0);
u(c, h, H, "+", "+");
u(c, h, H, "−", "-", !0);
u(c, h, H, "⋅", "\\cdot", !0);
u(c, h, H, "∘", "\\circ", !0);
u(c, h, H, "÷", "\\div", !0);
u(c, h, H, "±", "\\pm", !0);
u(c, h, H, "×", "\\times", !0);
u(c, h, H, "∩", "\\cap", !0);
u(c, h, H, "∪", "\\cup", !0);
u(c, h, H, "∖", "\\setminus", !0);
u(c, h, H, "∧", "\\land");
u(c, h, H, "∨", "\\lor");
u(c, h, H, "∧", "\\wedge", !0);
u(c, h, H, "∨", "\\vee", !0);
u(c, h, x, "√", "\\surd");
u(c, h, v0, "⟨", "\\langle", !0);
u(c, h, v0, "∣", "\\lvert");
u(c, h, v0, "∥", "\\lVert");
u(c, h, r0, "?", "?");
u(c, h, r0, "!", "!");
u(c, h, r0, "⟩", "\\rangle", !0);
u(c, h, r0, "∣", "\\rvert");
u(c, h, r0, "∥", "\\rVert");
u(c, h, b, "=", "=");
u(c, h, b, ":", ":");
u(c, h, b, "≈", "\\approx", !0);
u(c, h, b, "≅", "\\cong", !0);
u(c, h, b, "≥", "\\ge");
u(c, h, b, "≥", "\\geq", !0);
u(c, h, b, "←", "\\gets");
u(c, h, b, ">", "\\gt", !0);
u(c, h, b, "∈", "\\in", !0);
u(c, h, b, "", "\\@not");
u(c, h, b, "⊂", "\\subset", !0);
u(c, h, b, "⊃", "\\supset", !0);
u(c, h, b, "⊆", "\\subseteq", !0);
u(c, h, b, "⊇", "\\supseteq", !0);
u(c, v, b, "⊈", "\\nsubseteq", !0);
u(c, v, b, "⊉", "\\nsupseteq", !0);
u(c, h, b, "⊨", "\\models");
u(c, h, b, "←", "\\leftarrow", !0);
u(c, h, b, "≤", "\\le");
u(c, h, b, "≤", "\\leq", !0);
u(c, h, b, "<", "\\lt", !0);
u(c, h, b, "→", "\\rightarrow", !0);
u(c, h, b, "→", "\\to");
u(c, v, b, "≱", "\\ngeq", !0);
u(c, v, b, "≰", "\\nleq", !0);
u(c, h, Q0, " ", "\\ ");
u(c, h, Q0, " ", "\\space");
u(c, h, Q0, " ", "\\nobreakspace");
u(z, h, Q0, " ", "\\ ");
u(z, h, Q0, " ", " ");
u(z, h, Q0, " ", "\\space");
u(z, h, Q0, " ", "\\nobreakspace");
u(c, h, Q0, null, "\\nobreak");
u(c, h, Q0, null, "\\allowbreak");
u(c, h, Pr, ",", ",");
u(c, h, Pr, ";", ";");
u(c, v, H, "⊼", "\\barwedge", !0);
u(c, v, H, "⊻", "\\veebar", !0);
u(c, h, H, "⊙", "\\odot", !0);
u(c, h, H, "⊕", "\\oplus", !0);
u(c, h, H, "⊗", "\\otimes", !0);
u(c, h, x, "∂", "\\partial", !0);
u(c, h, H, "⊘", "\\oslash", !0);
u(c, v, H, "⊚", "\\circledcirc", !0);
u(c, v, H, "⊡", "\\boxdot", !0);
u(c, h, H, "△", "\\bigtriangleup");
u(c, h, H, "▽", "\\bigtriangledown");
u(c, h, H, "†", "\\dagger");
u(c, h, H, "⋄", "\\diamond");
u(c, h, H, "⋆", "\\star");
u(c, h, H, "◃", "\\triangleleft");
u(c, h, H, "▹", "\\triangleright");
u(c, h, v0, "{", "\\{");
u(z, h, x, "{", "\\{");
u(z, h, x, "{", "\\textbraceleft");
u(c, h, r0, "}", "\\}");
u(z, h, x, "}", "\\}");
u(z, h, x, "}", "\\textbraceright");
u(c, h, v0, "{", "\\lbrace");
u(c, h, r0, "}", "\\rbrace");
u(c, h, v0, "[", "\\lbrack", !0);
u(z, h, x, "[", "\\lbrack", !0);
u(c, h, r0, "]", "\\rbrack", !0);
u(z, h, x, "]", "\\rbrack", !0);
u(c, h, v0, "(", "\\lparen", !0);
u(c, h, r0, ")", "\\rparen", !0);
u(z, h, x, "<", "\\textless", !0);
u(z, h, x, ">", "\\textgreater", !0);
u(c, h, v0, "⌊", "\\lfloor", !0);
u(c, h, r0, "⌋", "\\rfloor", !0);
u(c, h, v0, "⌈", "\\lceil", !0);
u(c, h, r0, "⌉", "\\rceil", !0);
u(c, h, x, "\\", "\\backslash");
u(c, h, x, "∣", "|");
u(c, h, x, "∣", "\\vert");
u(z, h, x, "|", "\\textbar", !0);
u(c, h, x, "∥", "\\|");
u(c, h, x, "∥", "\\Vert");
u(z, h, x, "∥", "\\textbardbl");
u(z, h, x, "~", "\\textasciitilde");
u(z, h, x, "\\", "\\textbackslash");
u(z, h, x, "^", "\\textasciicircum");
u(c, h, b, "↑", "\\uparrow", !0);
u(c, h, b, "⇑", "\\Uparrow", !0);
u(c, h, b, "↓", "\\downarrow", !0);
u(c, h, b, "⇓", "\\Downarrow", !0);
u(c, h, b, "↕", "\\updownarrow", !0);
u(c, h, b, "⇕", "\\Updownarrow", !0);
u(c, h, He, "∐", "\\coprod");
u(c, h, He, "⋁", "\\bigvee");
u(c, h, He, "⋀", "\\bigwedge");
u(c, h, He, "⨄", "\\biguplus");
u(c, h, He, "⋂", "\\bigcap");
u(c, h, He, "⋃", "\\bigcup");
u(c, h, He, "∫", "\\int");
u(c, h, He, "∫", "\\intop");
u(c, h, He, "∬", "\\iint");
u(c, h, He, "∭", "\\iiint");
u(c, h, He, "∏", "\\prod");
u(c, h, He, "∑", "\\sum");
u(c, h, He, "⨂", "\\bigotimes");
u(c, h, He, "⨁", "\\bigoplus");
u(c, h, He, "⨀", "\\bigodot");
u(c, h, He, "∮", "\\oint");
u(c, h, He, "∯", "\\oiint");
u(c, h, He, "∰", "\\oiiint");
u(c, h, He, "⨆", "\\bigsqcup");
u(c, h, He, "∫", "\\smallint");
u(z, h, It, "…", "\\textellipsis");
u(c, h, It, "…", "\\mathellipsis");
u(z, h, It, "…", "\\ldots", !0);
u(c, h, It, "…", "\\ldots", !0);
u(c, h, It, "⋯", "\\@cdots", !0);
u(c, h, It, "⋱", "\\ddots", !0);
u(c, h, x, "⋮", "\\varvdots");
u(c, h, Ce, "ˊ", "\\acute");
u(c, h, Ce, "ˋ", "\\grave");
u(c, h, Ce, "¨", "\\ddot");
u(c, h, Ce, "~", "\\tilde");
u(c, h, Ce, "ˉ", "\\bar");
u(c, h, Ce, "˘", "\\breve");
u(c, h, Ce, "ˇ", "\\check");
u(c, h, Ce, "^", "\\hat");
u(c, h, Ce, "⃗", "\\vec");
u(c, h, Ce, "˙", "\\dot");
u(c, h, Ce, "˚", "\\mathring");
u(c, h, Y, "", "\\@imath");
u(c, h, Y, "", "\\@jmath");
u(c, h, x, "ı", "ı");
u(c, h, x, "ȷ", "ȷ");
u(z, h, x, "ı", "\\i", !0);
u(z, h, x, "ȷ", "\\j", !0);
u(z, h, x, "ß", "\\ss", !0);
u(z, h, x, "æ", "\\ae", !0);
u(z, h, x, "œ", "\\oe", !0);
u(z, h, x, "ø", "\\o", !0);
u(z, h, x, "Æ", "\\AE", !0);
u(z, h, x, "Œ", "\\OE", !0);
u(z, h, x, "Ø", "\\O", !0);
u(z, h, Ce, "ˊ", "\\'");
u(z, h, Ce, "ˋ", "\\`");
u(z, h, Ce, "ˆ", "\\^");
u(z, h, Ce, "˜", "\\~");
u(z, h, Ce, "ˉ", "\\=");
u(z, h, Ce, "˘", "\\u");
u(z, h, Ce, "˙", "\\.");
u(z, h, Ce, "¸", "\\c");
u(z, h, Ce, "˚", "\\r");
u(z, h, Ce, "ˇ", "\\v");
u(z, h, Ce, "¨", '\\"');
u(z, h, Ce, "˝", "\\H");
u(z, h, Ce, "◯", "\\textcircled");
var Oi = {
  "--": !0,
  "---": !0,
  "``": !0,
  "''": !0
};
u(z, h, x, "–", "--", !0);
u(z, h, x, "–", "\\textendash");
u(z, h, x, "—", "---", !0);
u(z, h, x, "—", "\\textemdash");
u(z, h, x, "‘", "`", !0);
u(z, h, x, "‘", "\\textquoteleft");
u(z, h, x, "’", "'", !0);
u(z, h, x, "’", "\\textquoteright");
u(z, h, x, "“", "``", !0);
u(z, h, x, "“", "\\textquotedblleft");
u(z, h, x, "”", "''", !0);
u(z, h, x, "”", "\\textquotedblright");
u(c, h, x, "°", "\\degree", !0);
u(z, h, x, "°", "\\degree");
u(z, h, x, "°", "\\textdegree", !0);
u(c, h, x, "£", "\\pounds");
u(c, h, x, "£", "\\mathsterling", !0);
u(z, h, x, "£", "\\pounds");
u(z, h, x, "£", "\\textsterling", !0);
u(c, v, x, "✠", "\\maltese");
u(z, v, x, "✠", "\\maltese");
var gn = '0123456789/@."';
for (var jr = 0; jr < gn.length; jr++) {
  var vn = gn.charAt(jr);
  u(c, h, x, vn, vn);
}
var bn = '0123456789!@*()-=+";:?/.,';
for (var Xr = 0; Xr < bn.length; Xr++) {
  var yn = bn.charAt(Xr);
  u(z, h, x, yn, yn);
}
var Er = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (var Zr = 0; Zr < Er.length; Zr++) {
  var fr = Er.charAt(Zr);
  u(c, h, Y, fr, fr), u(z, h, x, fr, fr);
}
u(c, v, x, "C", "ℂ");
u(z, v, x, "C", "ℂ");
u(c, v, x, "H", "ℍ");
u(z, v, x, "H", "ℍ");
u(c, v, x, "N", "ℕ");
u(z, v, x, "N", "ℕ");
u(c, v, x, "P", "ℙ");
u(z, v, x, "P", "ℙ");
u(c, v, x, "Q", "ℚ");
u(z, v, x, "Q", "ℚ");
u(c, v, x, "R", "ℝ");
u(z, v, x, "R", "ℝ");
u(c, v, x, "Z", "ℤ");
u(z, v, x, "Z", "ℤ");
u(c, h, Y, "h", "ℎ");
u(z, h, Y, "h", "ℎ");
var Q = "";
for (var Je = 0; Je < Er.length; Je++) {
  var Ie = Er.charAt(Je);
  Q = String.fromCharCode(55349, 56320 + Je), u(c, h, Y, Ie, Q), u(z, h, x, Ie, Q), Q = String.fromCharCode(55349, 56372 + Je), u(c, h, Y, Ie, Q), u(z, h, x, Ie, Q), Q = String.fromCharCode(55349, 56424 + Je), u(c, h, Y, Ie, Q), u(z, h, x, Ie, Q), Q = String.fromCharCode(55349, 56580 + Je), u(c, h, Y, Ie, Q), u(z, h, x, Ie, Q), Q = String.fromCharCode(55349, 56684 + Je), u(c, h, Y, Ie, Q), u(z, h, x, Ie, Q), Q = String.fromCharCode(55349, 56736 + Je), u(c, h, Y, Ie, Q), u(z, h, x, Ie, Q), Q = String.fromCharCode(55349, 56788 + Je), u(c, h, Y, Ie, Q), u(z, h, x, Ie, Q), Q = String.fromCharCode(55349, 56840 + Je), u(c, h, Y, Ie, Q), u(z, h, x, Ie, Q), Q = String.fromCharCode(55349, 56944 + Je), u(c, h, Y, Ie, Q), u(z, h, x, Ie, Q), Je < 26 && (Q = String.fromCharCode(55349, 56632 + Je), u(c, h, Y, Ie, Q), u(z, h, x, Ie, Q), Q = String.fromCharCode(55349, 56476 + Je), u(c, h, Y, Ie, Q), u(z, h, x, Ie, Q));
}
Q = "𝕜";
u(c, h, Y, "k", Q);
u(z, h, x, "k", Q);
for (var ft = 0; ft < 10; ft++) {
  var rt = ft.toString();
  Q = String.fromCharCode(55349, 57294 + ft), u(c, h, Y, rt, Q), u(z, h, x, rt, Q), Q = String.fromCharCode(55349, 57314 + ft), u(c, h, Y, rt, Q), u(z, h, x, rt, Q), Q = String.fromCharCode(55349, 57324 + ft), u(c, h, Y, rt, Q), u(z, h, x, rt, Q), Q = String.fromCharCode(55349, 57334 + ft), u(c, h, Y, rt, Q), u(z, h, x, rt, Q);
}
var wn = "ÐÞþ";
for (var Kr = 0; Kr < wn.length; Kr++) {
  var dr = wn.charAt(Kr);
  u(c, h, Y, dr, dr), u(z, h, x, dr, dr);
}
var pr = [
  ["mathbf", "textbf", "Main-Bold"],
  // A-Z bold upright
  ["mathbf", "textbf", "Main-Bold"],
  // a-z bold upright
  ["mathnormal", "textit", "Math-Italic"],
  // A-Z italic
  ["mathnormal", "textit", "Math-Italic"],
  // a-z italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // A-Z bold italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // a-z bold italic
  // Map fancy A-Z letters to script, not calligraphic.
  // This aligns with unicode-math and math fonts (except Cambria Math).
  ["mathscr", "textscr", "Script-Regular"],
  // A-Z script
  ["", "", ""],
  // a-z script.  No font
  ["", "", ""],
  // A-Z bold script. No font
  ["", "", ""],
  // a-z bold script. No font
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // A-Z Fraktur
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // a-z Fraktur
  ["mathbb", "textbb", "AMS-Regular"],
  // A-Z double-struck
  ["mathbb", "textbb", "AMS-Regular"],
  // k double-struck
  // Note that we are using a bold font, but font metrics for regular Fraktur.
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // A-Z bold Fraktur
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // a-z bold Fraktur
  ["mathsf", "textsf", "SansSerif-Regular"],
  // A-Z sans-serif
  ["mathsf", "textsf", "SansSerif-Regular"],
  // a-z sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // A-Z bold sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // a-z bold sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // A-Z italic sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // a-z italic sans-serif
  ["", "", ""],
  // A-Z bold italic sans. No font
  ["", "", ""],
  // a-z bold italic sans. No font
  ["mathtt", "texttt", "Typewriter-Regular"],
  // A-Z monospace
  ["mathtt", "texttt", "Typewriter-Regular"]
  // a-z monospace
], kn = [
  ["mathbf", "textbf", "Main-Bold"],
  // 0-9 bold
  ["", "", ""],
  // 0-9 double-struck. No KaTeX font.
  ["mathsf", "textsf", "SansSerif-Regular"],
  // 0-9 sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // 0-9 bold sans-serif
  ["mathtt", "texttt", "Typewriter-Regular"]
  // 0-9 monospace
], Us = function(e, t) {
  var a = e.charCodeAt(0), n = e.charCodeAt(1), i = (a - 55296) * 1024 + (n - 56320) + 65536, l = t === "math" ? 0 : 1;
  if (119808 <= i && i < 120484) {
    var s = Math.floor((i - 119808) / 26);
    return [pr[s][2], pr[s][l]];
  } else if (120782 <= i && i <= 120831) {
    var o = Math.floor((i - 120782) / 10);
    return [kn[o][2], kn[o][l]];
  } else {
    if (i === 120485 || i === 120486)
      return [pr[0][2], pr[0][l]];
    if (120486 < i && i < 120782)
      return ["", ""];
    throw new W("Unsupported character: " + e);
  }
}, Hr = function(e, t, a) {
  return qe[a][e] && qe[a][e].replace && (e = qe[a][e].replace), {
    value: e,
    metrics: Fa(e, t, a)
  };
}, T0 = function(e, t, a, n, i) {
  var l = Hr(e, t, a), s = l.metrics;
  e = l.value;
  var o;
  if (s) {
    var m = s.italic;
    (a === "text" || n && n.font === "mathit") && (m = 0), o = new P0(e, s.height, s.depth, m, s.skew, s.width, i);
  } else
    typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + a + "'")), o = new P0(e, 0, 0, 0, 0, 0, i);
  if (n) {
    o.maxFontSize = n.sizeMultiplier, n.style.isTight() && o.classes.push("mtight");
    var f = n.getColor();
    f && (o.style.color = f);
  }
  return o;
}, Gs = function(e, t, a, n) {
  return n === void 0 && (n = []), a.font === "boldsymbol" && Hr(e, "Main-Bold", t).metrics ? T0(e, "Main-Bold", t, a, n.concat(["mathbf"])) : e === "\\" || qe[t][e].font === "main" ? T0(e, "Main-Regular", t, a, n) : T0(e, "AMS-Regular", t, a, n.concat(["amsrm"]));
}, Vs = function(e, t, a, n, i) {
  return i !== "textord" && Hr(e, "Math-BoldItalic", t).metrics ? {
    fontName: "Math-BoldItalic",
    fontClass: "boldsymbol"
  } : {
    fontName: "Main-Bold",
    fontClass: "mathbf"
  };
}, Ws = function(e, t, a) {
  var n = e.mode, i = e.text, l = ["mord"], s = n === "math" || n === "text" && t.font, o = s ? t.font : t.fontFamily, m = "", f = "";
  if (i.charCodeAt(0) === 55349 && ([m, f] = Us(i, n)), m.length > 0)
    return T0(i, m, n, t, l.concat(f));
  if (o) {
    var p, g;
    if (o === "boldsymbol") {
      var w = Vs(i, n, t, l, a);
      p = w.fontName, g = [w.fontClass];
    } else s ? (p = Hi[o].fontName, g = [o]) : (p = gr(o, t.fontWeight, t.fontShape), g = [o, t.fontWeight, t.fontShape]);
    if (Hr(i, p, n).metrics)
      return T0(i, p, n, t, l.concat(g));
    if (Oi.hasOwnProperty(i) && p.slice(0, 10) === "Typewriter") {
      for (var F = [], E = 0; E < i.length; E++)
        F.push(T0(i[E], p, n, t, l.concat(g)));
      return Pi(F);
    }
  }
  if (a === "mathord")
    return T0(i, "Math-Italic", n, t, l.concat(["mathnormal"]));
  if (a === "textord") {
    var k = qe[n][i] && qe[n][i].font;
    if (k === "ams") {
      var S = gr("amsrm", t.fontWeight, t.fontShape);
      return T0(i, S, n, t, l.concat("amsrm", t.fontWeight, t.fontShape));
    } else if (k === "main" || !k) {
      var y = gr("textrm", t.fontWeight, t.fontShape);
      return T0(i, y, n, t, l.concat(t.fontWeight, t.fontShape));
    } else {
      var D = gr(k, t.fontWeight, t.fontShape);
      return T0(i, D, n, t, l.concat(D, t.fontWeight, t.fontShape));
    }
  } else
    throw new Error("unexpected type: " + a + " in makeOrd");
}, Ys = (r, e) => {
  if (at(r.classes) !== at(e.classes) || r.skew !== e.skew || r.maxFontSize !== e.maxFontSize)
    return !1;
  if (r.classes.length === 1) {
    var t = r.classes[0];
    if (t === "mbin" || t === "mord")
      return !1;
  }
  for (var a in r.style)
    if (r.style.hasOwnProperty(a) && r.style[a] !== e.style[a])
      return !1;
  for (var n in e.style)
    if (e.style.hasOwnProperty(n) && r.style[n] !== e.style[n])
      return !1;
  return !0;
}, js = (r) => {
  for (var e = 0; e < r.length - 1; e++) {
    var t = r[e], a = r[e + 1];
    t instanceof P0 && a instanceof P0 && Ys(t, a) && (t.text += a.text, t.height = Math.max(t.height, a.height), t.depth = Math.max(t.depth, a.depth), t.italic = a.italic, r.splice(e + 1, 1), e--);
  }
  return r;
}, _a = function(e) {
  for (var t = 0, a = 0, n = 0, i = 0; i < e.children.length; i++) {
    var l = e.children[i];
    l.height > t && (t = l.height), l.depth > a && (a = l.depth), l.maxFontSize > n && (n = l.maxFontSize);
  }
  e.height = t, e.depth = a, e.maxFontSize = n;
}, s0 = function(e, t, a, n) {
  var i = new qr(e, t, a, n);
  return _a(i), i;
}, qi = (r, e, t, a) => new qr(r, e, t, a), Xs = function(e, t, a) {
  var n = s0([e], [], t);
  return n.height = Math.max(a || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), n.style.borderBottomWidth = q(n.height), n.maxFontSize = 1, n;
}, Zs = function(e, t, a, n) {
  var i = new Li(e, t, a, n);
  return _a(i), i;
}, Pi = function(e) {
  var t = new rr(e);
  return _a(t), t;
}, Ks = function(e, t) {
  return e instanceof rr ? s0([], [e], t) : e;
}, Qs = function(e) {
  if (e.positionType === "individualShift") {
    for (var t = e.children, a = [t[0]], n = -t[0].shift - t[0].elem.depth, i = n, l = 1; l < t.length; l++) {
      var s = -t[l].shift - i - t[l].elem.depth, o = s - (t[l - 1].elem.height + t[l - 1].elem.depth);
      i = i + s, a.push({
        type: "kern",
        size: o
      }), a.push(t[l]);
    }
    return {
      children: a,
      depth: n
    };
  }
  var m;
  if (e.positionType === "top") {
    for (var f = e.positionData, p = 0; p < e.children.length; p++) {
      var g = e.children[p];
      f -= g.type === "kern" ? g.size : g.elem.height + g.elem.depth;
    }
    m = f;
  } else if (e.positionType === "bottom")
    m = -e.positionData;
  else {
    var w = e.children[0];
    if (w.type !== "elem")
      throw new Error('First child must have type "elem".');
    if (e.positionType === "shift")
      m = -w.elem.depth - e.positionData;
    else if (e.positionType === "firstBaseline")
      m = -w.elem.depth;
    else
      throw new Error("Invalid positionType " + e.positionType + ".");
  }
  return {
    children: e.children,
    depth: m
  };
}, Js = function(e, t) {
  for (var {
    children: a,
    depth: n
  } = Qs(e), i = 0, l = 0; l < a.length; l++) {
    var s = a[l];
    if (s.type === "elem") {
      var o = s.elem;
      i = Math.max(i, o.maxFontSize, o.height);
    }
  }
  i += 2;
  var m = s0(["pstrut"], []);
  m.style.height = q(i);
  for (var f = [], p = n, g = n, w = n, F = 0; F < a.length; F++) {
    var E = a[F];
    if (E.type === "kern")
      w += E.size;
    else {
      var k = E.elem, S = E.wrapperClasses || [], y = E.wrapperStyle || {}, D = s0(S, [m, k], void 0, y);
      D.style.top = q(-i - w - k.depth), E.marginLeft && (D.style.marginLeft = E.marginLeft), E.marginRight && (D.style.marginRight = E.marginRight), f.push(D), w += k.height + k.depth;
    }
    p = Math.min(p, w), g = Math.max(g, w);
  }
  var _ = s0(["vlist"], f);
  _.style.height = q(g);
  var C;
  if (p < 0) {
    var M = s0([], []), R = s0(["vlist"], [M]);
    R.style.height = q(-p);
    var U = s0(["vlist-s"], [new P0("​")]);
    C = [s0(["vlist-r"], [_, U]), s0(["vlist-r"], [R])];
  } else
    C = [s0(["vlist-r"], [_])];
  var I = s0(["vlist-t"], C);
  return C.length === 2 && I.classes.push("vlist-t2"), I.height = g, I.depth = -p, I;
}, $s = (r, e) => {
  var t = s0(["mspace"], [], e), a = ze(r, e);
  return t.style.marginRight = q(a), t;
}, gr = function(e, t, a) {
  var n = "";
  switch (e) {
    case "amsrm":
      n = "AMS";
      break;
    case "textrm":
      n = "Main";
      break;
    case "textsf":
      n = "SansSerif";
      break;
    case "texttt":
      n = "Typewriter";
      break;
    default:
      n = e;
  }
  var i;
  return t === "textbf" && a === "textit" ? i = "BoldItalic" : t === "textbf" ? i = "Bold" : t === "textit" ? i = "Italic" : i = "Regular", n + "-" + i;
}, Hi = {
  // styles
  mathbf: {
    variant: "bold",
    fontName: "Main-Bold"
  },
  mathrm: {
    variant: "normal",
    fontName: "Main-Regular"
  },
  textit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathnormal: {
    variant: "italic",
    fontName: "Math-Italic"
  },
  // "boldsymbol" is missing because they require the use of multiple fonts:
  // Math-BoldItalic and Main-Bold.  This is handled by a special case in
  // makeOrd which ends up calling boldsymbol.
  // families
  mathbb: {
    variant: "double-struck",
    fontName: "AMS-Regular"
  },
  mathcal: {
    variant: "script",
    fontName: "Caligraphic-Regular"
  },
  mathfrak: {
    variant: "fraktur",
    fontName: "Fraktur-Regular"
  },
  mathscr: {
    variant: "script",
    fontName: "Script-Regular"
  },
  mathsf: {
    variant: "sans-serif",
    fontName: "SansSerif-Regular"
  },
  mathtt: {
    variant: "monospace",
    fontName: "Typewriter-Regular"
  }
}, Ui = {
  //   path, width, height
  vec: ["vec", 0.471, 0.714],
  // values from the font glyph
  oiintSize1: ["oiintSize1", 0.957, 0.499],
  // oval to overlay the integrand
  oiintSize2: ["oiintSize2", 1.472, 0.659],
  oiiintSize1: ["oiiintSize1", 1.304, 0.499],
  oiiintSize2: ["oiiintSize2", 1.98, 0.659]
}, e1 = function(e, t) {
  var [a, n, i] = Ui[e], l = new gt(a), s = new nt([l], {
    width: q(n),
    height: q(i),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + q(n),
    viewBox: "0 0 " + 1e3 * n + " " + 1e3 * i,
    preserveAspectRatio: "xMinYMin"
  }), o = qi(["overlay"], [s], t);
  return o.height = i, o.style.height = q(i), o.style.width = q(n), o;
}, T = {
  fontMap: Hi,
  makeSymbol: T0,
  mathsym: Gs,
  makeSpan: s0,
  makeSvgSpan: qi,
  makeLineSpan: Xs,
  makeAnchor: Zs,
  makeFragment: Pi,
  wrapFragment: Ks,
  makeVList: Js,
  makeOrd: Ws,
  makeGlue: $s,
  staticSvg: e1,
  svgData: Ui,
  tryCombineChars: js
}, Be = {
  number: 3,
  unit: "mu"
}, dt = {
  number: 4,
  unit: "mu"
}, Y0 = {
  number: 5,
  unit: "mu"
}, t1 = {
  mord: {
    mop: Be,
    mbin: dt,
    mrel: Y0,
    minner: Be
  },
  mop: {
    mord: Be,
    mop: Be,
    mrel: Y0,
    minner: Be
  },
  mbin: {
    mord: dt,
    mop: dt,
    mopen: dt,
    minner: dt
  },
  mrel: {
    mord: Y0,
    mop: Y0,
    mopen: Y0,
    minner: Y0
  },
  mopen: {},
  mclose: {
    mop: Be,
    mbin: dt,
    mrel: Y0,
    minner: Be
  },
  mpunct: {
    mord: Be,
    mop: Be,
    mrel: Y0,
    mopen: Be,
    mclose: Be,
    mpunct: Be,
    minner: Be
  },
  minner: {
    mord: Be,
    mop: Be,
    mbin: dt,
    mrel: Y0,
    mopen: Be,
    mpunct: Be,
    minner: Be
  }
}, r1 = {
  mord: {
    mop: Be
  },
  mop: {
    mord: Be,
    mop: Be
  },
  mbin: {},
  mrel: {},
  mopen: {},
  mclose: {
    mop: Be
  },
  mpunct: {},
  minner: {
    mop: Be
  }
}, Gi = {}, Tr = {}, Cr = {};
function P(r) {
  for (var {
    type: e,
    names: t,
    props: a,
    handler: n,
    htmlBuilder: i,
    mathmlBuilder: l
  } = r, s = {
    type: e,
    numArgs: a.numArgs,
    argTypes: a.argTypes,
    allowedInArgument: !!a.allowedInArgument,
    allowedInText: !!a.allowedInText,
    allowedInMath: a.allowedInMath === void 0 ? !0 : a.allowedInMath,
    numOptionalArgs: a.numOptionalArgs || 0,
    infix: !!a.infix,
    primitive: !!a.primitive,
    handler: n
  }, o = 0; o < t.length; ++o)
    Gi[t[o]] = s;
  e && (i && (Tr[e] = i), l && (Cr[e] = l));
}
function wt(r) {
  var {
    type: e,
    htmlBuilder: t,
    mathmlBuilder: a
  } = r;
  P({
    type: e,
    names: [],
    props: {
      numArgs: 0
    },
    handler() {
      throw new Error("Should never be called.");
    },
    htmlBuilder: t,
    mathmlBuilder: a
  });
}
var Mr = function(e) {
  return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, Oe = function(e) {
  return e.type === "ordgroup" ? e.body : [e];
}, Rt = T.makeSpan, a1 = ["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"], n1 = ["rightmost", "mrel", "mclose", "mpunct"], i1 = {
  display: Z.DISPLAY,
  text: Z.TEXT,
  script: Z.SCRIPT,
  scriptscript: Z.SCRIPTSCRIPT
}, l1 = {
  mord: "mord",
  mop: "mop",
  mbin: "mbin",
  mrel: "mrel",
  mopen: "mopen",
  mclose: "mclose",
  mpunct: "mpunct",
  minner: "minner"
}, je = function(e, t, a, n) {
  n === void 0 && (n = [null, null]);
  for (var i = [], l = 0; l < e.length; l++) {
    var s = he(e[l], t);
    if (s instanceof rr) {
      var o = s.children;
      i.push(...o);
    } else
      i.push(s);
  }
  if (T.tryCombineChars(i), !a)
    return i;
  var m = t;
  if (e.length === 1) {
    var f = e[0];
    f.type === "sizing" ? m = t.havingSize(f.size) : f.type === "styling" && (m = t.havingStyle(i1[f.style]));
  }
  var p = Rt([n[0] || "leftmost"], [], t), g = Rt([n[1] || "rightmost"], [], t), w = a === "root";
  return Dn(i, (F, E) => {
    var k = E.classes[0], S = F.classes[0];
    k === "mbin" && j.contains(n1, S) ? E.classes[0] = "mord" : S === "mbin" && j.contains(a1, k) && (F.classes[0] = "mord");
  }, {
    node: p
  }, g, w), Dn(i, (F, E) => {
    var k = ga(E), S = ga(F), y = k && S ? F.hasClass("mtight") ? r1[k][S] : t1[k][S] : null;
    if (y)
      return T.makeGlue(y, m);
  }, {
    node: p
  }, g, w), i;
}, Dn = function r(e, t, a, n, i) {
  n && e.push(n);
  for (var l = 0; l < e.length; l++) {
    var s = e[l], o = Vi(s);
    if (o) {
      r(o.children, t, a, null, i);
      continue;
    }
    var m = !s.hasClass("mspace");
    if (m) {
      var f = t(s, a.node);
      f && (a.insertAfter ? a.insertAfter(f) : (e.unshift(f), l++));
    }
    m ? a.node = s : i && s.hasClass("newline") && (a.node = Rt(["leftmost"])), a.insertAfter = /* @__PURE__ */ ((p) => (g) => {
      e.splice(p + 1, 0, g), l++;
    })(l);
  }
  n && e.pop();
}, Vi = function(e) {
  return e instanceof rr || e instanceof Li || e instanceof qr && e.hasClass("enclosing") ? e : null;
}, s1 = function r(e, t) {
  var a = Vi(e);
  if (a) {
    var n = a.children;
    if (n.length) {
      if (t === "right")
        return r(n[n.length - 1], "right");
      if (t === "left")
        return r(n[0], "left");
    }
  }
  return e;
}, ga = function(e, t) {
  return e ? (t && (e = s1(e, t)), l1[e.classes[0]] || null) : null;
}, tr = function(e, t) {
  var a = ["nulldelimiter"].concat(e.baseSizingClasses());
  return Rt(t.concat(a));
}, he = function(e, t, a) {
  if (!e)
    return Rt();
  if (Tr[e.type]) {
    var n = Tr[e.type](e, t);
    if (a && t.size !== a.size) {
      n = Rt(t.sizingClasses(a), [n], t);
      var i = t.sizeMultiplier / a.sizeMultiplier;
      n.height *= i, n.depth *= i;
    }
    return n;
  } else
    throw new W("Got group of unknown type: '" + e.type + "'");
};
function Wi(r) {
  return new rr(r);
}
class C0 {
  constructor(e, t, a) {
    this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = a || [];
  }
  /**
   * Sets an attribute on a MathML node. MathML depends on attributes to convey a
   * semantic content, so this is used heavily.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  /**
   * Gets an attribute on a MathML node.
   */
  getAttribute(e) {
    return this.attributes[e];
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
    this.classes.length > 0 && (e.className = at(this.classes));
    for (var a = 0; a < this.children.length; a++)
      e.appendChild(this.children[a].toNode());
    return e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    var e = "<" + this.type;
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="', e += j.escape(this.attributes[t]), e += '"');
    this.classes.length > 0 && (e += ' class ="' + j.escape(at(this.classes)) + '"'), e += ">";
    for (var a = 0; a < this.children.length; a++)
      e += this.children[a].toMarkup();
    return e += "</" + this.type + ">", e;
  }
  /**
   * Converts the math node into a string, similar to innerText, but escaped.
   */
  toText() {
    return this.children.map((e) => e.toText()).join("");
  }
}
class Kt {
  constructor(e) {
    this.text = void 0, this.text = e;
  }
  /**
   * Converts the text node into a DOM text node.
   */
  toNode() {
    return document.createTextNode(this.text);
  }
  /**
   * Converts the text node into escaped HTML markup
   * (representing the text itself).
   */
  toMarkup() {
    return j.escape(this.toText());
  }
  /**
   * Converts the text node into a string
   * (representing the text itself).
   */
  toText() {
    return this.text;
  }
}
class u1 {
  /**
   * Create a Space node with width given in CSS ems.
   */
  constructor(e) {
    this.width = void 0, this.character = void 0, this.width = e, e >= 0.05555 && e <= 0.05556 ? this.character = " " : e >= 0.1666 && e <= 0.1667 ? this.character = " " : e >= 0.2222 && e <= 0.2223 ? this.character = " " : e >= 0.2777 && e <= 0.2778 ? this.character = "  " : e >= -0.05556 && e <= -0.05555 ? this.character = " ⁣" : e >= -0.1667 && e <= -0.1666 ? this.character = " ⁣" : e >= -0.2223 && e <= -0.2222 ? this.character = " ⁣" : e >= -0.2778 && e <= -0.2777 ? this.character = " ⁣" : this.character = null;
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    if (this.character)
      return document.createTextNode(this.character);
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
    return e.setAttribute("width", q(this.width)), e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + q(this.width) + '"/>';
  }
  /**
   * Converts the math node into a string, similar to innerText.
   */
  toText() {
    return this.character ? this.character : " ";
  }
}
var N = {
  MathNode: C0,
  TextNode: Kt,
  SpaceNode: u1,
  newDocumentFragment: Wi
}, x0 = function(e, t, a) {
  return qe[t][e] && qe[t][e].replace && e.charCodeAt(0) !== 55349 && !(Oi.hasOwnProperty(e) && a && (a.fontFamily && a.fontFamily.slice(4, 6) === "tt" || a.font && a.font.slice(4, 6) === "tt")) && (e = qe[t][e].replace), new N.TextNode(e);
}, Ea = function(e) {
  return e.length === 1 ? e[0] : new N.MathNode("mrow", e);
}, Ta = function(e, t) {
  if (t.fontFamily === "texttt")
    return "monospace";
  if (t.fontFamily === "textsf")
    return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
  if (t.fontShape === "textit" && t.fontWeight === "textbf")
    return "bold-italic";
  if (t.fontShape === "textit")
    return "italic";
  if (t.fontWeight === "textbf")
    return "bold";
  var a = t.font;
  if (!a || a === "mathnormal")
    return null;
  var n = e.mode;
  if (a === "mathit")
    return "italic";
  if (a === "boldsymbol")
    return e.type === "textord" ? "bold" : "bold-italic";
  if (a === "mathbf")
    return "bold";
  if (a === "mathbb")
    return "double-struck";
  if (a === "mathfrak")
    return "fraktur";
  if (a === "mathscr" || a === "mathcal")
    return "script";
  if (a === "mathsf")
    return "sans-serif";
  if (a === "mathtt")
    return "monospace";
  var i = e.text;
  if (j.contains(["\\imath", "\\jmath"], i))
    return null;
  qe[n][i] && qe[n][i].replace && (i = qe[n][i].replace);
  var l = T.fontMap[a].fontName;
  return Fa(i, l, n) ? T.fontMap[a].variant : null;
}, b0 = function(e, t, a) {
  if (e.length === 1) {
    var n = De(e[0], t);
    return a && n instanceof C0 && n.type === "mo" && (n.setAttribute("lspace", "0em"), n.setAttribute("rspace", "0em")), [n];
  }
  for (var i = [], l, s = 0; s < e.length; s++) {
    var o = De(e[s], t);
    if (o instanceof C0 && l instanceof C0) {
      if (o.type === "mtext" && l.type === "mtext" && o.getAttribute("mathvariant") === l.getAttribute("mathvariant")) {
        l.children.push(...o.children);
        continue;
      } else if (o.type === "mn" && l.type === "mn") {
        l.children.push(...o.children);
        continue;
      } else if (o.type === "mi" && o.children.length === 1 && l.type === "mn") {
        var m = o.children[0];
        if (m instanceof Kt && m.text === ".") {
          l.children.push(...o.children);
          continue;
        }
      } else if (l.type === "mi" && l.children.length === 1) {
        var f = l.children[0];
        if (f instanceof Kt && f.text === "̸" && (o.type === "mo" || o.type === "mi" || o.type === "mn")) {
          var p = o.children[0];
          p instanceof Kt && p.text.length > 0 && (p.text = p.text.slice(0, 1) + "̸" + p.text.slice(1), i.pop());
        }
      }
    }
    i.push(o), l = o;
  }
  return i;
}, it = function(e, t, a) {
  return Ea(b0(e, t, a));
}, De = function(e, t) {
  if (!e)
    return new N.MathNode("mrow");
  if (Cr[e.type]) {
    var a = Cr[e.type](e, t);
    return a;
  } else
    throw new W("Got group of unknown type: '" + e.type + "'");
}, o1 = {
  widehat: "^",
  widecheck: "ˇ",
  widetilde: "~",
  utilde: "~",
  overleftarrow: "←",
  underleftarrow: "←",
  xleftarrow: "←",
  overrightarrow: "→",
  underrightarrow: "→",
  xrightarrow: "→",
  underbrace: "⏟",
  overbrace: "⏞",
  overgroup: "⏠",
  undergroup: "⏡",
  overleftrightarrow: "↔",
  underleftrightarrow: "↔",
  xleftrightarrow: "↔",
  Overrightarrow: "⇒",
  xRightarrow: "⇒",
  overleftharpoon: "↼",
  xleftharpoonup: "↼",
  overrightharpoon: "⇀",
  xrightharpoonup: "⇀",
  xLeftarrow: "⇐",
  xLeftrightarrow: "⇔",
  xhookleftarrow: "↩",
  xhookrightarrow: "↪",
  xmapsto: "↦",
  xrightharpoondown: "⇁",
  xleftharpoondown: "↽",
  xrightleftharpoons: "⇌",
  xleftrightharpoons: "⇋",
  xtwoheadleftarrow: "↞",
  xtwoheadrightarrow: "↠",
  xlongequal: "=",
  xtofrom: "⇄",
  xrightleftarrows: "⇄",
  xrightequilibrium: "⇌",
  // Not a perfect match.
  xleftequilibrium: "⇋",
  // None better available.
  "\\cdrightarrow": "→",
  "\\cdleftarrow": "←",
  "\\cdlongequal": "="
}, c1 = function(e) {
  var t = new N.MathNode("mo", [new N.TextNode(o1[e.replace(/^\\/, "")])]);
  return t.setAttribute("stretchy", "true"), t;
}, h1 = {
  //   path(s), minWidth, height, align
  overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
  "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
  // CD minwwidth2.5pc
  xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
  "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
  Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
  xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
  xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
  overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
  overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
  xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
  "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
  xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
  xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
  overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
  underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
  underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
  xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
  xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
  xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
  xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
  xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
  overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
  undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
  xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
  xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
  // The next three arrows are from the mhchem package.
  // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
  // document as \xrightarrow or \xrightleftharpoons. Those have
  // min-length = 1.75em, so we set min-length on these next three to match.
  xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
  xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
  xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
}, m1 = function(e) {
  return e.type === "ordgroup" ? e.body.length : 1;
}, f1 = function(e, t) {
  function a() {
    var s = 4e5, o = e.label.slice(1);
    if (j.contains(["widehat", "widecheck", "widetilde", "utilde"], o)) {
      var m = e, f = m1(m.base), p, g, w;
      if (f > 5)
        o === "widehat" || o === "widecheck" ? (p = 420, s = 2364, w = 0.42, g = o + "4") : (p = 312, s = 2340, w = 0.34, g = "tilde4");
      else {
        var F = [1, 1, 2, 2, 3, 3][f];
        o === "widehat" || o === "widecheck" ? (s = [0, 1062, 2364, 2364, 2364][F], p = [0, 239, 300, 360, 420][F], w = [0, 0.24, 0.3, 0.3, 0.36, 0.42][F], g = o + F) : (s = [0, 600, 1033, 2339, 2340][F], p = [0, 260, 286, 306, 312][F], w = [0, 0.26, 0.286, 0.3, 0.306, 0.34][F], g = "tilde" + F);
      }
      var E = new gt(g), k = new nt([E], {
        width: "100%",
        height: q(w),
        viewBox: "0 0 " + s + " " + p,
        preserveAspectRatio: "none"
      });
      return {
        span: T.makeSvgSpan([], [k], t),
        minWidth: 0,
        height: w
      };
    } else {
      var S = [], y = h1[o], [D, _, C] = y, M = C / 1e3, R = D.length, U, I;
      if (R === 1) {
        var O = y[3];
        U = ["hide-tail"], I = [O];
      } else if (R === 2)
        U = ["halfarrow-left", "halfarrow-right"], I = ["xMinYMin", "xMaxYMin"];
      else if (R === 3)
        U = ["brace-left", "brace-center", "brace-right"], I = ["xMinYMin", "xMidYMin", "xMaxYMin"];
      else
        throw new Error(`Correct katexImagesData or update code here to support
                    ` + R + " children.");
      for (var J = 0; J < R; J++) {
        var le = new gt(D[J]), se = new nt([le], {
          width: "400em",
          height: q(M),
          viewBox: "0 0 " + s + " " + C,
          preserveAspectRatio: I[J] + " slice"
        }), Te = T.makeSvgSpan([U[J]], [se], t);
        if (R === 1)
          return {
            span: Te,
            minWidth: _,
            height: M
          };
        Te.style.height = q(M), S.push(Te);
      }
      return {
        span: T.makeSpan(["stretchy"], S, t),
        minWidth: _,
        height: M
      };
    }
  }
  var {
    span: n,
    minWidth: i,
    height: l
  } = a();
  return n.height = l, n.style.height = q(l), i > 0 && (n.style.minWidth = q(i)), n;
}, d1 = function(e, t, a, n, i) {
  var l, s = e.height + e.depth + a + n;
  if (/fbox|color|angl/.test(t)) {
    if (l = T.makeSpan(["stretchy", t], [], i), t === "fbox") {
      var o = i.color && i.getColor();
      o && (l.style.borderColor = o);
    }
  } else {
    var m = [];
    /^[bx]cancel$/.test(t) && m.push(new dn({
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%",
      "stroke-width": "0.046em"
    })), /^x?cancel$/.test(t) && m.push(new dn({
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0",
      "stroke-width": "0.046em"
    }));
    var f = new nt(m, {
      width: "100%",
      height: q(s)
    });
    l = T.makeSvgSpan([], [f], i);
  }
  return l.height = s, l.style.height = q(s), l;
}, K0 = {
  encloseSpan: d1,
  mathMLnode: c1,
  svgSpan: f1
};
function ae(r, e) {
  if (!r || r.type !== e)
    throw new Error("Expected node of type " + e + ", but got " + (r ? "node of type " + r.type : String(r)));
  return r;
}
function Ca(r) {
  var e = Ur(r);
  if (!e)
    throw new Error("Expected node of symbol group type, but got " + (r ? "node of type " + r.type : String(r)));
  return e;
}
function Ur(r) {
  return r && (r.type === "atom" || Hs.hasOwnProperty(r.type)) ? r : null;
}
var Ma = (r, e) => {
  var t, a, n;
  r && r.type === "supsub" ? (a = ae(r.base, "accent"), t = a.base, r.base = t, n = Ps(he(r, e)), r.base = a) : (a = ae(r, "accent"), t = a.base);
  var i = he(t, e.havingCrampedStyle()), l = a.isShifty && j.isCharacterBox(t), s = 0;
  if (l) {
    var o = j.getBaseElem(t), m = he(o, e.havingCrampedStyle());
    s = pn(m).skew;
  }
  var f = a.label === "\\c", p = f ? i.height + i.depth : Math.min(i.height, e.fontMetrics().xHeight), g;
  if (a.isStretchy)
    g = K0.svgSpan(a, e), g = T.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "elem",
        elem: g,
        wrapperClasses: ["svg-align"],
        wrapperStyle: s > 0 ? {
          width: "calc(100% - " + q(2 * s) + ")",
          marginLeft: q(2 * s)
        } : void 0
      }]
    }, e);
  else {
    var w, F;
    a.label === "\\vec" ? (w = T.staticSvg("vec", e), F = T.svgData.vec[1]) : (w = T.makeOrd({
      mode: a.mode,
      text: a.label
    }, e, "textord"), w = pn(w), w.italic = 0, F = w.width, f && (p += w.depth)), g = T.makeSpan(["accent-body"], [w]);
    var E = a.label === "\\textcircled";
    E && (g.classes.push("accent-full"), p = i.height);
    var k = s;
    E || (k -= F / 2), g.style.left = q(k), a.label === "\\textcircled" && (g.style.top = ".2em"), g = T.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "kern",
        size: -p
      }, {
        type: "elem",
        elem: g
      }]
    }, e);
  }
  var S = T.makeSpan(["mord", "accent"], [g], e);
  return n ? (n.children[0] = S, n.height = Math.max(S.height, n.height), n.classes[0] = "mord", n) : S;
}, Yi = (r, e) => {
  var t = r.isStretchy ? K0.mathMLnode(r.label) : new N.MathNode("mo", [x0(r.label, r.mode)]), a = new N.MathNode("mover", [De(r.base, e), t]);
  return a.setAttribute("accent", "true"), a;
}, p1 = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map((r) => "\\" + r).join("|"));
P({
  type: "accent",
  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var t = Mr(e[0]), a = !p1.test(r.funcName), n = !a || r.funcName === "\\widehat" || r.funcName === "\\widetilde" || r.funcName === "\\widecheck";
    return {
      type: "accent",
      mode: r.parser.mode,
      label: r.funcName,
      isStretchy: a,
      isShifty: n,
      base: t
    };
  },
  htmlBuilder: Ma,
  mathmlBuilder: Yi
});
P({
  type: "accent",
  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    // unless in strict mode
    argTypes: ["primitive"]
  },
  handler: (r, e) => {
    var t = e[0], a = r.parser.mode;
    return a === "math" && (r.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + r.funcName + " works only in text mode"), a = "text"), {
      type: "accent",
      mode: a,
      label: r.funcName,
      isStretchy: !1,
      isShifty: !0,
      base: t
    };
  },
  htmlBuilder: Ma,
  mathmlBuilder: Yi
});
P({
  type: "accentUnder",
  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "accentUnder",
      mode: t.mode,
      label: a,
      base: n
    };
  },
  htmlBuilder: (r, e) => {
    var t = he(r.base, e), a = K0.svgSpan(r, e), n = r.label === "\\utilde" ? 0.12 : 0, i = T.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "elem",
        elem: a,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: n
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return T.makeSpan(["mord", "accentunder"], [i], e);
  },
  mathmlBuilder: (r, e) => {
    var t = K0.mathMLnode(r.label), a = new N.MathNode("munder", [De(r.base, e), t]);
    return a.setAttribute("accentunder", "true"), a;
  }
});
var vr = (r) => {
  var e = new N.MathNode("mpadded", r ? [r] : []);
  return e.setAttribute("width", "+0.6em"), e.setAttribute("lspace", "0.3em"), e;
};
P({
  type: "xArrow",
  names: [
    "\\xleftarrow",
    "\\xrightarrow",
    "\\xLeftarrow",
    "\\xRightarrow",
    "\\xleftrightarrow",
    "\\xLeftrightarrow",
    "\\xhookleftarrow",
    "\\xhookrightarrow",
    "\\xmapsto",
    "\\xrightharpoondown",
    "\\xrightharpoonup",
    "\\xleftharpoondown",
    "\\xleftharpoonup",
    "\\xrightleftharpoons",
    "\\xleftrightharpoons",
    "\\xlongequal",
    "\\xtwoheadrightarrow",
    "\\xtwoheadleftarrow",
    "\\xtofrom",
    // The next 3 functions are here to support the mhchem extension.
    // Direct use of these functions is discouraged and may break someday.
    "\\xrightleftarrows",
    "\\xrightequilibrium",
    "\\xleftequilibrium",
    // The next 3 functions are here only to support the {CD} environment.
    "\\\\cdrightarrow",
    "\\\\cdleftarrow",
    "\\\\cdlongequal"
  ],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(r, e, t) {
    var {
      parser: a,
      funcName: n
    } = r;
    return {
      type: "xArrow",
      mode: a.mode,
      label: n,
      body: e[0],
      below: t[0]
    };
  },
  // Flow is unable to correctly infer the type of `group`, even though it's
  // unambiguously determined from the passed-in `type` above.
  htmlBuilder(r, e) {
    var t = e.style, a = e.havingStyle(t.sup()), n = T.wrapFragment(he(r.body, a, e), e), i = r.label.slice(0, 2) === "\\x" ? "x" : "cd";
    n.classes.push(i + "-arrow-pad");
    var l;
    r.below && (a = e.havingStyle(t.sub()), l = T.wrapFragment(he(r.below, a, e), e), l.classes.push(i + "-arrow-pad"));
    var s = K0.svgSpan(r, e), o = -e.fontMetrics().axisHeight + 0.5 * s.height, m = -e.fontMetrics().axisHeight - 0.5 * s.height - 0.111;
    (n.depth > 0.25 || r.label === "\\xleftequilibrium") && (m -= n.depth);
    var f;
    if (l) {
      var p = -e.fontMetrics().axisHeight + l.height + 0.5 * s.height + 0.111;
      f = T.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: n,
          shift: m
        }, {
          type: "elem",
          elem: s,
          shift: o
        }, {
          type: "elem",
          elem: l,
          shift: p
        }]
      }, e);
    } else
      f = T.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: n,
          shift: m
        }, {
          type: "elem",
          elem: s,
          shift: o
        }]
      }, e);
    return f.children[0].children[0].children[1].classes.push("svg-align"), T.makeSpan(["mrel", "x-arrow"], [f], e);
  },
  mathmlBuilder(r, e) {
    var t = K0.mathMLnode(r.label);
    t.setAttribute("minsize", r.label.charAt(0) === "x" ? "1.75em" : "3.0em");
    var a;
    if (r.body) {
      var n = vr(De(r.body, e));
      if (r.below) {
        var i = vr(De(r.below, e));
        a = new N.MathNode("munderover", [t, i, n]);
      } else
        a = new N.MathNode("mover", [t, n]);
    } else if (r.below) {
      var l = vr(De(r.below, e));
      a = new N.MathNode("munder", [t, l]);
    } else
      a = vr(), a = new N.MathNode("mover", [t, a]);
    return a;
  }
});
var g1 = T.makeSpan;
function ji(r, e) {
  var t = je(r.body, e, !0);
  return g1([r.mclass], t, e);
}
function Xi(r, e) {
  var t, a = b0(r.body, e);
  return r.mclass === "minner" ? t = new N.MathNode("mpadded", a) : r.mclass === "mord" ? r.isCharacterBox ? (t = a[0], t.type = "mi") : t = new N.MathNode("mi", a) : (r.isCharacterBox ? (t = a[0], t.type = "mo") : t = new N.MathNode("mo", a), r.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : r.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : r.mclass === "mopen" || r.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : r.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t;
}
P({
  type: "mclass",
  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "mclass",
      mode: t.mode,
      mclass: "m" + a.slice(5),
      // TODO(kevinb): don't prefix with 'm'
      body: Oe(n),
      isCharacterBox: j.isCharacterBox(n)
    };
  },
  htmlBuilder: ji,
  mathmlBuilder: Xi
});
var Gr = (r) => {
  var e = r.type === "ordgroup" && r.body.length ? r.body[0] : r;
  return e.type === "atom" && (e.family === "bin" || e.family === "rel") ? "m" + e.family : "mord";
};
P({
  type: "mclass",
  names: ["\\@binrel"],
  props: {
    numArgs: 2
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "mclass",
      mode: t.mode,
      mclass: Gr(e[0]),
      body: Oe(e[1]),
      isCharacterBox: j.isCharacterBox(e[1])
    };
  }
});
P({
  type: "mclass",
  names: ["\\stackrel", "\\overset", "\\underset"],
  props: {
    numArgs: 2
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = e[1], i = e[0], l;
    a !== "\\stackrel" ? l = Gr(n) : l = "mrel";
    var s = {
      type: "op",
      mode: n.mode,
      limits: !0,
      alwaysHandleSupSub: !0,
      parentIsSupSub: !1,
      symbol: !1,
      suppressBaseShift: a !== "\\stackrel",
      body: Oe(n)
    }, o = {
      type: "supsub",
      mode: i.mode,
      base: s,
      sup: a === "\\underset" ? null : i,
      sub: a === "\\underset" ? i : null
    };
    return {
      type: "mclass",
      mode: t.mode,
      mclass: l,
      body: [o],
      isCharacterBox: j.isCharacterBox(o)
    };
  },
  htmlBuilder: ji,
  mathmlBuilder: Xi
});
P({
  type: "pmb",
  names: ["\\pmb"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "pmb",
      mode: t.mode,
      mclass: Gr(e[0]),
      body: Oe(e[0])
    };
  },
  htmlBuilder(r, e) {
    var t = je(r.body, e, !0), a = T.makeSpan([r.mclass], t, e);
    return a.style.textShadow = "0.02em 0.01em 0.04px", a;
  },
  mathmlBuilder(r, e) {
    var t = b0(r.body, e), a = new N.MathNode("mstyle", t);
    return a.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), a;
  }
});
var v1 = {
  ">": "\\\\cdrightarrow",
  "<": "\\\\cdleftarrow",
  "=": "\\\\cdlongequal",
  A: "\\uparrow",
  V: "\\downarrow",
  "|": "\\Vert",
  ".": "no arrow"
}, xn = () => ({
  type: "styling",
  body: [],
  mode: "math",
  style: "display"
}), An = (r) => r.type === "textord" && r.text === "@", b1 = (r, e) => (r.type === "mathord" || r.type === "atom") && r.text === e;
function y1(r, e, t) {
  var a = v1[r];
  switch (a) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow":
      return t.callFunction(a, [e[0]], [e[1]]);
    case "\\uparrow":
    case "\\downarrow": {
      var n = t.callFunction("\\\\cdleft", [e[0]], []), i = {
        type: "atom",
        text: a,
        mode: "math",
        family: "rel"
      }, l = t.callFunction("\\Big", [i], []), s = t.callFunction("\\\\cdright", [e[1]], []), o = {
        type: "ordgroup",
        mode: "math",
        body: [n, l, s]
      };
      return t.callFunction("\\\\cdparent", [o], []);
    }
    case "\\\\cdlongequal":
      return t.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert": {
      var m = {
        type: "textord",
        text: "\\Vert",
        mode: "math"
      };
      return t.callFunction("\\Big", [m], []);
    }
    default:
      return {
        type: "textord",
        text: " ",
        mode: "math"
      };
  }
}
function w1(r) {
  var e = [];
  for (r.gullet.beginGroup(), r.gullet.macros.set("\\cr", "\\\\\\relax"), r.gullet.beginGroup(); ; ) {
    e.push(r.parseExpression(!1, "\\\\")), r.gullet.endGroup(), r.gullet.beginGroup();
    var t = r.fetch().text;
    if (t === "&" || t === "\\\\")
      r.consume();
    else if (t === "\\end") {
      e[e.length - 1].length === 0 && e.pop();
      break;
    } else
      throw new W("Expected \\\\ or \\cr or \\end", r.nextToken);
  }
  for (var a = [], n = [a], i = 0; i < e.length; i++) {
    for (var l = e[i], s = xn(), o = 0; o < l.length; o++)
      if (!An(l[o]))
        s.body.push(l[o]);
      else {
        a.push(s), o += 1;
        var m = Ca(l[o]).text, f = new Array(2);
        if (f[0] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, f[1] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, !("=|.".indexOf(m) > -1)) if ("<>AV".indexOf(m) > -1)
          for (var p = 0; p < 2; p++) {
            for (var g = !0, w = o + 1; w < l.length; w++) {
              if (b1(l[w], m)) {
                g = !1, o = w;
                break;
              }
              if (An(l[w]))
                throw new W("Missing a " + m + " character to complete a CD arrow.", l[w]);
              f[p].body.push(l[w]);
            }
            if (g)
              throw new W("Missing a " + m + " character to complete a CD arrow.", l[o]);
          }
        else
          throw new W('Expected one of "<>AV=|." after @', l[o]);
        var F = y1(m, f, r), E = {
          type: "styling",
          body: [F],
          mode: "math",
          style: "display"
          // CD is always displaystyle.
        };
        a.push(E), s = xn();
      }
    i % 2 === 0 ? a.push(s) : a.shift(), a = [], n.push(a);
  }
  r.gullet.endGroup(), r.gullet.endGroup();
  var k = new Array(n[0].length).fill({
    type: "align",
    align: "c",
    pregap: 0.25,
    // CD package sets \enskip between columns.
    postgap: 0.25
    // So pre and post each get half an \enskip, i.e. 0.25em.
  });
  return {
    type: "array",
    mode: "math",
    body: n,
    arraystretch: 1,
    addJot: !0,
    rowGaps: [null],
    cols: k,
    colSeparationType: "CD",
    hLinesBeforeRow: new Array(n.length + 1).fill([])
  };
}
P({
  type: "cdlabel",
  names: ["\\\\cdleft", "\\\\cdright"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r;
    return {
      type: "cdlabel",
      mode: t.mode,
      side: a.slice(4),
      label: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = e.havingStyle(e.style.sup()), a = T.wrapFragment(he(r.label, t, e), e);
    return a.classes.push("cd-label-" + r.side), a.style.bottom = q(0.8 - a.depth), a.height = 0, a.depth = 0, a;
  },
  mathmlBuilder(r, e) {
    var t = new N.MathNode("mrow", [De(r.label, e)]);
    return t = new N.MathNode("mpadded", [t]), t.setAttribute("width", "0"), r.side === "left" && t.setAttribute("lspace", "-1width"), t.setAttribute("voffset", "0.7em"), t = new N.MathNode("mstyle", [t]), t.setAttribute("displaystyle", "false"), t.setAttribute("scriptlevel", "1"), t;
  }
});
P({
  type: "cdlabelparent",
  names: ["\\\\cdparent"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "cdlabelparent",
      mode: t.mode,
      fragment: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = T.wrapFragment(he(r.fragment, e), e);
    return t.classes.push("cd-vert-arrow"), t;
  },
  mathmlBuilder(r, e) {
    return new N.MathNode("mrow", [De(r.fragment, e)]);
  }
});
P({
  type: "textord",
  names: ["\\@char"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    for (var {
      parser: t
    } = r, a = ae(e[0], "ordgroup"), n = a.body, i = "", l = 0; l < n.length; l++) {
      var s = ae(n[l], "textord");
      i += s.text;
    }
    var o = parseInt(i), m;
    if (isNaN(o))
      throw new W("\\@char has non-numeric argument " + i);
    if (o < 0 || o >= 1114111)
      throw new W("\\@char with invalid code point " + i);
    return o <= 65535 ? m = String.fromCharCode(o) : (o -= 65536, m = String.fromCharCode((o >> 10) + 55296, (o & 1023) + 56320)), {
      type: "textord",
      mode: t.mode,
      text: m
    };
  }
});
var Zi = (r, e) => {
  var t = je(r.body, e.withColor(r.color), !1);
  return T.makeFragment(t);
}, Ki = (r, e) => {
  var t = b0(r.body, e.withColor(r.color)), a = new N.MathNode("mstyle", t);
  return a.setAttribute("mathcolor", r.color), a;
};
P({
  type: "color",
  names: ["\\textcolor"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "original"]
  },
  handler(r, e) {
    var {
      parser: t
    } = r, a = ae(e[0], "color-token").color, n = e[1];
    return {
      type: "color",
      mode: t.mode,
      color: a,
      body: Oe(n)
    };
  },
  htmlBuilder: Zi,
  mathmlBuilder: Ki
});
P({
  type: "color",
  names: ["\\color"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    argTypes: ["color"]
  },
  handler(r, e) {
    var {
      parser: t,
      breakOnTokenText: a
    } = r, n = ae(e[0], "color-token").color;
    t.gullet.macros.set("\\current@color", n);
    var i = t.parseExpression(!0, a);
    return {
      type: "color",
      mode: t.mode,
      color: n,
      body: i
    };
  },
  htmlBuilder: Zi,
  mathmlBuilder: Ki
});
P({
  type: "cr",
  names: ["\\\\"],
  props: {
    numArgs: 0,
    numOptionalArgs: 0,
    allowedInText: !0
  },
  handler(r, e, t) {
    var {
      parser: a
    } = r, n = a.gullet.future().text === "[" ? a.parseSizeGroup(!0) : null, i = !a.settings.displayMode || !a.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
    return {
      type: "cr",
      mode: a.mode,
      newLine: i,
      size: n && ae(n, "size").value
    };
  },
  // The following builders are called only at the top level,
  // not within tabular/array environments.
  htmlBuilder(r, e) {
    var t = T.makeSpan(["mspace"], [], e);
    return r.newLine && (t.classes.push("newline"), r.size && (t.style.marginTop = q(ze(r.size, e)))), t;
  },
  mathmlBuilder(r, e) {
    var t = new N.MathNode("mspace");
    return r.newLine && (t.setAttribute("linebreak", "newline"), r.size && t.setAttribute("height", q(ze(r.size, e)))), t;
  }
});
var va = {
  "\\global": "\\global",
  "\\long": "\\\\globallong",
  "\\\\globallong": "\\\\globallong",
  "\\def": "\\gdef",
  "\\gdef": "\\gdef",
  "\\edef": "\\xdef",
  "\\xdef": "\\xdef",
  "\\let": "\\\\globallet",
  "\\futurelet": "\\\\globalfuture"
}, Qi = (r) => {
  var e = r.text;
  if (/^(?:[\\{}$&#^_]|EOF)$/.test(e))
    throw new W("Expected a control sequence", r);
  return e;
}, k1 = (r) => {
  var e = r.gullet.popToken();
  return e.text === "=" && (e = r.gullet.popToken(), e.text === " " && (e = r.gullet.popToken())), e;
}, Ji = (r, e, t, a) => {
  var n = r.gullet.macros.get(t.text);
  n == null && (t.noexpand = !0, n = {
    tokens: [t],
    numArgs: 0,
    // reproduce the same behavior in expansion
    unexpandable: !r.gullet.isExpandable(t.text)
  }), r.gullet.macros.set(e, n, a);
};
P({
  type: "internal",
  names: [
    "\\global",
    "\\long",
    "\\\\globallong"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    e.consumeSpaces();
    var a = e.fetch();
    if (va[a.text])
      return (t === "\\global" || t === "\\\\globallong") && (a.text = va[a.text]), ae(e.parseFunction(), "internal");
    throw new W("Invalid token after macro prefix", a);
  }
});
P({
  type: "internal",
  names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, a = e.gullet.popToken(), n = a.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(n))
      throw new W("Expected a control sequence", a);
    for (var i = 0, l, s = [[]]; e.gullet.future().text !== "{"; )
      if (a = e.gullet.popToken(), a.text === "#") {
        if (e.gullet.future().text === "{") {
          l = e.gullet.future(), s[i].push("{");
          break;
        }
        if (a = e.gullet.popToken(), !/^[1-9]$/.test(a.text))
          throw new W('Invalid argument number "' + a.text + '"');
        if (parseInt(a.text) !== i + 1)
          throw new W('Argument number "' + a.text + '" out of order');
        i++, s.push([]);
      } else {
        if (a.text === "EOF")
          throw new W("Expected a macro definition");
        s[i].push(a.text);
      }
    var {
      tokens: o
    } = e.gullet.consumeArg();
    return l && o.unshift(l), (t === "\\edef" || t === "\\xdef") && (o = e.gullet.expandTokens(o), o.reverse()), e.gullet.macros.set(n, {
      tokens: o,
      numArgs: i,
      delimiters: s
    }, t === va[t]), {
      type: "internal",
      mode: e.mode
    };
  }
});
P({
  type: "internal",
  names: [
    "\\let",
    "\\\\globallet"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, a = Qi(e.gullet.popToken());
    e.gullet.consumeSpaces();
    var n = k1(e);
    return Ji(e, a, n, t === "\\\\globallet"), {
      type: "internal",
      mode: e.mode
    };
  }
});
P({
  type: "internal",
  names: [
    "\\futurelet",
    "\\\\globalfuture"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, a = Qi(e.gullet.popToken()), n = e.gullet.popToken(), i = e.gullet.popToken();
    return Ji(e, a, i, t === "\\\\globalfuture"), e.gullet.pushToken(i), e.gullet.pushToken(n), {
      type: "internal",
      mode: e.mode
    };
  }
});
var Zt = function(e, t, a) {
  var n = qe.math[e] && qe.math[e].replace, i = Fa(n || e, t, a);
  if (!i)
    throw new Error("Unsupported symbol " + e + " and font size " + t + ".");
  return i;
}, Ba = function(e, t, a, n) {
  var i = a.havingBaseStyle(t), l = T.makeSpan(n.concat(i.sizingClasses(a)), [e], a), s = i.sizeMultiplier / a.sizeMultiplier;
  return l.height *= s, l.depth *= s, l.maxFontSize = i.sizeMultiplier, l;
}, $i = function(e, t, a) {
  var n = t.havingBaseStyle(a), i = (1 - t.sizeMultiplier / n.sizeMultiplier) * t.fontMetrics().axisHeight;
  e.classes.push("delimcenter"), e.style.top = q(i), e.height -= i, e.depth += i;
}, D1 = function(e, t, a, n, i, l) {
  var s = T.makeSymbol(e, "Main-Regular", i, n), o = Ba(s, t, n, l);
  return a && $i(o, n, t), o;
}, x1 = function(e, t, a, n) {
  return T.makeSymbol(e, "Size" + t + "-Regular", a, n);
}, el = function(e, t, a, n, i, l) {
  var s = x1(e, t, i, n), o = Ba(T.makeSpan(["delimsizing", "size" + t], [s], n), Z.TEXT, n, l);
  return a && $i(o, n, Z.TEXT), o;
}, Qr = function(e, t, a) {
  var n;
  t === "Size1-Regular" ? n = "delim-size1" : n = "delim-size4";
  var i = T.makeSpan(["delimsizinginner", n], [T.makeSpan([], [T.makeSymbol(e, t, a)])]);
  return {
    type: "elem",
    elem: i
  };
}, Jr = function(e, t, a) {
  var n = j0["Size4-Regular"][e.charCodeAt(0)] ? j0["Size4-Regular"][e.charCodeAt(0)][4] : j0["Size1-Regular"][e.charCodeAt(0)][4], i = new gt("inner", Rs(e, Math.round(1e3 * t))), l = new nt([i], {
    width: q(n),
    height: q(t),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + q(n),
    viewBox: "0 0 " + 1e3 * n + " " + Math.round(1e3 * t),
    preserveAspectRatio: "xMinYMin"
  }), s = T.makeSvgSpan([], [l], a);
  return s.height = t, s.style.height = q(t), s.style.width = q(n), {
    type: "elem",
    elem: s
  };
}, ba = 8e-3, br = {
  type: "kern",
  size: -1 * ba
}, A1 = ["|", "\\lvert", "\\rvert", "\\vert"], S1 = ["\\|", "\\lVert", "\\rVert", "\\Vert"], tl = function(e, t, a, n, i, l) {
  var s, o, m, f, p = "", g = 0;
  s = m = f = e, o = null;
  var w = "Size1-Regular";
  e === "\\uparrow" ? m = f = "⏐" : e === "\\Uparrow" ? m = f = "‖" : e === "\\downarrow" ? s = m = "⏐" : e === "\\Downarrow" ? s = m = "‖" : e === "\\updownarrow" ? (s = "\\uparrow", m = "⏐", f = "\\downarrow") : e === "\\Updownarrow" ? (s = "\\Uparrow", m = "‖", f = "\\Downarrow") : j.contains(A1, e) ? (m = "∣", p = "vert", g = 333) : j.contains(S1, e) ? (m = "∥", p = "doublevert", g = 556) : e === "[" || e === "\\lbrack" ? (s = "⎡", m = "⎢", f = "⎣", w = "Size4-Regular", p = "lbrack", g = 667) : e === "]" || e === "\\rbrack" ? (s = "⎤", m = "⎥", f = "⎦", w = "Size4-Regular", p = "rbrack", g = 667) : e === "\\lfloor" || e === "⌊" ? (m = s = "⎢", f = "⎣", w = "Size4-Regular", p = "lfloor", g = 667) : e === "\\lceil" || e === "⌈" ? (s = "⎡", m = f = "⎢", w = "Size4-Regular", p = "lceil", g = 667) : e === "\\rfloor" || e === "⌋" ? (m = s = "⎥", f = "⎦", w = "Size4-Regular", p = "rfloor", g = 667) : e === "\\rceil" || e === "⌉" ? (s = "⎤", m = f = "⎥", w = "Size4-Regular", p = "rceil", g = 667) : e === "(" || e === "\\lparen" ? (s = "⎛", m = "⎜", f = "⎝", w = "Size4-Regular", p = "lparen", g = 875) : e === ")" || e === "\\rparen" ? (s = "⎞", m = "⎟", f = "⎠", w = "Size4-Regular", p = "rparen", g = 875) : e === "\\{" || e === "\\lbrace" ? (s = "⎧", o = "⎨", f = "⎩", m = "⎪", w = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (s = "⎫", o = "⎬", f = "⎭", m = "⎪", w = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (s = "⎧", f = "⎩", m = "⎪", w = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (s = "⎫", f = "⎭", m = "⎪", w = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (s = "⎧", f = "⎭", m = "⎪", w = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (s = "⎫", f = "⎩", m = "⎪", w = "Size4-Regular");
  var F = Zt(s, w, i), E = F.height + F.depth, k = Zt(m, w, i), S = k.height + k.depth, y = Zt(f, w, i), D = y.height + y.depth, _ = 0, C = 1;
  if (o !== null) {
    var M = Zt(o, w, i);
    _ = M.height + M.depth, C = 2;
  }
  var R = E + D + _, U = Math.max(0, Math.ceil((t - R) / (C * S))), I = R + U * C * S, O = n.fontMetrics().axisHeight;
  a && (O *= n.sizeMultiplier);
  var J = I / 2 - O, le = [];
  if (p.length > 0) {
    var se = I - E - D, Te = Math.round(I * 1e3), Ue = Ns(p, Math.round(se * 1e3)), Ze = new gt(p, Ue), a0 = (g / 1e3).toFixed(3) + "em", ge = (Te / 1e3).toFixed(3) + "em", Le = new nt([Ze], {
      width: a0,
      height: ge,
      viewBox: "0 0 " + g + " " + Te
    }), ve = T.makeSvgSpan([], [Le], n);
    ve.height = Te / 1e3, ve.style.width = a0, ve.style.height = ge, le.push({
      type: "elem",
      elem: ve
    });
  } else {
    if (le.push(Qr(f, w, i)), le.push(br), o === null) {
      var te = I - E - D + 2 * ba;
      le.push(Jr(m, te, n));
    } else {
      var me = (I - E - D - _) / 2 + 2 * ba;
      le.push(Jr(m, me, n)), le.push(br), le.push(Qr(o, w, i)), le.push(br), le.push(Jr(m, me, n));
    }
    le.push(br), le.push(Qr(s, w, i));
  }
  var $ = n.havingBaseStyle(Z.TEXT), Me = T.makeVList({
    positionType: "bottom",
    positionData: J,
    children: le
  }, $);
  return Ba(T.makeSpan(["delimsizing", "mult"], [Me], $), Z.TEXT, n, l);
}, $r = 80, ea = 0.08, ta = function(e, t, a, n, i) {
  var l = zs(e, n, a), s = new gt(e, l), o = new nt([s], {
    // Note: 1000:1 ratio of viewBox to document em width.
    width: "400em",
    height: q(t),
    viewBox: "0 0 400000 " + a,
    preserveAspectRatio: "xMinYMin slice"
  });
  return T.makeSvgSpan(["hide-tail"], [o], i);
}, F1 = function(e, t) {
  var a = t.havingBaseSizing(), n = il("\\surd", e * a.sizeMultiplier, nl, a), i = a.sizeMultiplier, l = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), s, o = 0, m = 0, f = 0, p;
  return n.type === "small" ? (f = 1e3 + 1e3 * l + $r, e < 1 ? i = 1 : e < 1.4 && (i = 0.7), o = (1 + l + ea) / i, m = (1 + l) / i, s = ta("sqrtMain", o, f, l, t), s.style.minWidth = "0.853em", p = 0.833 / i) : n.type === "large" ? (f = (1e3 + $r) * Qt[n.size], m = (Qt[n.size] + l) / i, o = (Qt[n.size] + l + ea) / i, s = ta("sqrtSize" + n.size, o, f, l, t), s.style.minWidth = "1.02em", p = 1 / i) : (o = e + l + ea, m = e + l, f = Math.floor(1e3 * e + l) + $r, s = ta("sqrtTall", o, f, l, t), s.style.minWidth = "0.742em", p = 1.056), s.height = m, s.style.height = q(o), {
    span: s,
    advanceWidth: p,
    // Calculate the actual line width.
    // This actually should depend on the chosen font -- e.g. \boldmath
    // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
    // have thicker rules.
    ruleWidth: (t.fontMetrics().sqrtRuleThickness + l) * i
  };
}, rl = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"], _1 = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"], al = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"], Qt = [0, 1.2, 1.8, 2.4, 3], E1 = function(e, t, a, n, i) {
  if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), j.contains(rl, e) || j.contains(al, e))
    return el(e, t, !1, a, n, i);
  if (j.contains(_1, e))
    return tl(e, Qt[t], !1, a, n, i);
  throw new W("Illegal delimiter: '" + e + "'");
}, T1 = [{
  type: "small",
  style: Z.SCRIPTSCRIPT
}, {
  type: "small",
  style: Z.SCRIPT
}, {
  type: "small",
  style: Z.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}], C1 = [{
  type: "small",
  style: Z.SCRIPTSCRIPT
}, {
  type: "small",
  style: Z.SCRIPT
}, {
  type: "small",
  style: Z.TEXT
}, {
  type: "stack"
}], nl = [{
  type: "small",
  style: Z.SCRIPTSCRIPT
}, {
  type: "small",
  style: Z.SCRIPT
}, {
  type: "small",
  style: Z.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}, {
  type: "stack"
}], M1 = function(e) {
  if (e.type === "small")
    return "Main-Regular";
  if (e.type === "large")
    return "Size" + e.size + "-Regular";
  if (e.type === "stack")
    return "Size4-Regular";
  throw new Error("Add support for delim type '" + e.type + "' here.");
}, il = function(e, t, a, n) {
  for (var i = Math.min(2, 3 - n.style.size), l = i; l < a.length && a[l].type !== "stack"; l++) {
    var s = Zt(e, M1(a[l]), "math"), o = s.height + s.depth;
    if (a[l].type === "small") {
      var m = n.havingBaseStyle(a[l].style);
      o *= m.sizeMultiplier;
    }
    if (o > t)
      return a[l];
  }
  return a[a.length - 1];
}, ll = function(e, t, a, n, i, l) {
  e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
  var s;
  j.contains(al, e) ? s = T1 : j.contains(rl, e) ? s = nl : s = C1;
  var o = il(e, t, s, n);
  return o.type === "small" ? D1(e, o.style, a, n, i, l) : o.type === "large" ? el(e, o.size, a, n, i, l) : tl(e, t, a, n, i, l);
}, B1 = function(e, t, a, n, i, l) {
  var s = n.fontMetrics().axisHeight * n.sizeMultiplier, o = 901, m = 5 / n.fontMetrics().ptPerEm, f = Math.max(t - s, a + s), p = Math.max(
    // In real TeX, calculations are done using integral values which are
    // 65536 per pt, or 655360 per em. So, the division here truncates in
    // TeX but doesn't here, producing different results. If we wanted to
    // exactly match TeX's calculation, we could do
    //   Math.floor(655360 * maxDistFromAxis / 500) *
    //    delimiterFactor / 655360
    // (To see the difference, compare
    //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
    // in TeX and KaTeX)
    f / 500 * o,
    2 * f - m
  );
  return ll(e, p, !0, n, i, l);
}, Z0 = {
  sqrtImage: F1,
  sizedDelim: E1,
  sizeToMaxHeight: Qt,
  customSizedDelim: ll,
  leftRightDelim: B1
}, Sn = {
  "\\bigl": {
    mclass: "mopen",
    size: 1
  },
  "\\Bigl": {
    mclass: "mopen",
    size: 2
  },
  "\\biggl": {
    mclass: "mopen",
    size: 3
  },
  "\\Biggl": {
    mclass: "mopen",
    size: 4
  },
  "\\bigr": {
    mclass: "mclose",
    size: 1
  },
  "\\Bigr": {
    mclass: "mclose",
    size: 2
  },
  "\\biggr": {
    mclass: "mclose",
    size: 3
  },
  "\\Biggr": {
    mclass: "mclose",
    size: 4
  },
  "\\bigm": {
    mclass: "mrel",
    size: 1
  },
  "\\Bigm": {
    mclass: "mrel",
    size: 2
  },
  "\\biggm": {
    mclass: "mrel",
    size: 3
  },
  "\\Biggm": {
    mclass: "mrel",
    size: 4
  },
  "\\big": {
    mclass: "mord",
    size: 1
  },
  "\\Big": {
    mclass: "mord",
    size: 2
  },
  "\\bigg": {
    mclass: "mord",
    size: 3
  },
  "\\Bigg": {
    mclass: "mord",
    size: 4
  }
}, z1 = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
function Vr(r, e) {
  var t = Ur(r);
  if (t && j.contains(z1, t.text))
    return t;
  throw t ? new W("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", r) : new W("Invalid delimiter type '" + r.type + "'", r);
}
P({
  type: "delimsizing",
  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
  props: {
    numArgs: 1,
    argTypes: ["primitive"]
  },
  handler: (r, e) => {
    var t = Vr(e[0], r);
    return {
      type: "delimsizing",
      mode: r.parser.mode,
      size: Sn[r.funcName].size,
      mclass: Sn[r.funcName].mclass,
      delim: t.text
    };
  },
  htmlBuilder: (r, e) => r.delim === "." ? T.makeSpan([r.mclass]) : Z0.sizedDelim(r.delim, r.size, e, r.mode, [r.mclass]),
  mathmlBuilder: (r) => {
    var e = [];
    r.delim !== "." && e.push(x0(r.delim, r.mode));
    var t = new N.MathNode("mo", e);
    r.mclass === "mopen" || r.mclass === "mclose" ? t.setAttribute("fence", "true") : t.setAttribute("fence", "false"), t.setAttribute("stretchy", "true");
    var a = q(Z0.sizeToMaxHeight[r.size]);
    return t.setAttribute("minsize", a), t.setAttribute("maxsize", a), t;
  }
});
function Fn(r) {
  if (!r.body)
    throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
P({
  type: "leftright-right",
  names: ["\\right"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = r.parser.gullet.macros.get("\\current@color");
    if (t && typeof t != "string")
      throw new W("\\current@color set to non-string in \\right");
    return {
      type: "leftright-right",
      mode: r.parser.mode,
      delim: Vr(e[0], r).text,
      color: t
      // undefined if not set via \color
    };
  }
});
P({
  type: "leftright",
  names: ["\\left"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = Vr(e[0], r), a = r.parser;
    ++a.leftrightDepth;
    var n = a.parseExpression(!1);
    --a.leftrightDepth, a.expect("\\right", !1);
    var i = ae(a.parseFunction(), "leftright-right");
    return {
      type: "leftright",
      mode: a.mode,
      body: n,
      left: t.text,
      right: i.delim,
      rightColor: i.color
    };
  },
  htmlBuilder: (r, e) => {
    Fn(r);
    for (var t = je(r.body, e, !0, ["mopen", "mclose"]), a = 0, n = 0, i = !1, l = 0; l < t.length; l++)
      t[l].isMiddle ? i = !0 : (a = Math.max(t[l].height, a), n = Math.max(t[l].depth, n));
    a *= e.sizeMultiplier, n *= e.sizeMultiplier;
    var s;
    if (r.left === "." ? s = tr(e, ["mopen"]) : s = Z0.leftRightDelim(r.left, a, n, e, r.mode, ["mopen"]), t.unshift(s), i)
      for (var o = 1; o < t.length; o++) {
        var m = t[o], f = m.isMiddle;
        f && (t[o] = Z0.leftRightDelim(f.delim, a, n, f.options, r.mode, []));
      }
    var p;
    if (r.right === ".")
      p = tr(e, ["mclose"]);
    else {
      var g = r.rightColor ? e.withColor(r.rightColor) : e;
      p = Z0.leftRightDelim(r.right, a, n, g, r.mode, ["mclose"]);
    }
    return t.push(p), T.makeSpan(["minner"], t, e);
  },
  mathmlBuilder: (r, e) => {
    Fn(r);
    var t = b0(r.body, e);
    if (r.left !== ".") {
      var a = new N.MathNode("mo", [x0(r.left, r.mode)]);
      a.setAttribute("fence", "true"), t.unshift(a);
    }
    if (r.right !== ".") {
      var n = new N.MathNode("mo", [x0(r.right, r.mode)]);
      n.setAttribute("fence", "true"), r.rightColor && n.setAttribute("mathcolor", r.rightColor), t.push(n);
    }
    return Ea(t);
  }
});
P({
  type: "middle",
  names: ["\\middle"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = Vr(e[0], r);
    if (!r.parser.leftrightDepth)
      throw new W("\\middle without preceding \\left", t);
    return {
      type: "middle",
      mode: r.parser.mode,
      delim: t.text
    };
  },
  htmlBuilder: (r, e) => {
    var t;
    if (r.delim === ".")
      t = tr(e, []);
    else {
      t = Z0.sizedDelim(r.delim, 1, e, r.mode, []);
      var a = {
        delim: r.delim,
        options: e
      };
      t.isMiddle = a;
    }
    return t;
  },
  mathmlBuilder: (r, e) => {
    var t = r.delim === "\\vert" || r.delim === "|" ? x0("|", "text") : x0(r.delim, r.mode), a = new N.MathNode("mo", [t]);
    return a.setAttribute("fence", "true"), a.setAttribute("lspace", "0.05em"), a.setAttribute("rspace", "0.05em"), a;
  }
});
var za = (r, e) => {
  var t = T.wrapFragment(he(r.body, e), e), a = r.label.slice(1), n = e.sizeMultiplier, i, l = 0, s = j.isCharacterBox(r.body);
  if (a === "sout")
    i = T.makeSpan(["stretchy", "sout"]), i.height = e.fontMetrics().defaultRuleThickness / n, l = -0.5 * e.fontMetrics().xHeight;
  else if (a === "phase") {
    var o = ze({
      number: 0.6,
      unit: "pt"
    }, e), m = ze({
      number: 0.35,
      unit: "ex"
    }, e), f = e.havingBaseSizing();
    n = n / f.sizeMultiplier;
    var p = t.height + t.depth + o + m;
    t.style.paddingLeft = q(p / 2 + o);
    var g = Math.floor(1e3 * p * n), w = Ms(g), F = new nt([new gt("phase", w)], {
      width: "400em",
      height: q(g / 1e3),
      viewBox: "0 0 400000 " + g,
      preserveAspectRatio: "xMinYMin slice"
    });
    i = T.makeSvgSpan(["hide-tail"], [F], e), i.style.height = q(p), l = t.depth + o + m;
  } else {
    /cancel/.test(a) ? s || t.classes.push("cancel-pad") : a === "angl" ? t.classes.push("anglpad") : t.classes.push("boxpad");
    var E = 0, k = 0, S = 0;
    /box/.test(a) ? (S = Math.max(
      e.fontMetrics().fboxrule,
      // default
      e.minRuleThickness
      // User override.
    ), E = e.fontMetrics().fboxsep + (a === "colorbox" ? 0 : S), k = E) : a === "angl" ? (S = Math.max(e.fontMetrics().defaultRuleThickness, e.minRuleThickness), E = 4 * S, k = Math.max(0, 0.25 - t.depth)) : (E = s ? 0.2 : 0, k = E), i = K0.encloseSpan(t, a, E, k, e), /fbox|boxed|fcolorbox/.test(a) ? (i.style.borderStyle = "solid", i.style.borderWidth = q(S)) : a === "angl" && S !== 0.049 && (i.style.borderTopWidth = q(S), i.style.borderRightWidth = q(S)), l = t.depth + k, r.backgroundColor && (i.style.backgroundColor = r.backgroundColor, r.borderColor && (i.style.borderColor = r.borderColor));
  }
  var y;
  if (r.backgroundColor)
    y = T.makeVList({
      positionType: "individualShift",
      children: [
        // Put the color background behind inner;
        {
          type: "elem",
          elem: i,
          shift: l
        },
        {
          type: "elem",
          elem: t,
          shift: 0
        }
      ]
    }, e);
  else {
    var D = /cancel|phase/.test(a) ? ["svg-align"] : [];
    y = T.makeVList({
      positionType: "individualShift",
      children: [
        // Write the \cancel stroke on top of inner.
        {
          type: "elem",
          elem: t,
          shift: 0
        },
        {
          type: "elem",
          elem: i,
          shift: l,
          wrapperClasses: D
        }
      ]
    }, e);
  }
  return /cancel/.test(a) && (y.height = t.height, y.depth = t.depth), /cancel/.test(a) && !s ? T.makeSpan(["mord", "cancel-lap"], [y], e) : T.makeSpan(["mord"], [y], e);
}, Ra = (r, e) => {
  var t = 0, a = new N.MathNode(r.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [De(r.body, e)]);
  switch (r.label) {
    case "\\cancel":
      a.setAttribute("notation", "updiagonalstrike");
      break;
    case "\\bcancel":
      a.setAttribute("notation", "downdiagonalstrike");
      break;
    case "\\phase":
      a.setAttribute("notation", "phasorangle");
      break;
    case "\\sout":
      a.setAttribute("notation", "horizontalstrike");
      break;
    case "\\fbox":
      a.setAttribute("notation", "box");
      break;
    case "\\angl":
      a.setAttribute("notation", "actuarial");
      break;
    case "\\fcolorbox":
    case "\\colorbox":
      if (t = e.fontMetrics().fboxsep * e.fontMetrics().ptPerEm, a.setAttribute("width", "+" + 2 * t + "pt"), a.setAttribute("height", "+" + 2 * t + "pt"), a.setAttribute("lspace", t + "pt"), a.setAttribute("voffset", t + "pt"), r.label === "\\fcolorbox") {
        var n = Math.max(
          e.fontMetrics().fboxrule,
          // default
          e.minRuleThickness
          // user override
        );
        a.setAttribute("style", "border: " + n + "em solid " + String(r.borderColor));
      }
      break;
    case "\\xcancel":
      a.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
      break;
  }
  return r.backgroundColor && a.setAttribute("mathbackground", r.backgroundColor), a;
};
P({
  type: "enclose",
  names: ["\\colorbox"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "text"]
  },
  handler(r, e, t) {
    var {
      parser: a,
      funcName: n
    } = r, i = ae(e[0], "color-token").color, l = e[1];
    return {
      type: "enclose",
      mode: a.mode,
      label: n,
      backgroundColor: i,
      body: l
    };
  },
  htmlBuilder: za,
  mathmlBuilder: Ra
});
P({
  type: "enclose",
  names: ["\\fcolorbox"],
  props: {
    numArgs: 3,
    allowedInText: !0,
    argTypes: ["color", "color", "text"]
  },
  handler(r, e, t) {
    var {
      parser: a,
      funcName: n
    } = r, i = ae(e[0], "color-token").color, l = ae(e[1], "color-token").color, s = e[2];
    return {
      type: "enclose",
      mode: a.mode,
      label: n,
      backgroundColor: l,
      borderColor: i,
      body: s
    };
  },
  htmlBuilder: za,
  mathmlBuilder: Ra
});
P({
  type: "enclose",
  names: ["\\fbox"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\fbox",
      body: e[0]
    };
  }
});
P({
  type: "enclose",
  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "enclose",
      mode: t.mode,
      label: a,
      body: n
    };
  },
  htmlBuilder: za,
  mathmlBuilder: Ra
});
P({
  type: "enclose",
  names: ["\\angl"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\angl",
      body: e[0]
    };
  }
});
var sl = {};
function H0(r) {
  for (var {
    type: e,
    names: t,
    props: a,
    handler: n,
    htmlBuilder: i,
    mathmlBuilder: l
  } = r, s = {
    type: e,
    numArgs: a.numArgs || 0,
    allowedInText: !1,
    numOptionalArgs: 0,
    handler: n
  }, o = 0; o < t.length; ++o)
    sl[t[o]] = s;
  i && (Tr[e] = i), l && (Cr[e] = l);
}
var R1 = {};
function d(r, e) {
  R1[r] = e;
}
function _n(r) {
  var e = [];
  r.consumeSpaces();
  var t = r.fetch().text;
  for (t === "\\relax" && (r.consume(), r.consumeSpaces(), t = r.fetch().text); t === "\\hline" || t === "\\hdashline"; )
    r.consume(), e.push(t === "\\hdashline"), r.consumeSpaces(), t = r.fetch().text;
  return e;
}
var Wr = (r) => {
  var e = r.parser.settings;
  if (!e.displayMode)
    throw new W("{" + r.envName + "} can be used only in display mode.");
};
function Na(r) {
  if (r.indexOf("ed") === -1)
    return r.indexOf("*") === -1;
}
function ot(r, e, t) {
  var {
    hskipBeforeAndAfter: a,
    addJot: n,
    cols: i,
    arraystretch: l,
    colSeparationType: s,
    autoTag: o,
    singleRow: m,
    emptySingleRow: f,
    maxNumCols: p,
    leqno: g
  } = e;
  if (r.gullet.beginGroup(), m || r.gullet.macros.set("\\cr", "\\\\\\relax"), !l) {
    var w = r.gullet.expandMacroAsText("\\arraystretch");
    if (w == null)
      l = 1;
    else if (l = parseFloat(w), !l || l < 0)
      throw new W("Invalid \\arraystretch: " + w);
  }
  r.gullet.beginGroup();
  var F = [], E = [F], k = [], S = [], y = o != null ? [] : void 0;
  function D() {
    o && r.gullet.macros.set("\\@eqnsw", "1", !0);
  }
  function _() {
    y && (r.gullet.macros.get("\\df@tag") ? (y.push(r.subparse([new Aa("\\df@tag")])), r.gullet.macros.set("\\df@tag", void 0, !0)) : y.push(!!o && r.gullet.macros.get("\\@eqnsw") === "1"));
  }
  for (D(), S.push(_n(r)); ; ) {
    var C = r.parseExpression(!1, m ? "\\end" : "\\\\");
    r.gullet.endGroup(), r.gullet.beginGroup(), C = {
      type: "ordgroup",
      mode: r.mode,
      body: C
    }, t && (C = {
      type: "styling",
      mode: r.mode,
      style: t,
      body: [C]
    }), F.push(C);
    var M = r.fetch().text;
    if (M === "&") {
      if (p && F.length === p) {
        if (m || s)
          throw new W("Too many tab characters: &", r.nextToken);
        r.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
      }
      r.consume();
    } else if (M === "\\end") {
      _(), F.length === 1 && C.type === "styling" && C.body[0].body.length === 0 && (E.length > 1 || !f) && E.pop(), S.length < E.length + 1 && S.push([]);
      break;
    } else if (M === "\\\\") {
      r.consume();
      var R = void 0;
      r.gullet.future().text !== " " && (R = r.parseSizeGroup(!0)), k.push(R ? R.value : null), _(), S.push(_n(r)), F = [], E.push(F), D();
    } else
      throw new W("Expected & or \\\\ or \\cr or \\end", r.nextToken);
  }
  return r.gullet.endGroup(), r.gullet.endGroup(), {
    type: "array",
    mode: r.mode,
    addJot: n,
    arraystretch: l,
    body: E,
    cols: i,
    rowGaps: k,
    hskipBeforeAndAfter: a,
    hLinesBeforeRow: S,
    colSeparationType: s,
    tags: y,
    leqno: g
  };
}
function Ia(r) {
  return r.slice(0, 1) === "d" ? "display" : "text";
}
var U0 = function(e, t) {
  var a, n, i = e.body.length, l = e.hLinesBeforeRow, s = 0, o = new Array(i), m = [], f = Math.max(
    // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
    t.fontMetrics().arrayRuleWidth,
    t.minRuleThickness
    // User override.
  ), p = 1 / t.fontMetrics().ptPerEm, g = 5 * p;
  if (e.colSeparationType && e.colSeparationType === "small") {
    var w = t.havingStyle(Z.SCRIPT).sizeMultiplier;
    g = 0.2778 * (w / t.sizeMultiplier);
  }
  var F = e.colSeparationType === "CD" ? ze({
    number: 3,
    unit: "ex"
  }, t) : 12 * p, E = 3 * p, k = e.arraystretch * F, S = 0.7 * k, y = 0.3 * k, D = 0;
  function _(m0) {
    for (var f0 = 0; f0 < m0.length; ++f0)
      f0 > 0 && (D += 0.25), m.push({
        pos: D,
        isDashed: m0[f0]
      });
  }
  for (_(l[0]), a = 0; a < e.body.length; ++a) {
    var C = e.body[a], M = S, R = y;
    s < C.length && (s = C.length);
    var U = new Array(C.length);
    for (n = 0; n < C.length; ++n) {
      var I = he(C[n], t);
      R < I.depth && (R = I.depth), M < I.height && (M = I.height), U[n] = I;
    }
    var O = e.rowGaps[a], J = 0;
    O && (J = ze(O, t), J > 0 && (J += y, R < J && (R = J), J = 0)), e.addJot && (R += E), U.height = M, U.depth = R, D += M, U.pos = D, D += R + J, o[a] = U, _(l[a + 1]);
  }
  var le = D / 2 + t.fontMetrics().axisHeight, se = e.cols || [], Te = [], Ue, Ze, a0 = [];
  if (e.tags && e.tags.some((m0) => m0))
    for (a = 0; a < i; ++a) {
      var ge = o[a], Le = ge.pos - le, ve = e.tags[a], te = void 0;
      ve === !0 ? te = T.makeSpan(["eqn-num"], [], t) : ve === !1 ? te = T.makeSpan([], [], t) : te = T.makeSpan([], je(ve, t, !0), t), te.depth = ge.depth, te.height = ge.height, a0.push({
        type: "elem",
        elem: te,
        shift: Le
      });
    }
  for (
    n = 0, Ze = 0;
    // Continue while either there are more columns or more column
    // descriptions, so trailing separators don't get lost.
    n < s || Ze < se.length;
    ++n, ++Ze
  ) {
    for (var me = se[Ze] || {}, $ = !0; me.type === "separator"; ) {
      if ($ || (Ue = T.makeSpan(["arraycolsep"], []), Ue.style.width = q(t.fontMetrics().doubleRuleSep), Te.push(Ue)), me.separator === "|" || me.separator === ":") {
        var Me = me.separator === "|" ? "solid" : "dashed", re = T.makeSpan(["vertical-separator"], [], t);
        re.style.height = q(D), re.style.borderRightWidth = q(f), re.style.borderRightStyle = Me, re.style.margin = "0 " + q(-f / 2);
        var Ge = D - le;
        Ge && (re.style.verticalAlign = q(-Ge)), Te.push(re);
      } else
        throw new W("Invalid separator type: " + me.separator);
      Ze++, me = se[Ze] || {}, $ = !1;
    }
    if (!(n >= s)) {
      var xe = void 0;
      (n > 0 || e.hskipBeforeAndAfter) && (xe = j.deflt(me.pregap, g), xe !== 0 && (Ue = T.makeSpan(["arraycolsep"], []), Ue.style.width = q(xe), Te.push(Ue)));
      var Ke = [];
      for (a = 0; a < i; ++a) {
        var ce = o[a], Ve = ce[n];
        if (Ve) {
          var c0 = ce.pos - le;
          Ve.depth = ce.depth, Ve.height = ce.height, Ke.push({
            type: "elem",
            elem: Ve,
            shift: c0
          });
        }
      }
      Ke = T.makeVList({
        positionType: "individualShift",
        children: Ke
      }, t), Ke = T.makeSpan(["col-align-" + (me.align || "c")], [Ke]), Te.push(Ke), (n < s - 1 || e.hskipBeforeAndAfter) && (xe = j.deflt(me.postgap, g), xe !== 0 && (Ue = T.makeSpan(["arraycolsep"], []), Ue.style.width = q(xe), Te.push(Ue)));
    }
  }
  if (o = T.makeSpan(["mtable"], Te), m.length > 0) {
    for (var Re = T.makeLineSpan("hline", t, f), n0 = T.makeLineSpan("hdashline", t, f), Pe = [{
      type: "elem",
      elem: o,
      shift: 0
    }]; m.length > 0; ) {
      var F0 = m.pop(), h0 = F0.pos - le;
      F0.isDashed ? Pe.push({
        type: "elem",
        elem: n0,
        shift: h0
      }) : Pe.push({
        type: "elem",
        elem: Re,
        shift: h0
      });
    }
    o = T.makeVList({
      positionType: "individualShift",
      children: Pe
    }, t);
  }
  if (a0.length === 0)
    return T.makeSpan(["mord"], [o], t);
  var i0 = T.makeVList({
    positionType: "individualShift",
    children: a0
  }, t);
  return i0 = T.makeSpan(["tag"], [i0], t), T.makeFragment([o, i0]);
}, N1 = {
  c: "center ",
  l: "left ",
  r: "right "
}, G0 = function(e, t) {
  for (var a = [], n = new N.MathNode("mtd", [], ["mtr-glue"]), i = new N.MathNode("mtd", [], ["mml-eqn-num"]), l = 0; l < e.body.length; l++) {
    for (var s = e.body[l], o = [], m = 0; m < s.length; m++)
      o.push(new N.MathNode("mtd", [De(s[m], t)]));
    e.tags && e.tags[l] && (o.unshift(n), o.push(n), e.leqno ? o.unshift(i) : o.push(i)), a.push(new N.MathNode("mtr", o));
  }
  var f = new N.MathNode("mtable", a), p = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
  f.setAttribute("rowspacing", q(p));
  var g = "", w = "";
  if (e.cols && e.cols.length > 0) {
    var F = e.cols, E = "", k = !1, S = 0, y = F.length;
    F[0].type === "separator" && (g += "top ", S = 1), F[F.length - 1].type === "separator" && (g += "bottom ", y -= 1);
    for (var D = S; D < y; D++)
      F[D].type === "align" ? (w += N1[F[D].align], k && (E += "none "), k = !0) : F[D].type === "separator" && k && (E += F[D].separator === "|" ? "solid " : "dashed ", k = !1);
    f.setAttribute("columnalign", w.trim()), /[sd]/.test(E) && f.setAttribute("columnlines", E.trim());
  }
  if (e.colSeparationType === "align") {
    for (var _ = e.cols || [], C = "", M = 1; M < _.length; M++)
      C += M % 2 ? "0em " : "1em ";
    f.setAttribute("columnspacing", C.trim());
  } else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? f.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? f.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? f.setAttribute("columnspacing", "0.5em") : f.setAttribute("columnspacing", "1em");
  var R = "", U = e.hLinesBeforeRow;
  g += U[0].length > 0 ? "left " : "", g += U[U.length - 1].length > 0 ? "right " : "";
  for (var I = 1; I < U.length - 1; I++)
    R += U[I].length === 0 ? "none " : U[I][0] ? "dashed " : "solid ";
  return /[sd]/.test(R) && f.setAttribute("rowlines", R.trim()), g !== "" && (f = new N.MathNode("menclose", [f]), f.setAttribute("notation", g.trim())), e.arraystretch && e.arraystretch < 1 && (f = new N.MathNode("mstyle", [f]), f.setAttribute("scriptlevel", "1")), f;
}, ul = function(e, t) {
  e.envName.indexOf("ed") === -1 && Wr(e);
  var a = [], n = e.envName.indexOf("at") > -1 ? "alignat" : "align", i = e.envName === "split", l = ot(e.parser, {
    cols: a,
    addJot: !0,
    autoTag: i ? void 0 : Na(e.envName),
    emptySingleRow: !0,
    colSeparationType: n,
    maxNumCols: i ? 2 : void 0,
    leqno: e.parser.settings.leqno
  }, "display"), s, o = 0, m = {
    type: "ordgroup",
    mode: e.mode,
    body: []
  };
  if (t[0] && t[0].type === "ordgroup") {
    for (var f = "", p = 0; p < t[0].body.length; p++) {
      var g = ae(t[0].body[p], "textord");
      f += g.text;
    }
    s = Number(f), o = s * 2;
  }
  var w = !o;
  l.body.forEach(function(S) {
    for (var y = 1; y < S.length; y += 2) {
      var D = ae(S[y], "styling"), _ = ae(D.body[0], "ordgroup");
      _.body.unshift(m);
    }
    if (w)
      o < S.length && (o = S.length);
    else {
      var C = S.length / 2;
      if (s < C)
        throw new W("Too many math in a row: " + ("expected " + s + ", but got " + C), S[0]);
    }
  });
  for (var F = 0; F < o; ++F) {
    var E = "r", k = 0;
    F % 2 === 1 ? E = "l" : F > 0 && w && (k = 1), a[F] = {
      type: "align",
      align: E,
      pregap: k,
      postgap: 0
    };
  }
  return l.colSeparationType = w ? "align" : "alignat", l;
};
H0({
  type: "array",
  names: ["array", "darray"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var t = Ur(e[0]), a = t ? [e[0]] : ae(e[0], "ordgroup").body, n = a.map(function(l) {
      var s = Ca(l), o = s.text;
      if ("lcr".indexOf(o) !== -1)
        return {
          type: "align",
          align: o
        };
      if (o === "|")
        return {
          type: "separator",
          separator: "|"
        };
      if (o === ":")
        return {
          type: "separator",
          separator: ":"
        };
      throw new W("Unknown column alignment: " + o, l);
    }), i = {
      cols: n,
      hskipBeforeAndAfter: !0,
      // \@preamble in lttab.dtx
      maxNumCols: n.length
    };
    return ot(r.parser, i, Ia(r.envName));
  },
  htmlBuilder: U0,
  mathmlBuilder: G0
});
H0({
  type: "array",
  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      matrix: null,
      pmatrix: ["(", ")"],
      bmatrix: ["[", "]"],
      Bmatrix: ["\\{", "\\}"],
      vmatrix: ["|", "|"],
      Vmatrix: ["\\Vert", "\\Vert"]
    }[r.envName.replace("*", "")], t = "c", a = {
      hskipBeforeAndAfter: !1,
      cols: [{
        type: "align",
        align: t
      }]
    };
    if (r.envName.charAt(r.envName.length - 1) === "*") {
      var n = r.parser;
      if (n.consumeSpaces(), n.fetch().text === "[") {
        if (n.consume(), n.consumeSpaces(), t = n.fetch().text, "lcr".indexOf(t) === -1)
          throw new W("Expected l or c or r", n.nextToken);
        n.consume(), n.consumeSpaces(), n.expect("]"), n.consume(), a.cols = [{
          type: "align",
          align: t
        }];
      }
    }
    var i = ot(r.parser, a, Ia(r.envName)), l = Math.max(0, ...i.body.map((s) => s.length));
    return i.cols = new Array(l).fill({
      type: "align",
      align: t
    }), e ? {
      type: "leftright",
      mode: r.mode,
      body: [i],
      left: e[0],
      right: e[1],
      rightColor: void 0
      // \right uninfluenced by \color in array
    } : i;
  },
  htmlBuilder: U0,
  mathmlBuilder: G0
});
H0({
  type: "array",
  names: ["smallmatrix"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      arraystretch: 0.5
    }, t = ot(r.parser, e, "script");
    return t.colSeparationType = "small", t;
  },
  htmlBuilder: U0,
  mathmlBuilder: G0
});
H0({
  type: "array",
  names: ["subarray"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var t = Ur(e[0]), a = t ? [e[0]] : ae(e[0], "ordgroup").body, n = a.map(function(l) {
      var s = Ca(l), o = s.text;
      if ("lc".indexOf(o) !== -1)
        return {
          type: "align",
          align: o
        };
      throw new W("Unknown column alignment: " + o, l);
    });
    if (n.length > 1)
      throw new W("{subarray} can contain only one column");
    var i = {
      cols: n,
      hskipBeforeAndAfter: !1,
      arraystretch: 0.5
    };
    if (i = ot(r.parser, i, "script"), i.body.length > 0 && i.body[0].length > 1)
      throw new W("{subarray} can contain only one column");
    return i;
  },
  htmlBuilder: U0,
  mathmlBuilder: G0
});
H0({
  type: "array",
  names: ["cases", "dcases", "rcases", "drcases"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      arraystretch: 1.2,
      cols: [{
        type: "align",
        align: "l",
        pregap: 0,
        // TODO(kevinb) get the current style.
        // For now we use the metrics for TEXT style which is what we were
        // doing before.  Before attempting to get the current style we
        // should look at TeX's behavior especially for \over and matrices.
        postgap: 1
        /* 1em quad */
      }, {
        type: "align",
        align: "l",
        pregap: 0,
        postgap: 0
      }]
    }, t = ot(r.parser, e, Ia(r.envName));
    return {
      type: "leftright",
      mode: r.mode,
      body: [t],
      left: r.envName.indexOf("r") > -1 ? "." : "\\{",
      right: r.envName.indexOf("r") > -1 ? "\\}" : ".",
      rightColor: void 0
    };
  },
  htmlBuilder: U0,
  mathmlBuilder: G0
});
H0({
  type: "array",
  names: ["align", "align*", "aligned", "split"],
  props: {
    numArgs: 0
  },
  handler: ul,
  htmlBuilder: U0,
  mathmlBuilder: G0
});
H0({
  type: "array",
  names: ["gathered", "gather", "gather*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    j.contains(["gather", "gather*"], r.envName) && Wr(r);
    var e = {
      cols: [{
        type: "align",
        align: "c"
      }],
      addJot: !0,
      colSeparationType: "gather",
      autoTag: Na(r.envName),
      emptySingleRow: !0,
      leqno: r.parser.settings.leqno
    };
    return ot(r.parser, e, "display");
  },
  htmlBuilder: U0,
  mathmlBuilder: G0
});
H0({
  type: "array",
  names: ["alignat", "alignat*", "alignedat"],
  props: {
    numArgs: 1
  },
  handler: ul,
  htmlBuilder: U0,
  mathmlBuilder: G0
});
H0({
  type: "array",
  names: ["equation", "equation*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    Wr(r);
    var e = {
      autoTag: Na(r.envName),
      emptySingleRow: !0,
      singleRow: !0,
      maxNumCols: 1,
      leqno: r.parser.settings.leqno
    };
    return ot(r.parser, e, "display");
  },
  htmlBuilder: U0,
  mathmlBuilder: G0
});
H0({
  type: "array",
  names: ["CD"],
  props: {
    numArgs: 0
  },
  handler(r) {
    return Wr(r), w1(r.parser);
  },
  htmlBuilder: U0,
  mathmlBuilder: G0
});
d("\\nonumber", "\\gdef\\@eqnsw{0}");
d("\\notag", "\\nonumber");
P({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\hline", "\\hdashline"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !0
  },
  handler(r, e) {
    throw new W(r.funcName + " valid only within array environment");
  }
});
var En = sl;
P({
  type: "environment",
  names: ["\\begin", "\\end"],
  props: {
    numArgs: 1,
    argTypes: ["text"]
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    if (n.type !== "ordgroup")
      throw new W("Invalid environment name", n);
    for (var i = "", l = 0; l < n.body.length; ++l)
      i += ae(n.body[l], "textord").text;
    if (a === "\\begin") {
      if (!En.hasOwnProperty(i))
        throw new W("No such environment: " + i, n);
      var s = En[i], {
        args: o,
        optArgs: m
      } = t.parseArguments("\\begin{" + i + "}", s), f = {
        mode: t.mode,
        envName: i,
        parser: t
      }, p = s.handler(f, o, m);
      t.expect("\\end", !1);
      var g = t.nextToken, w = ae(t.parseFunction(), "environment");
      if (w.name !== i)
        throw new W("Mismatch: \\begin{" + i + "} matched by \\end{" + w.name + "}", g);
      return p;
    }
    return {
      type: "environment",
      mode: t.mode,
      name: i,
      nameGroup: n
    };
  }
});
var ol = (r, e) => {
  var t = r.font, a = e.withFont(t);
  return he(r.body, a);
}, cl = (r, e) => {
  var t = r.font, a = e.withFont(t);
  return De(r.body, a);
}, Tn = {
  "\\Bbb": "\\mathbb",
  "\\bold": "\\mathbf",
  "\\frak": "\\mathfrak",
  "\\bm": "\\boldsymbol"
};
P({
  type: "font",
  names: [
    // styles, except \boldsymbol defined below
    "\\mathrm",
    "\\mathit",
    "\\mathbf",
    "\\mathnormal",
    // families
    "\\mathbb",
    "\\mathcal",
    "\\mathfrak",
    "\\mathscr",
    "\\mathsf",
    "\\mathtt",
    // aliases, except \bm defined below
    "\\Bbb",
    "\\bold",
    "\\frak"
  ],
  props: {
    numArgs: 1,
    allowedInArgument: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = Mr(e[0]), i = a;
    return i in Tn && (i = Tn[i]), {
      type: "font",
      mode: t.mode,
      font: i.slice(1),
      body: n
    };
  },
  htmlBuilder: ol,
  mathmlBuilder: cl
});
P({
  type: "mclass",
  names: ["\\boldsymbol", "\\bm"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[0], n = j.isCharacterBox(a);
    return {
      type: "mclass",
      mode: t.mode,
      mclass: Gr(a),
      body: [{
        type: "font",
        mode: t.mode,
        font: "boldsymbol",
        body: a
      }],
      isCharacterBox: n
    };
  }
});
P({
  type: "font",
  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a,
      breakOnTokenText: n
    } = r, {
      mode: i
    } = t, l = t.parseExpression(!0, n), s = "math" + a.slice(1);
    return {
      type: "font",
      mode: i,
      font: s,
      body: {
        type: "ordgroup",
        mode: t.mode,
        body: l
      }
    };
  },
  htmlBuilder: ol,
  mathmlBuilder: cl
});
var hl = (r, e) => {
  var t = e;
  return r === "display" ? t = t.id >= Z.SCRIPT.id ? t.text() : Z.DISPLAY : r === "text" && t.size === Z.DISPLAY.size ? t = Z.TEXT : r === "script" ? t = Z.SCRIPT : r === "scriptscript" && (t = Z.SCRIPTSCRIPT), t;
}, La = (r, e) => {
  var t = hl(r.size, e.style), a = t.fracNum(), n = t.fracDen(), i;
  i = e.havingStyle(a);
  var l = he(r.numer, i, e);
  if (r.continued) {
    var s = 8.5 / e.fontMetrics().ptPerEm, o = 3.5 / e.fontMetrics().ptPerEm;
    l.height = l.height < s ? s : l.height, l.depth = l.depth < o ? o : l.depth;
  }
  i = e.havingStyle(n);
  var m = he(r.denom, i, e), f, p, g;
  r.hasBarLine ? (r.barSize ? (p = ze(r.barSize, e), f = T.makeLineSpan("frac-line", e, p)) : f = T.makeLineSpan("frac-line", e), p = f.height, g = f.height) : (f = null, p = 0, g = e.fontMetrics().defaultRuleThickness);
  var w, F, E;
  t.size === Z.DISPLAY.size || r.size === "display" ? (w = e.fontMetrics().num1, p > 0 ? F = 3 * g : F = 7 * g, E = e.fontMetrics().denom1) : (p > 0 ? (w = e.fontMetrics().num2, F = g) : (w = e.fontMetrics().num3, F = 3 * g), E = e.fontMetrics().denom2);
  var k;
  if (f) {
    var y = e.fontMetrics().axisHeight;
    w - l.depth - (y + 0.5 * p) < F && (w += F - (w - l.depth - (y + 0.5 * p))), y - 0.5 * p - (m.height - E) < F && (E += F - (y - 0.5 * p - (m.height - E)));
    var D = -(y - 0.5 * p);
    k = T.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: m,
        shift: E
      }, {
        type: "elem",
        elem: f,
        shift: D
      }, {
        type: "elem",
        elem: l,
        shift: -w
      }]
    }, e);
  } else {
    var S = w - l.depth - (m.height - E);
    S < F && (w += 0.5 * (F - S), E += 0.5 * (F - S)), k = T.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: m,
        shift: E
      }, {
        type: "elem",
        elem: l,
        shift: -w
      }]
    }, e);
  }
  i = e.havingStyle(t), k.height *= i.sizeMultiplier / e.sizeMultiplier, k.depth *= i.sizeMultiplier / e.sizeMultiplier;
  var _;
  t.size === Z.DISPLAY.size ? _ = e.fontMetrics().delim1 : t.size === Z.SCRIPTSCRIPT.size ? _ = e.havingStyle(Z.SCRIPT).fontMetrics().delim2 : _ = e.fontMetrics().delim2;
  var C, M;
  return r.leftDelim == null ? C = tr(e, ["mopen"]) : C = Z0.customSizedDelim(r.leftDelim, _, !0, e.havingStyle(t), r.mode, ["mopen"]), r.continued ? M = T.makeSpan([]) : r.rightDelim == null ? M = tr(e, ["mclose"]) : M = Z0.customSizedDelim(r.rightDelim, _, !0, e.havingStyle(t), r.mode, ["mclose"]), T.makeSpan(["mord"].concat(i.sizingClasses(e)), [C, T.makeSpan(["mfrac"], [k]), M], e);
}, Oa = (r, e) => {
  var t = new N.MathNode("mfrac", [De(r.numer, e), De(r.denom, e)]);
  if (!r.hasBarLine)
    t.setAttribute("linethickness", "0px");
  else if (r.barSize) {
    var a = ze(r.barSize, e);
    t.setAttribute("linethickness", q(a));
  }
  var n = hl(r.size, e.style);
  if (n.size !== e.style.size) {
    t = new N.MathNode("mstyle", [t]);
    var i = n.size === Z.DISPLAY.size ? "true" : "false";
    t.setAttribute("displaystyle", i), t.setAttribute("scriptlevel", "0");
  }
  if (r.leftDelim != null || r.rightDelim != null) {
    var l = [];
    if (r.leftDelim != null) {
      var s = new N.MathNode("mo", [new N.TextNode(r.leftDelim.replace("\\", ""))]);
      s.setAttribute("fence", "true"), l.push(s);
    }
    if (l.push(t), r.rightDelim != null) {
      var o = new N.MathNode("mo", [new N.TextNode(r.rightDelim.replace("\\", ""))]);
      o.setAttribute("fence", "true"), l.push(o);
    }
    return Ea(l);
  }
  return t;
};
P({
  type: "genfrac",
  names: [
    "\\dfrac",
    "\\frac",
    "\\tfrac",
    "\\dbinom",
    "\\binom",
    "\\tbinom",
    "\\\\atopfrac",
    // can’t be entered directly
    "\\\\bracefrac",
    "\\\\brackfrac"
    // ditto
  ],
  props: {
    numArgs: 2,
    allowedInArgument: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0], i = e[1], l, s = null, o = null, m = "auto";
    switch (a) {
      case "\\dfrac":
      case "\\frac":
      case "\\tfrac":
        l = !0;
        break;
      case "\\\\atopfrac":
        l = !1;
        break;
      case "\\dbinom":
      case "\\binom":
      case "\\tbinom":
        l = !1, s = "(", o = ")";
        break;
      case "\\\\bracefrac":
        l = !1, s = "\\{", o = "\\}";
        break;
      case "\\\\brackfrac":
        l = !1, s = "[", o = "]";
        break;
      default:
        throw new Error("Unrecognized genfrac command");
    }
    switch (a) {
      case "\\dfrac":
      case "\\dbinom":
        m = "display";
        break;
      case "\\tfrac":
      case "\\tbinom":
        m = "text";
        break;
    }
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !1,
      numer: n,
      denom: i,
      hasBarLine: l,
      leftDelim: s,
      rightDelim: o,
      size: m,
      barSize: null
    };
  },
  htmlBuilder: La,
  mathmlBuilder: Oa
});
P({
  type: "genfrac",
  names: ["\\cfrac"],
  props: {
    numArgs: 2
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0], i = e[1];
    return {
      type: "genfrac",
      mode: t.mode,
      continued: !0,
      numer: n,
      denom: i,
      hasBarLine: !0,
      leftDelim: null,
      rightDelim: null,
      size: "display",
      barSize: null
    };
  }
});
P({
  type: "infix",
  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
  props: {
    numArgs: 0,
    infix: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t,
      token: a
    } = r, n;
    switch (t) {
      case "\\over":
        n = "\\frac";
        break;
      case "\\choose":
        n = "\\binom";
        break;
      case "\\atop":
        n = "\\\\atopfrac";
        break;
      case "\\brace":
        n = "\\\\bracefrac";
        break;
      case "\\brack":
        n = "\\\\brackfrac";
        break;
      default:
        throw new Error("Unrecognized infix genfrac command");
    }
    return {
      type: "infix",
      mode: e.mode,
      replaceWith: n,
      token: a
    };
  }
});
var Cn = ["display", "text", "script", "scriptscript"], Mn = function(e) {
  var t = null;
  return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
P({
  type: "genfrac",
  names: ["\\genfrac"],
  props: {
    numArgs: 6,
    allowedInArgument: !0,
    argTypes: ["math", "math", "size", "text", "math", "math"]
  },
  handler(r, e) {
    var {
      parser: t
    } = r, a = e[4], n = e[5], i = Mr(e[0]), l = i.type === "atom" && i.family === "open" ? Mn(i.text) : null, s = Mr(e[1]), o = s.type === "atom" && s.family === "close" ? Mn(s.text) : null, m = ae(e[2], "size"), f, p = null;
    m.isBlank ? f = !0 : (p = m.value, f = p.number > 0);
    var g = "auto", w = e[3];
    if (w.type === "ordgroup") {
      if (w.body.length > 0) {
        var F = ae(w.body[0], "textord");
        g = Cn[Number(F.text)];
      }
    } else
      w = ae(w, "textord"), g = Cn[Number(w.text)];
    return {
      type: "genfrac",
      mode: t.mode,
      numer: a,
      denom: n,
      continued: !1,
      hasBarLine: f,
      barSize: p,
      leftDelim: l,
      rightDelim: o,
      size: g
    };
  },
  htmlBuilder: La,
  mathmlBuilder: Oa
});
P({
  type: "infix",
  names: ["\\above"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    infix: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a,
      token: n
    } = r;
    return {
      type: "infix",
      mode: t.mode,
      replaceWith: "\\\\abovefrac",
      size: ae(e[0], "size").value,
      token: n
    };
  }
});
P({
  type: "genfrac",
  names: ["\\\\abovefrac"],
  props: {
    numArgs: 3,
    argTypes: ["math", "size", "math"]
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0], i = gs(ae(e[1], "infix").size), l = e[2], s = i.number > 0;
    return {
      type: "genfrac",
      mode: t.mode,
      numer: n,
      denom: l,
      continued: !1,
      hasBarLine: s,
      barSize: i,
      leftDelim: null,
      rightDelim: null,
      size: "auto"
    };
  },
  htmlBuilder: La,
  mathmlBuilder: Oa
});
var ml = (r, e) => {
  var t = e.style, a, n;
  r.type === "supsub" ? (a = r.sup ? he(r.sup, e.havingStyle(t.sup()), e) : he(r.sub, e.havingStyle(t.sub()), e), n = ae(r.base, "horizBrace")) : n = ae(r, "horizBrace");
  var i = he(n.base, e.havingBaseStyle(Z.DISPLAY)), l = K0.svgSpan(n, e), s;
  if (n.isOver ? (s = T.makeVList({
    positionType: "firstBaseline",
    children: [{
      type: "elem",
      elem: i
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: l
    }]
  }, e), s.children[0].children[0].children[1].classes.push("svg-align")) : (s = T.makeVList({
    positionType: "bottom",
    positionData: i.depth + 0.1 + l.height,
    children: [{
      type: "elem",
      elem: l
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: i
    }]
  }, e), s.children[0].children[0].children[0].classes.push("svg-align")), a) {
    var o = T.makeSpan(["mord", n.isOver ? "mover" : "munder"], [s], e);
    n.isOver ? s = T.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: o
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: a
      }]
    }, e) : s = T.makeVList({
      positionType: "bottom",
      positionData: o.depth + 0.2 + a.height + a.depth,
      children: [{
        type: "elem",
        elem: a
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: o
      }]
    }, e);
  }
  return T.makeSpan(["mord", n.isOver ? "mover" : "munder"], [s], e);
}, I1 = (r, e) => {
  var t = K0.mathMLnode(r.label);
  return new N.MathNode(r.isOver ? "mover" : "munder", [De(r.base, e), t]);
};
P({
  type: "horizBrace",
  names: ["\\overbrace", "\\underbrace"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r;
    return {
      type: "horizBrace",
      mode: t.mode,
      label: a,
      isOver: /^\\over/.test(a),
      base: e[0]
    };
  },
  htmlBuilder: ml,
  mathmlBuilder: I1
});
P({
  type: "href",
  names: ["\\href"],
  props: {
    numArgs: 2,
    argTypes: ["url", "original"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[1], n = ae(e[0], "url").url;
    return t.settings.isTrusted({
      command: "\\href",
      url: n
    }) ? {
      type: "href",
      mode: t.mode,
      href: n,
      body: Oe(a)
    } : t.formatUnsupportedCmd("\\href");
  },
  htmlBuilder: (r, e) => {
    var t = je(r.body, e, !1);
    return T.makeAnchor(r.href, [], t, e);
  },
  mathmlBuilder: (r, e) => {
    var t = it(r.body, e);
    return t instanceof C0 || (t = new C0("mrow", [t])), t.setAttribute("href", r.href), t;
  }
});
P({
  type: "href",
  names: ["\\url"],
  props: {
    numArgs: 1,
    argTypes: ["url"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = ae(e[0], "url").url;
    if (!t.settings.isTrusted({
      command: "\\url",
      url: a
    }))
      return t.formatUnsupportedCmd("\\url");
    for (var n = [], i = 0; i < a.length; i++) {
      var l = a[i];
      l === "~" && (l = "\\textasciitilde"), n.push({
        type: "textord",
        mode: "text",
        text: l
      });
    }
    var s = {
      type: "text",
      mode: t.mode,
      font: "\\texttt",
      body: n
    };
    return {
      type: "href",
      mode: t.mode,
      href: a,
      body: Oe(s)
    };
  }
});
P({
  type: "hbox",
  names: ["\\hbox"],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInText: !0,
    primitive: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "hbox",
      mode: t.mode,
      body: Oe(e[0])
    };
  },
  htmlBuilder(r, e) {
    var t = je(r.body, e, !1);
    return T.makeFragment(t);
  },
  mathmlBuilder(r, e) {
    return new N.MathNode("mrow", b0(r.body, e));
  }
});
P({
  type: "html",
  names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
  props: {
    numArgs: 2,
    argTypes: ["raw", "original"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a,
      token: n
    } = r, i = ae(e[0], "raw").string, l = e[1];
    t.settings.strict && t.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
    var s, o = {};
    switch (a) {
      case "\\htmlClass":
        o.class = i, s = {
          command: "\\htmlClass",
          class: i
        };
        break;
      case "\\htmlId":
        o.id = i, s = {
          command: "\\htmlId",
          id: i
        };
        break;
      case "\\htmlStyle":
        o.style = i, s = {
          command: "\\htmlStyle",
          style: i
        };
        break;
      case "\\htmlData": {
        for (var m = i.split(","), f = 0; f < m.length; f++) {
          var p = m[f].split("=");
          if (p.length !== 2)
            throw new W("Error parsing key-value for \\htmlData");
          o["data-" + p[0].trim()] = p[1].trim();
        }
        s = {
          command: "\\htmlData",
          attributes: o
        };
        break;
      }
      default:
        throw new Error("Unrecognized html command");
    }
    return t.settings.isTrusted(s) ? {
      type: "html",
      mode: t.mode,
      attributes: o,
      body: Oe(l)
    } : t.formatUnsupportedCmd(a);
  },
  htmlBuilder: (r, e) => {
    var t = je(r.body, e, !1), a = ["enclosing"];
    r.attributes.class && a.push(...r.attributes.class.trim().split(/\s+/));
    var n = T.makeSpan(a, t, e);
    for (var i in r.attributes)
      i !== "class" && r.attributes.hasOwnProperty(i) && n.setAttribute(i, r.attributes[i]);
    return n;
  },
  mathmlBuilder: (r, e) => it(r.body, e)
});
P({
  type: "htmlmathml",
  names: ["\\html@mathml"],
  props: {
    numArgs: 2,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r;
    return {
      type: "htmlmathml",
      mode: t.mode,
      html: Oe(e[0]),
      mathml: Oe(e[1])
    };
  },
  htmlBuilder: (r, e) => {
    var t = je(r.html, e, !1);
    return T.makeFragment(t);
  },
  mathmlBuilder: (r, e) => it(r.mathml, e)
});
var ra = function(e) {
  if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
    return {
      number: +e,
      unit: "bp"
    };
  var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
  if (!t)
    throw new W("Invalid size: '" + e + "' in \\includegraphics");
  var a = {
    number: +(t[1] + t[2]),
    // sign + magnitude, cast to number
    unit: t[3]
  };
  if (!Ls(a))
    throw new W("Invalid unit: '" + a.unit + "' in \\includegraphics.");
  return a;
};
P({
  type: "includegraphics",
  names: ["\\includegraphics"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    argTypes: ["raw", "url"],
    allowedInText: !1
  },
  handler: (r, e, t) => {
    var {
      parser: a
    } = r, n = {
      number: 0,
      unit: "em"
    }, i = {
      number: 0.9,
      unit: "em"
    }, l = {
      number: 0,
      unit: "em"
    }, s = "";
    if (t[0])
      for (var o = ae(t[0], "raw").string, m = o.split(","), f = 0; f < m.length; f++) {
        var p = m[f].split("=");
        if (p.length === 2) {
          var g = p[1].trim();
          switch (p[0].trim()) {
            case "alt":
              s = g;
              break;
            case "width":
              n = ra(g);
              break;
            case "height":
              i = ra(g);
              break;
            case "totalheight":
              l = ra(g);
              break;
            default:
              throw new W("Invalid key: '" + p[0] + "' in \\includegraphics.");
          }
        }
      }
    var w = ae(e[0], "url").url;
    return s === "" && (s = w, s = s.replace(/^.*[\\/]/, ""), s = s.substring(0, s.lastIndexOf("."))), a.settings.isTrusted({
      command: "\\includegraphics",
      url: w
    }) ? {
      type: "includegraphics",
      mode: a.mode,
      alt: s,
      width: n,
      height: i,
      totalheight: l,
      src: w
    } : a.formatUnsupportedCmd("\\includegraphics");
  },
  htmlBuilder: (r, e) => {
    var t = ze(r.height, e), a = 0;
    r.totalheight.number > 0 && (a = ze(r.totalheight, e) - t);
    var n = 0;
    r.width.number > 0 && (n = ze(r.width, e));
    var i = {
      height: q(t + a)
    };
    n > 0 && (i.width = q(n)), a > 0 && (i.verticalAlign = q(-a));
    var l = new Os(r.src, r.alt, i);
    return l.height = t, l.depth = a, l;
  },
  mathmlBuilder: (r, e) => {
    var t = new N.MathNode("mglyph", []);
    t.setAttribute("alt", r.alt);
    var a = ze(r.height, e), n = 0;
    if (r.totalheight.number > 0 && (n = ze(r.totalheight, e) - a, t.setAttribute("valign", q(-n))), t.setAttribute("height", q(a + n)), r.width.number > 0) {
      var i = ze(r.width, e);
      t.setAttribute("width", q(i));
    }
    return t.setAttribute("src", r.src), t;
  }
});
P({
  type: "kern",
  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    primitive: !0,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = ae(e[0], "size");
    if (t.settings.strict) {
      var i = a[1] === "m", l = n.value.unit === "mu";
      i ? (l || t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " supports only mu units, " + ("not " + n.value.unit + " units")), t.mode !== "math" && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " works only in math mode")) : l && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " doesn't support mu units");
    }
    return {
      type: "kern",
      mode: t.mode,
      dimension: n.value
    };
  },
  htmlBuilder(r, e) {
    return T.makeGlue(r.dimension, e);
  },
  mathmlBuilder(r, e) {
    var t = ze(r.dimension, e);
    return new N.SpaceNode(t);
  }
});
P({
  type: "lap",
  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "lap",
      mode: t.mode,
      alignment: a.slice(5),
      body: n
    };
  },
  htmlBuilder: (r, e) => {
    var t;
    r.alignment === "clap" ? (t = T.makeSpan([], [he(r.body, e)]), t = T.makeSpan(["inner"], [t], e)) : t = T.makeSpan(["inner"], [he(r.body, e)]);
    var a = T.makeSpan(["fix"], []), n = T.makeSpan([r.alignment], [t, a], e), i = T.makeSpan(["strut"]);
    return i.style.height = q(n.height + n.depth), n.depth && (i.style.verticalAlign = q(-n.depth)), n.children.unshift(i), n = T.makeSpan(["thinbox"], [n], e), T.makeSpan(["mord", "vbox"], [n], e);
  },
  mathmlBuilder: (r, e) => {
    var t = new N.MathNode("mpadded", [De(r.body, e)]);
    if (r.alignment !== "rlap") {
      var a = r.alignment === "llap" ? "-1" : "-0.5";
      t.setAttribute("lspace", a + "width");
    }
    return t.setAttribute("width", "0px"), t;
  }
});
P({
  type: "styling",
  names: ["\\(", "$"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(r, e) {
    var {
      funcName: t,
      parser: a
    } = r, n = a.mode;
    a.switchMode("math");
    var i = t === "\\(" ? "\\)" : "$", l = a.parseExpression(!1, i);
    return a.expect(i), a.switchMode(n), {
      type: "styling",
      mode: a.mode,
      style: "text",
      body: l
    };
  }
});
P({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\)", "\\]"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(r, e) {
    throw new W("Mismatched " + r.funcName);
  }
});
var Bn = (r, e) => {
  switch (e.style.size) {
    case Z.DISPLAY.size:
      return r.display;
    case Z.TEXT.size:
      return r.text;
    case Z.SCRIPT.size:
      return r.script;
    case Z.SCRIPTSCRIPT.size:
      return r.scriptscript;
    default:
      return r.text;
  }
};
P({
  type: "mathchoice",
  names: ["\\mathchoice"],
  props: {
    numArgs: 4,
    primitive: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r;
    return {
      type: "mathchoice",
      mode: t.mode,
      display: Oe(e[0]),
      text: Oe(e[1]),
      script: Oe(e[2]),
      scriptscript: Oe(e[3])
    };
  },
  htmlBuilder: (r, e) => {
    var t = Bn(r, e), a = je(t, e, !1);
    return T.makeFragment(a);
  },
  mathmlBuilder: (r, e) => {
    var t = Bn(r, e);
    return it(t, e);
  }
});
var fl = (r, e, t, a, n, i, l) => {
  r = T.makeSpan([], [r]);
  var s = t && j.isCharacterBox(t), o, m;
  if (e) {
    var f = he(e, a.havingStyle(n.sup()), a);
    m = {
      elem: f,
      kern: Math.max(a.fontMetrics().bigOpSpacing1, a.fontMetrics().bigOpSpacing3 - f.depth)
    };
  }
  if (t) {
    var p = he(t, a.havingStyle(n.sub()), a);
    o = {
      elem: p,
      kern: Math.max(a.fontMetrics().bigOpSpacing2, a.fontMetrics().bigOpSpacing4 - p.height)
    };
  }
  var g;
  if (m && o) {
    var w = a.fontMetrics().bigOpSpacing5 + o.elem.height + o.elem.depth + o.kern + r.depth + l;
    g = T.makeVList({
      positionType: "bottom",
      positionData: w,
      children: [{
        type: "kern",
        size: a.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: o.elem,
        marginLeft: q(-i)
      }, {
        type: "kern",
        size: o.kern
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: m.kern
      }, {
        type: "elem",
        elem: m.elem,
        marginLeft: q(i)
      }, {
        type: "kern",
        size: a.fontMetrics().bigOpSpacing5
      }]
    }, a);
  } else if (o) {
    var F = r.height - l;
    g = T.makeVList({
      positionType: "top",
      positionData: F,
      children: [{
        type: "kern",
        size: a.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: o.elem,
        marginLeft: q(-i)
      }, {
        type: "kern",
        size: o.kern
      }, {
        type: "elem",
        elem: r
      }]
    }, a);
  } else if (m) {
    var E = r.depth + l;
    g = T.makeVList({
      positionType: "bottom",
      positionData: E,
      children: [{
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: m.kern
      }, {
        type: "elem",
        elem: m.elem,
        marginLeft: q(i)
      }, {
        type: "kern",
        size: a.fontMetrics().bigOpSpacing5
      }]
    }, a);
  } else
    return r;
  var k = [g];
  if (o && i !== 0 && !s) {
    var S = T.makeSpan(["mspace"], [], a);
    S.style.marginRight = q(i), k.unshift(S);
  }
  return T.makeSpan(["mop", "op-limits"], k, a);
}, dl = ["\\smallint"], Lt = (r, e) => {
  var t, a, n = !1, i;
  r.type === "supsub" ? (t = r.sup, a = r.sub, i = ae(r.base, "op"), n = !0) : i = ae(r, "op");
  var l = e.style, s = !1;
  l.size === Z.DISPLAY.size && i.symbol && !j.contains(dl, i.name) && (s = !0);
  var o;
  if (i.symbol) {
    var m = s ? "Size2-Regular" : "Size1-Regular", f = "";
    if ((i.name === "\\oiint" || i.name === "\\oiiint") && (f = i.name.slice(1), i.name = f === "oiint" ? "\\iint" : "\\iiint"), o = T.makeSymbol(i.name, m, "math", e, ["mop", "op-symbol", s ? "large-op" : "small-op"]), f.length > 0) {
      var p = o.italic, g = T.staticSvg(f + "Size" + (s ? "2" : "1"), e);
      o = T.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: o,
          shift: 0
        }, {
          type: "elem",
          elem: g,
          shift: s ? 0.08 : 0
        }]
      }, e), i.name = "\\" + f, o.classes.unshift("mop"), o.italic = p;
    }
  } else if (i.body) {
    var w = je(i.body, e, !0);
    w.length === 1 && w[0] instanceof P0 ? (o = w[0], o.classes[0] = "mop") : o = T.makeSpan(["mop"], w, e);
  } else {
    for (var F = [], E = 1; E < i.name.length; E++)
      F.push(T.mathsym(i.name[E], i.mode, e));
    o = T.makeSpan(["mop"], F, e);
  }
  var k = 0, S = 0;
  return (o instanceof P0 || i.name === "\\oiint" || i.name === "\\oiiint") && !i.suppressBaseShift && (k = (o.height - o.depth) / 2 - e.fontMetrics().axisHeight, S = o.italic), n ? fl(o, t, a, e, l, S, k) : (k && (o.style.position = "relative", o.style.top = q(k)), o);
}, ar = (r, e) => {
  var t;
  if (r.symbol)
    t = new C0("mo", [x0(r.name, r.mode)]), j.contains(dl, r.name) && t.setAttribute("largeop", "false");
  else if (r.body)
    t = new C0("mo", b0(r.body, e));
  else {
    t = new C0("mi", [new Kt(r.name.slice(1))]);
    var a = new C0("mo", [x0("⁡", "text")]);
    r.parentIsSupSub ? t = new C0("mrow", [t, a]) : t = Wi([t, a]);
  }
  return t;
}, L1 = {
  "∏": "\\prod",
  "∐": "\\coprod",
  "∑": "\\sum",
  "⋀": "\\bigwedge",
  "⋁": "\\bigvee",
  "⋂": "\\bigcap",
  "⋃": "\\bigcup",
  "⨀": "\\bigodot",
  "⨁": "\\bigoplus",
  "⨂": "\\bigotimes",
  "⨄": "\\biguplus",
  "⨆": "\\bigsqcup"
};
P({
  type: "op",
  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
  props: {
    numArgs: 0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = a;
    return n.length === 1 && (n = L1[n]), {
      type: "op",
      mode: t.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !0,
      name: n
    };
  },
  htmlBuilder: Lt,
  mathmlBuilder: ar
});
P({
  type: "op",
  names: ["\\mathop"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[0];
    return {
      type: "op",
      mode: t.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      body: Oe(a)
    };
  },
  htmlBuilder: Lt,
  mathmlBuilder: ar
});
var O1 = {
  "∫": "\\int",
  "∬": "\\iint",
  "∭": "\\iiint",
  "∮": "\\oint",
  "∯": "\\oiint",
  "∰": "\\oiiint"
};
P({
  type: "op",
  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    return {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: Lt,
  mathmlBuilder: ar
});
P({
  type: "op",
  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    return {
      type: "op",
      mode: e.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: Lt,
  mathmlBuilder: ar
});
P({
  type: "op",
  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, a = t;
    return a.length === 1 && (a = O1[a]), {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !0,
      name: a
    };
  },
  htmlBuilder: Lt,
  mathmlBuilder: ar
});
var pl = (r, e) => {
  var t, a, n = !1, i;
  r.type === "supsub" ? (t = r.sup, a = r.sub, i = ae(r.base, "operatorname"), n = !0) : i = ae(r, "operatorname");
  var l;
  if (i.body.length > 0) {
    for (var s = i.body.map((p) => {
      var g = p.text;
      return typeof g == "string" ? {
        type: "textord",
        mode: p.mode,
        text: g
      } : p;
    }), o = je(s, e.withFont("mathrm"), !0), m = 0; m < o.length; m++) {
      var f = o[m];
      f instanceof P0 && (f.text = f.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
    }
    l = T.makeSpan(["mop"], o, e);
  } else
    l = T.makeSpan(["mop"], [], e);
  return n ? fl(l, t, a, e, e.style, 0, 0) : l;
}, q1 = (r, e) => {
  for (var t = b0(r.body, e.withFont("mathrm")), a = !0, n = 0; n < t.length; n++) {
    var i = t[n];
    if (!(i instanceof N.SpaceNode)) if (i instanceof N.MathNode)
      switch (i.type) {
        case "mi":
        case "mn":
        case "ms":
        case "mspace":
        case "mtext":
          break;
        case "mo": {
          var l = i.children[0];
          i.children.length === 1 && l instanceof N.TextNode ? l.text = l.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : a = !1;
          break;
        }
        default:
          a = !1;
      }
    else
      a = !1;
  }
  if (a) {
    var s = t.map((f) => f.toText()).join("");
    t = [new N.TextNode(s)];
  }
  var o = new N.MathNode("mi", t);
  o.setAttribute("mathvariant", "normal");
  var m = new N.MathNode("mo", [x0("⁡", "text")]);
  return r.parentIsSupSub ? new N.MathNode("mrow", [o, m]) : N.newDocumentFragment([o, m]);
};
P({
  type: "operatorname",
  names: ["\\operatorname@", "\\operatornamewithlimits"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "operatorname",
      mode: t.mode,
      body: Oe(n),
      alwaysHandleSupSub: a === "\\operatornamewithlimits",
      limits: !1,
      parentIsSupSub: !1
    };
  },
  htmlBuilder: pl,
  mathmlBuilder: q1
});
d("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
wt({
  type: "ordgroup",
  htmlBuilder(r, e) {
    return r.semisimple ? T.makeFragment(je(r.body, e, !1)) : T.makeSpan(["mord"], je(r.body, e, !0), e);
  },
  mathmlBuilder(r, e) {
    return it(r.body, e, !0);
  }
});
P({
  type: "overline",
  names: ["\\overline"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t
    } = r, a = e[0];
    return {
      type: "overline",
      mode: t.mode,
      body: a
    };
  },
  htmlBuilder(r, e) {
    var t = he(r.body, e.havingCrampedStyle()), a = T.makeLineSpan("overline-line", e), n = e.fontMetrics().defaultRuleThickness, i = T.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }, {
        type: "kern",
        size: 3 * n
      }, {
        type: "elem",
        elem: a
      }, {
        type: "kern",
        size: n
      }]
    }, e);
    return T.makeSpan(["mord", "overline"], [i], e);
  },
  mathmlBuilder(r, e) {
    var t = new N.MathNode("mo", [new N.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var a = new N.MathNode("mover", [De(r.body, e), t]);
    return a.setAttribute("accent", "true"), a;
  }
});
P({
  type: "phantom",
  names: ["\\phantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[0];
    return {
      type: "phantom",
      mode: t.mode,
      body: Oe(a)
    };
  },
  htmlBuilder: (r, e) => {
    var t = je(r.body, e.withPhantom(), !1);
    return T.makeFragment(t);
  },
  mathmlBuilder: (r, e) => {
    var t = b0(r.body, e);
    return new N.MathNode("mphantom", t);
  }
});
P({
  type: "hphantom",
  names: ["\\hphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[0];
    return {
      type: "hphantom",
      mode: t.mode,
      body: a
    };
  },
  htmlBuilder: (r, e) => {
    var t = T.makeSpan([], [he(r.body, e.withPhantom())]);
    if (t.height = 0, t.depth = 0, t.children)
      for (var a = 0; a < t.children.length; a++)
        t.children[a].height = 0, t.children[a].depth = 0;
    return t = T.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e), T.makeSpan(["mord"], [t], e);
  },
  mathmlBuilder: (r, e) => {
    var t = b0(Oe(r.body), e), a = new N.MathNode("mphantom", t), n = new N.MathNode("mpadded", [a]);
    return n.setAttribute("height", "0px"), n.setAttribute("depth", "0px"), n;
  }
});
P({
  type: "vphantom",
  names: ["\\vphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[0];
    return {
      type: "vphantom",
      mode: t.mode,
      body: a
    };
  },
  htmlBuilder: (r, e) => {
    var t = T.makeSpan(["inner"], [he(r.body, e.withPhantom())]), a = T.makeSpan(["fix"], []);
    return T.makeSpan(["mord", "rlap"], [t, a], e);
  },
  mathmlBuilder: (r, e) => {
    var t = b0(Oe(r.body), e), a = new N.MathNode("mphantom", t), n = new N.MathNode("mpadded", [a]);
    return n.setAttribute("width", "0px"), n;
  }
});
P({
  type: "raisebox",
  names: ["\\raisebox"],
  props: {
    numArgs: 2,
    argTypes: ["size", "hbox"],
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r, a = ae(e[0], "size").value, n = e[1];
    return {
      type: "raisebox",
      mode: t.mode,
      dy: a,
      body: n
    };
  },
  htmlBuilder(r, e) {
    var t = he(r.body, e), a = ze(r.dy, e);
    return T.makeVList({
      positionType: "shift",
      positionData: -a,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(r, e) {
    var t = new N.MathNode("mpadded", [De(r.body, e)]), a = r.dy.number + r.dy.unit;
    return t.setAttribute("voffset", a), t;
  }
});
P({
  type: "internal",
  names: ["\\relax"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r) {
    var {
      parser: e
    } = r;
    return {
      type: "internal",
      mode: e.mode
    };
  }
});
P({
  type: "rule",
  names: ["\\rule"],
  props: {
    numArgs: 2,
    numOptionalArgs: 1,
    argTypes: ["size", "size", "size"]
  },
  handler(r, e, t) {
    var {
      parser: a
    } = r, n = t[0], i = ae(e[0], "size"), l = ae(e[1], "size");
    return {
      type: "rule",
      mode: a.mode,
      shift: n && ae(n, "size").value,
      width: i.value,
      height: l.value
    };
  },
  htmlBuilder(r, e) {
    var t = T.makeSpan(["mord", "rule"], [], e), a = ze(r.width, e), n = ze(r.height, e), i = r.shift ? ze(r.shift, e) : 0;
    return t.style.borderRightWidth = q(a), t.style.borderTopWidth = q(n), t.style.bottom = q(i), t.width = a, t.height = n + i, t.depth = -i, t.maxFontSize = n * 1.125 * e.sizeMultiplier, t;
  },
  mathmlBuilder(r, e) {
    var t = ze(r.width, e), a = ze(r.height, e), n = r.shift ? ze(r.shift, e) : 0, i = e.color && e.getColor() || "black", l = new N.MathNode("mspace");
    l.setAttribute("mathbackground", i), l.setAttribute("width", q(t)), l.setAttribute("height", q(a));
    var s = new N.MathNode("mpadded", [l]);
    return n >= 0 ? s.setAttribute("height", q(n)) : (s.setAttribute("height", q(n)), s.setAttribute("depth", q(-n))), s.setAttribute("voffset", q(n)), s;
  }
});
function gl(r, e, t) {
  for (var a = je(r, e, !1), n = e.sizeMultiplier / t.sizeMultiplier, i = 0; i < a.length; i++) {
    var l = a[i].classes.indexOf("sizing");
    l < 0 ? Array.prototype.push.apply(a[i].classes, e.sizingClasses(t)) : a[i].classes[l + 1] === "reset-size" + e.size && (a[i].classes[l + 1] = "reset-size" + t.size), a[i].height *= n, a[i].depth *= n;
  }
  return T.makeFragment(a);
}
var zn = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], P1 = (r, e) => {
  var t = e.havingSize(r.size);
  return gl(r.body, t, e);
};
P({
  type: "sizing",
  names: zn,
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      breakOnTokenText: t,
      funcName: a,
      parser: n
    } = r, i = n.parseExpression(!1, t);
    return {
      type: "sizing",
      mode: n.mode,
      // Figure out what size to use based on the list of functions above
      size: zn.indexOf(a) + 1,
      body: i
    };
  },
  htmlBuilder: P1,
  mathmlBuilder: (r, e) => {
    var t = e.havingSize(r.size), a = b0(r.body, t), n = new N.MathNode("mstyle", a);
    return n.setAttribute("mathsize", q(t.sizeMultiplier)), n;
  }
});
P({
  type: "smash",
  names: ["\\smash"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    allowedInText: !0
  },
  handler: (r, e, t) => {
    var {
      parser: a
    } = r, n = !1, i = !1, l = t[0] && ae(t[0], "ordgroup");
    if (l)
      for (var s = "", o = 0; o < l.body.length; ++o) {
        var m = l.body[o];
        if (s = m.text, s === "t")
          n = !0;
        else if (s === "b")
          i = !0;
        else {
          n = !1, i = !1;
          break;
        }
      }
    else
      n = !0, i = !0;
    var f = e[0];
    return {
      type: "smash",
      mode: a.mode,
      body: f,
      smashHeight: n,
      smashDepth: i
    };
  },
  htmlBuilder: (r, e) => {
    var t = T.makeSpan([], [he(r.body, e)]);
    if (!r.smashHeight && !r.smashDepth)
      return t;
    if (r.smashHeight && (t.height = 0, t.children))
      for (var a = 0; a < t.children.length; a++)
        t.children[a].height = 0;
    if (r.smashDepth && (t.depth = 0, t.children))
      for (var n = 0; n < t.children.length; n++)
        t.children[n].depth = 0;
    var i = T.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
    return T.makeSpan(["mord"], [i], e);
  },
  mathmlBuilder: (r, e) => {
    var t = new N.MathNode("mpadded", [De(r.body, e)]);
    return r.smashHeight && t.setAttribute("height", "0px"), r.smashDepth && t.setAttribute("depth", "0px"), t;
  }
});
P({
  type: "sqrt",
  names: ["\\sqrt"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(r, e, t) {
    var {
      parser: a
    } = r, n = t[0], i = e[0];
    return {
      type: "sqrt",
      mode: a.mode,
      body: i,
      index: n
    };
  },
  htmlBuilder(r, e) {
    var t = he(r.body, e.havingCrampedStyle());
    t.height === 0 && (t.height = e.fontMetrics().xHeight), t = T.wrapFragment(t, e);
    var a = e.fontMetrics(), n = a.defaultRuleThickness, i = n;
    e.style.id < Z.TEXT.id && (i = e.fontMetrics().xHeight);
    var l = n + i / 4, s = t.height + t.depth + l + n, {
      span: o,
      ruleWidth: m,
      advanceWidth: f
    } = Z0.sqrtImage(s, e), p = o.height - m;
    p > t.height + t.depth + l && (l = (l + p - t.height - t.depth) / 2);
    var g = o.height - t.height - l - m;
    t.style.paddingLeft = q(f);
    var w = T.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: -(t.height + g)
      }, {
        type: "elem",
        elem: o
      }, {
        type: "kern",
        size: m
      }]
    }, e);
    if (r.index) {
      var F = e.havingStyle(Z.SCRIPTSCRIPT), E = he(r.index, F, e), k = 0.6 * (w.height - w.depth), S = T.makeVList({
        positionType: "shift",
        positionData: -k,
        children: [{
          type: "elem",
          elem: E
        }]
      }, e), y = T.makeSpan(["root"], [S]);
      return T.makeSpan(["mord", "sqrt"], [y, w], e);
    } else
      return T.makeSpan(["mord", "sqrt"], [w], e);
  },
  mathmlBuilder(r, e) {
    var {
      body: t,
      index: a
    } = r;
    return a ? new N.MathNode("mroot", [De(t, e), De(a, e)]) : new N.MathNode("msqrt", [De(t, e)]);
  }
});
var Rn = {
  display: Z.DISPLAY,
  text: Z.TEXT,
  script: Z.SCRIPT,
  scriptscript: Z.SCRIPTSCRIPT
};
P({
  type: "styling",
  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r, e) {
    var {
      breakOnTokenText: t,
      funcName: a,
      parser: n
    } = r, i = n.parseExpression(!0, t), l = a.slice(1, a.length - 5);
    return {
      type: "styling",
      mode: n.mode,
      // Figure out what style to use by pulling out the style from
      // the function name
      style: l,
      body: i
    };
  },
  htmlBuilder(r, e) {
    var t = Rn[r.style], a = e.havingStyle(t).withFont("");
    return gl(r.body, a, e);
  },
  mathmlBuilder(r, e) {
    var t = Rn[r.style], a = e.havingStyle(t), n = b0(r.body, a), i = new N.MathNode("mstyle", n), l = {
      display: ["0", "true"],
      text: ["0", "false"],
      script: ["1", "false"],
      scriptscript: ["2", "false"]
    }, s = l[r.style];
    return i.setAttribute("scriptlevel", s[0]), i.setAttribute("displaystyle", s[1]), i;
  }
});
var H1 = function(e, t) {
  var a = e.base;
  if (a)
    if (a.type === "op") {
      var n = a.limits && (t.style.size === Z.DISPLAY.size || a.alwaysHandleSupSub);
      return n ? Lt : null;
    } else if (a.type === "operatorname") {
      var i = a.alwaysHandleSupSub && (t.style.size === Z.DISPLAY.size || a.limits);
      return i ? pl : null;
    } else {
      if (a.type === "accent")
        return j.isCharacterBox(a.base) ? Ma : null;
      if (a.type === "horizBrace") {
        var l = !e.sub;
        return l === a.isOver ? ml : null;
      } else
        return null;
    }
  else return null;
};
wt({
  type: "supsub",
  htmlBuilder(r, e) {
    var t = H1(r, e);
    if (t)
      return t(r, e);
    var {
      base: a,
      sup: n,
      sub: i
    } = r, l = he(a, e), s, o, m = e.fontMetrics(), f = 0, p = 0, g = a && j.isCharacterBox(a);
    if (n) {
      var w = e.havingStyle(e.style.sup());
      s = he(n, w, e), g || (f = l.height - w.fontMetrics().supDrop * w.sizeMultiplier / e.sizeMultiplier);
    }
    if (i) {
      var F = e.havingStyle(e.style.sub());
      o = he(i, F, e), g || (p = l.depth + F.fontMetrics().subDrop * F.sizeMultiplier / e.sizeMultiplier);
    }
    var E;
    e.style === Z.DISPLAY ? E = m.sup1 : e.style.cramped ? E = m.sup3 : E = m.sup2;
    var k = e.sizeMultiplier, S = q(0.5 / m.ptPerEm / k), y = null;
    if (o) {
      var D = r.base && r.base.type === "op" && r.base.name && (r.base.name === "\\oiint" || r.base.name === "\\oiiint");
      (l instanceof P0 || D) && (y = q(-l.italic));
    }
    var _;
    if (s && o) {
      f = Math.max(f, E, s.depth + 0.25 * m.xHeight), p = Math.max(p, m.sub2);
      var C = m.defaultRuleThickness, M = 4 * C;
      if (f - s.depth - (o.height - p) < M) {
        p = M - (f - s.depth) + o.height;
        var R = 0.8 * m.xHeight - (f - s.depth);
        R > 0 && (f += R, p -= R);
      }
      var U = [{
        type: "elem",
        elem: o,
        shift: p,
        marginRight: S,
        marginLeft: y
      }, {
        type: "elem",
        elem: s,
        shift: -f,
        marginRight: S
      }];
      _ = T.makeVList({
        positionType: "individualShift",
        children: U
      }, e);
    } else if (o) {
      p = Math.max(p, m.sub1, o.height - 0.8 * m.xHeight);
      var I = [{
        type: "elem",
        elem: o,
        marginLeft: y,
        marginRight: S
      }];
      _ = T.makeVList({
        positionType: "shift",
        positionData: p,
        children: I
      }, e);
    } else if (s)
      f = Math.max(f, E, s.depth + 0.25 * m.xHeight), _ = T.makeVList({
        positionType: "shift",
        positionData: -f,
        children: [{
          type: "elem",
          elem: s,
          marginRight: S
        }]
      }, e);
    else
      throw new Error("supsub must have either sup or sub.");
    var O = ga(l, "right") || "mord";
    return T.makeSpan([O], [l, T.makeSpan(["msupsub"], [_])], e);
  },
  mathmlBuilder(r, e) {
    var t = !1, a, n;
    r.base && r.base.type === "horizBrace" && (n = !!r.sup, n === r.base.isOver && (t = !0, a = r.base.isOver)), r.base && (r.base.type === "op" || r.base.type === "operatorname") && (r.base.parentIsSupSub = !0);
    var i = [De(r.base, e)];
    r.sub && i.push(De(r.sub, e)), r.sup && i.push(De(r.sup, e));
    var l;
    if (t)
      l = a ? "mover" : "munder";
    else if (r.sub)
      if (r.sup) {
        var m = r.base;
        m && m.type === "op" && m.limits && e.style === Z.DISPLAY || m && m.type === "operatorname" && m.alwaysHandleSupSub && (e.style === Z.DISPLAY || m.limits) ? l = "munderover" : l = "msubsup";
      } else {
        var o = r.base;
        o && o.type === "op" && o.limits && (e.style === Z.DISPLAY || o.alwaysHandleSupSub) || o && o.type === "operatorname" && o.alwaysHandleSupSub && (o.limits || e.style === Z.DISPLAY) ? l = "munder" : l = "msub";
      }
    else {
      var s = r.base;
      s && s.type === "op" && s.limits && (e.style === Z.DISPLAY || s.alwaysHandleSupSub) || s && s.type === "operatorname" && s.alwaysHandleSupSub && (s.limits || e.style === Z.DISPLAY) ? l = "mover" : l = "msup";
    }
    return new N.MathNode(l, i);
  }
});
wt({
  type: "atom",
  htmlBuilder(r, e) {
    return T.mathsym(r.text, r.mode, e, ["m" + r.family]);
  },
  mathmlBuilder(r, e) {
    var t = new N.MathNode("mo", [x0(r.text, r.mode)]);
    if (r.family === "bin") {
      var a = Ta(r, e);
      a === "bold-italic" && t.setAttribute("mathvariant", a);
    } else r.family === "punct" ? t.setAttribute("separator", "true") : (r.family === "open" || r.family === "close") && t.setAttribute("stretchy", "false");
    return t;
  }
});
var vl = {
  mi: "italic",
  mn: "normal",
  mtext: "normal"
};
wt({
  type: "mathord",
  htmlBuilder(r, e) {
    return T.makeOrd(r, e, "mathord");
  },
  mathmlBuilder(r, e) {
    var t = new N.MathNode("mi", [x0(r.text, r.mode, e)]), a = Ta(r, e) || "italic";
    return a !== vl[t.type] && t.setAttribute("mathvariant", a), t;
  }
});
wt({
  type: "textord",
  htmlBuilder(r, e) {
    return T.makeOrd(r, e, "textord");
  },
  mathmlBuilder(r, e) {
    var t = x0(r.text, r.mode, e), a = Ta(r, e) || "normal", n;
    return r.mode === "text" ? n = new N.MathNode("mtext", [t]) : /[0-9]/.test(r.text) ? n = new N.MathNode("mn", [t]) : r.text === "\\prime" ? n = new N.MathNode("mo", [t]) : n = new N.MathNode("mi", [t]), a !== vl[n.type] && n.setAttribute("mathvariant", a), n;
  }
});
var aa = {
  "\\nobreak": "nobreak",
  "\\allowbreak": "allowbreak"
}, na = {
  " ": {},
  "\\ ": {},
  "~": {
    className: "nobreak"
  },
  "\\space": {},
  "\\nobreakspace": {
    className: "nobreak"
  }
};
wt({
  type: "spacing",
  htmlBuilder(r, e) {
    if (na.hasOwnProperty(r.text)) {
      var t = na[r.text].className || "";
      if (r.mode === "text") {
        var a = T.makeOrd(r, e, "textord");
        return a.classes.push(t), a;
      } else
        return T.makeSpan(["mspace", t], [T.mathsym(r.text, r.mode, e)], e);
    } else {
      if (aa.hasOwnProperty(r.text))
        return T.makeSpan(["mspace", aa[r.text]], [], e);
      throw new W('Unknown type of space "' + r.text + '"');
    }
  },
  mathmlBuilder(r, e) {
    var t;
    if (na.hasOwnProperty(r.text))
      t = new N.MathNode("mtext", [new N.TextNode(" ")]);
    else {
      if (aa.hasOwnProperty(r.text))
        return new N.MathNode("mspace");
      throw new W('Unknown type of space "' + r.text + '"');
    }
    return t;
  }
});
var Nn = () => {
  var r = new N.MathNode("mtd", []);
  return r.setAttribute("width", "50%"), r;
};
wt({
  type: "tag",
  mathmlBuilder(r, e) {
    var t = new N.MathNode("mtable", [new N.MathNode("mtr", [Nn(), new N.MathNode("mtd", [it(r.body, e)]), Nn(), new N.MathNode("mtd", [it(r.tag, e)])])]);
    return t.setAttribute("width", "100%"), t;
  }
});
var In = {
  "\\text": void 0,
  "\\textrm": "textrm",
  "\\textsf": "textsf",
  "\\texttt": "texttt",
  "\\textnormal": "textrm"
}, Ln = {
  "\\textbf": "textbf",
  "\\textmd": "textmd"
}, U1 = {
  "\\textit": "textit",
  "\\textup": "textup"
}, On = (r, e) => {
  var t = r.font;
  if (t) {
    if (In[t])
      return e.withTextFontFamily(In[t]);
    if (Ln[t])
      return e.withTextFontWeight(Ln[t]);
    if (t === "\\emph")
      return e.fontShape === "textit" ? e.withTextFontShape("textup") : e.withTextFontShape("textit");
  } else return e;
  return e.withTextFontShape(U1[t]);
};
P({
  type: "text",
  names: [
    // Font families
    "\\text",
    "\\textrm",
    "\\textsf",
    "\\texttt",
    "\\textnormal",
    // Font weights
    "\\textbf",
    "\\textmd",
    // Font Shapes
    "\\textit",
    "\\textup",
    "\\emph"
  ],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInArgument: !0,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "text",
      mode: t.mode,
      body: Oe(n),
      font: a
    };
  },
  htmlBuilder(r, e) {
    var t = On(r, e), a = je(r.body, t, !0);
    return T.makeSpan(["mord", "text"], a, t);
  },
  mathmlBuilder(r, e) {
    var t = On(r, e);
    return it(r.body, t);
  }
});
P({
  type: "underline",
  names: ["\\underline"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "underline",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = he(r.body, e), a = T.makeLineSpan("underline-line", e), n = e.fontMetrics().defaultRuleThickness, i = T.makeVList({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "kern",
        size: n
      }, {
        type: "elem",
        elem: a
      }, {
        type: "kern",
        size: 3 * n
      }, {
        type: "elem",
        elem: t
      }]
    }, e);
    return T.makeSpan(["mord", "underline"], [i], e);
  },
  mathmlBuilder(r, e) {
    var t = new N.MathNode("mo", [new N.TextNode("‾")]);
    t.setAttribute("stretchy", "true");
    var a = new N.MathNode("munder", [De(r.body, e), t]);
    return a.setAttribute("accentunder", "true"), a;
  }
});
P({
  type: "vcenter",
  names: ["\\vcenter"],
  props: {
    numArgs: 1,
    argTypes: ["original"],
    // In LaTeX, \vcenter can act only on a box.
    allowedInText: !1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "vcenter",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = he(r.body, e), a = e.fontMetrics().axisHeight, n = 0.5 * (t.height - a - (t.depth + a));
    return T.makeVList({
      positionType: "shift",
      positionData: n,
      children: [{
        type: "elem",
        elem: t
      }]
    }, e);
  },
  mathmlBuilder(r, e) {
    return new N.MathNode("mpadded", [De(r.body, e)], ["vcenter"]);
  }
});
P({
  type: "verb",
  names: ["\\verb"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r, e, t) {
    throw new W("\\verb ended by end of line instead of matching delimiter");
  },
  htmlBuilder(r, e) {
    for (var t = qn(r), a = [], n = e.havingStyle(e.style.text()), i = 0; i < t.length; i++) {
      var l = t[i];
      l === "~" && (l = "\\textasciitilde"), a.push(T.makeSymbol(l, "Typewriter-Regular", r.mode, n, ["mord", "texttt"]));
    }
    return T.makeSpan(["mord", "text"].concat(n.sizingClasses(e)), T.tryCombineChars(a), n);
  },
  mathmlBuilder(r, e) {
    var t = new N.TextNode(qn(r)), a = new N.MathNode("mtext", [t]);
    return a.setAttribute("mathvariant", "monospace"), a;
  }
});
var qn = (r) => r.body.replace(/ /g, r.star ? "␣" : " "), G1 = Gi;
d("\\noexpand", function(r) {
  var e = r.popToken();
  return r.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), {
    tokens: [e],
    numArgs: 0
  };
});
d("\\expandafter", function(r) {
  var e = r.popToken();
  return r.expandOnce(!0), {
    tokens: [e],
    numArgs: 0
  };
});
d("\\@firstoftwo", function(r) {
  var e = r.consumeArgs(2);
  return {
    tokens: e[0],
    numArgs: 0
  };
});
d("\\@secondoftwo", function(r) {
  var e = r.consumeArgs(2);
  return {
    tokens: e[1],
    numArgs: 0
  };
});
d("\\@ifnextchar", function(r) {
  var e = r.consumeArgs(3);
  r.consumeSpaces();
  var t = r.future();
  return e[0].length === 1 && e[0][0].text === t.text ? {
    tokens: e[1],
    numArgs: 0
  } : {
    tokens: e[2],
    numArgs: 0
  };
});
d("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
d("\\TextOrMath", function(r) {
  var e = r.consumeArgs(2);
  return r.mode === "text" ? {
    tokens: e[0],
    numArgs: 0
  } : {
    tokens: e[1],
    numArgs: 0
  };
});
var Pn = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15
};
d("\\char", function(r) {
  var e = r.popToken(), t, a = "";
  if (e.text === "'")
    t = 8, e = r.popToken();
  else if (e.text === '"')
    t = 16, e = r.popToken();
  else if (e.text === "`")
    if (e = r.popToken(), e.text[0] === "\\")
      a = e.text.charCodeAt(1);
    else {
      if (e.text === "EOF")
        throw new W("\\char` missing argument");
      a = e.text.charCodeAt(0);
    }
  else
    t = 10;
  if (t) {
    if (a = Pn[e.text], a == null || a >= t)
      throw new W("Invalid base-" + t + " digit " + e.text);
    for (var n; (n = Pn[r.future().text]) != null && n < t; )
      a *= t, a += n, r.popToken();
  }
  return "\\@char{" + a + "}";
});
var qa = (r, e, t) => {
  var a = r.consumeArg().tokens;
  if (a.length !== 1)
    throw new W("\\newcommand's first argument must be a macro name");
  var n = a[0].text, i = r.isDefined(n);
  if (i && !e)
    throw new W("\\newcommand{" + n + "} attempting to redefine " + (n + "; use \\renewcommand"));
  if (!i && !t)
    throw new W("\\renewcommand{" + n + "} when command " + n + " does not yet exist; use \\newcommand");
  var l = 0;
  if (a = r.consumeArg().tokens, a.length === 1 && a[0].text === "[") {
    for (var s = "", o = r.expandNextToken(); o.text !== "]" && o.text !== "EOF"; )
      s += o.text, o = r.expandNextToken();
    if (!s.match(/^\s*[0-9]+\s*$/))
      throw new W("Invalid number of arguments: " + s);
    l = parseInt(s), a = r.consumeArg().tokens;
  }
  return r.macros.set(n, {
    tokens: a,
    numArgs: l
  }), "";
};
d("\\newcommand", (r) => qa(r, !1, !0));
d("\\renewcommand", (r) => qa(r, !0, !1));
d("\\providecommand", (r) => qa(r, !0, !0));
d("\\message", (r) => {
  var e = r.consumeArgs(1)[0];
  return console.log(e.reverse().map((t) => t.text).join("")), "";
});
d("\\errmessage", (r) => {
  var e = r.consumeArgs(1)[0];
  return console.error(e.reverse().map((t) => t.text).join("")), "";
});
d("\\show", (r) => {
  var e = r.popToken(), t = e.text;
  return console.log(e, r.macros.get(t), G1[t], qe.math[t], qe.text[t]), "";
});
d("\\bgroup", "{");
d("\\egroup", "}");
d("~", "\\nobreakspace");
d("\\lq", "`");
d("\\rq", "'");
d("\\aa", "\\r a");
d("\\AA", "\\r A");
d("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}");
d("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
d("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}");
d("ℬ", "\\mathscr{B}");
d("ℰ", "\\mathscr{E}");
d("ℱ", "\\mathscr{F}");
d("ℋ", "\\mathscr{H}");
d("ℐ", "\\mathscr{I}");
d("ℒ", "\\mathscr{L}");
d("ℳ", "\\mathscr{M}");
d("ℛ", "\\mathscr{R}");
d("ℭ", "\\mathfrak{C}");
d("ℌ", "\\mathfrak{H}");
d("ℨ", "\\mathfrak{Z}");
d("\\Bbbk", "\\Bbb{k}");
d("·", "\\cdotp");
d("\\llap", "\\mathllap{\\textrm{#1}}");
d("\\rlap", "\\mathrlap{\\textrm{#1}}");
d("\\clap", "\\mathclap{\\textrm{#1}}");
d("\\mathstrut", "\\vphantom{(}");
d("\\underbar", "\\underline{\\text{#1}}");
d("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char"338}');
d("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}");
d("\\ne", "\\neq");
d("≠", "\\neq");
d("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}");
d("∉", "\\notin");
d("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}");
d("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}");
d("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}");
d("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}");
d("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}");
d("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}");
d("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}");
d("⟂", "\\perp");
d("‼", "\\mathclose{!\\mkern-0.8mu!}");
d("∌", "\\notni");
d("⌜", "\\ulcorner");
d("⌝", "\\urcorner");
d("⌞", "\\llcorner");
d("⌟", "\\lrcorner");
d("©", "\\copyright");
d("®", "\\textregistered");
d("️", "\\textregistered");
d("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
d("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
d("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
d("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
d("\\vdots", "\\mathord{\\varvdots\\rule{0pt}{15pt}}");
d("⋮", "\\vdots");
d("\\varGamma", "\\mathit{\\Gamma}");
d("\\varDelta", "\\mathit{\\Delta}");
d("\\varTheta", "\\mathit{\\Theta}");
d("\\varLambda", "\\mathit{\\Lambda}");
d("\\varXi", "\\mathit{\\Xi}");
d("\\varPi", "\\mathit{\\Pi}");
d("\\varSigma", "\\mathit{\\Sigma}");
d("\\varUpsilon", "\\mathit{\\Upsilon}");
d("\\varPhi", "\\mathit{\\Phi}");
d("\\varPsi", "\\mathit{\\Psi}");
d("\\varOmega", "\\mathit{\\Omega}");
d("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
d("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
d("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
d("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
d("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
d("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
var Hn = {
  ",": "\\dotsc",
  "\\not": "\\dotsb",
  // \keybin@ checks for the following:
  "+": "\\dotsb",
  "=": "\\dotsb",
  "<": "\\dotsb",
  ">": "\\dotsb",
  "-": "\\dotsb",
  "*": "\\dotsb",
  ":": "\\dotsb",
  // Symbols whose definition starts with \DOTSB:
  "\\DOTSB": "\\dotsb",
  "\\coprod": "\\dotsb",
  "\\bigvee": "\\dotsb",
  "\\bigwedge": "\\dotsb",
  "\\biguplus": "\\dotsb",
  "\\bigcap": "\\dotsb",
  "\\bigcup": "\\dotsb",
  "\\prod": "\\dotsb",
  "\\sum": "\\dotsb",
  "\\bigotimes": "\\dotsb",
  "\\bigoplus": "\\dotsb",
  "\\bigodot": "\\dotsb",
  "\\bigsqcup": "\\dotsb",
  "\\And": "\\dotsb",
  "\\longrightarrow": "\\dotsb",
  "\\Longrightarrow": "\\dotsb",
  "\\longleftarrow": "\\dotsb",
  "\\Longleftarrow": "\\dotsb",
  "\\longleftrightarrow": "\\dotsb",
  "\\Longleftrightarrow": "\\dotsb",
  "\\mapsto": "\\dotsb",
  "\\longmapsto": "\\dotsb",
  "\\hookrightarrow": "\\dotsb",
  "\\doteq": "\\dotsb",
  // Symbols whose definition starts with \mathbin:
  "\\mathbin": "\\dotsb",
  // Symbols whose definition starts with \mathrel:
  "\\mathrel": "\\dotsb",
  "\\relbar": "\\dotsb",
  "\\Relbar": "\\dotsb",
  "\\xrightarrow": "\\dotsb",
  "\\xleftarrow": "\\dotsb",
  // Symbols whose definition starts with \DOTSI:
  "\\DOTSI": "\\dotsi",
  "\\int": "\\dotsi",
  "\\oint": "\\dotsi",
  "\\iint": "\\dotsi",
  "\\iiint": "\\dotsi",
  "\\iiiint": "\\dotsi",
  "\\idotsint": "\\dotsi",
  // Symbols whose definition starts with \DOTSX:
  "\\DOTSX": "\\dotsx"
};
d("\\dots", function(r) {
  var e = "\\dotso", t = r.expandAfterFuture().text;
  return t in Hn ? e = Hn[t] : (t.slice(0, 4) === "\\not" || t in qe.math && j.contains(["bin", "rel"], qe.math[t].group)) && (e = "\\dotsb"), e;
});
var Pa = {
  // \rightdelim@ checks for the following:
  ")": !0,
  "]": !0,
  "\\rbrack": !0,
  "\\}": !0,
  "\\rbrace": !0,
  "\\rangle": !0,
  "\\rceil": !0,
  "\\rfloor": !0,
  "\\rgroup": !0,
  "\\rmoustache": !0,
  "\\right": !0,
  "\\bigr": !0,
  "\\biggr": !0,
  "\\Bigr": !0,
  "\\Biggr": !0,
  // \extra@ also tests for the following:
  $: !0,
  // \extrap@ checks for the following:
  ";": !0,
  ".": !0,
  ",": !0
};
d("\\dotso", function(r) {
  var e = r.future().text;
  return e in Pa ? "\\ldots\\," : "\\ldots";
});
d("\\dotsc", function(r) {
  var e = r.future().text;
  return e in Pa && e !== "," ? "\\ldots\\," : "\\ldots";
});
d("\\cdots", function(r) {
  var e = r.future().text;
  return e in Pa ? "\\@cdots\\," : "\\@cdots";
});
d("\\dotsb", "\\cdots");
d("\\dotsm", "\\cdots");
d("\\dotsi", "\\!\\cdots");
d("\\dotsx", "\\ldots\\,");
d("\\DOTSI", "\\relax");
d("\\DOTSB", "\\relax");
d("\\DOTSX", "\\relax");
d("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
d("\\,", "\\tmspace+{3mu}{.1667em}");
d("\\thinspace", "\\,");
d("\\>", "\\mskip{4mu}");
d("\\:", "\\tmspace+{4mu}{.2222em}");
d("\\medspace", "\\:");
d("\\;", "\\tmspace+{5mu}{.2777em}");
d("\\thickspace", "\\;");
d("\\!", "\\tmspace-{3mu}{.1667em}");
d("\\negthinspace", "\\!");
d("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
d("\\negthickspace", "\\tmspace-{5mu}{.277em}");
d("\\enspace", "\\kern.5em ");
d("\\enskip", "\\hskip.5em\\relax");
d("\\quad", "\\hskip1em\\relax");
d("\\qquad", "\\hskip2em\\relax");
d("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
d("\\tag@paren", "\\tag@literal{({#1})}");
d("\\tag@literal", (r) => {
  if (r.macros.get("\\df@tag"))
    throw new W("Multiple \\tag");
  return "\\gdef\\df@tag{\\text{#1}}";
});
d("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
d("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
d("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
d("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
d("\\newline", "\\\\\\relax");
d("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var bl = q(j0["Main-Regular"][84][1] - 0.7 * j0["Main-Regular"][65][1]);
d("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + bl + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
d("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + bl + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
d("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
d("\\@hspace", "\\hskip #1\\relax");
d("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
d("\\ordinarycolon", ":");
d("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
d("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
d("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
d("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
d("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
d("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
d("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
d("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
d("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
d("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
d("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
d("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
d("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
d("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
d("∷", "\\dblcolon");
d("∹", "\\eqcolon");
d("≔", "\\coloneqq");
d("≕", "\\eqqcolon");
d("⩴", "\\Coloneqq");
d("\\ratio", "\\vcentcolon");
d("\\coloncolon", "\\dblcolon");
d("\\colonequals", "\\coloneqq");
d("\\coloncolonequals", "\\Coloneqq");
d("\\equalscolon", "\\eqqcolon");
d("\\equalscoloncolon", "\\Eqqcolon");
d("\\colonminus", "\\coloneq");
d("\\coloncolonminus", "\\Coloneq");
d("\\minuscolon", "\\eqcolon");
d("\\minuscoloncolon", "\\Eqcolon");
d("\\coloncolonapprox", "\\Colonapprox");
d("\\coloncolonsim", "\\Colonsim");
d("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
d("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
d("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
d("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
d("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}");
d("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
d("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
d("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
d("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
d("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
d("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
d("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
d("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
d("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}");
d("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}");
d("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}");
d("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}");
d("\\nleqq", "\\html@mathml{\\@nleqq}{≰}");
d("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}");
d("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}");
d("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}");
d("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}");
d("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}");
d("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}");
d("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}");
d("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}");
d("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}");
d("\\imath", "\\html@mathml{\\@imath}{ı}");
d("\\jmath", "\\html@mathml{\\@jmath}{ȷ}");
d("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}");
d("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}");
d("⟦", "\\llbracket");
d("⟧", "\\rrbracket");
d("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}");
d("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}");
d("⦃", "\\lBrace");
d("⦄", "\\rBrace");
d("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}");
d("⦵", "\\minuso");
d("\\darr", "\\downarrow");
d("\\dArr", "\\Downarrow");
d("\\Darr", "\\Downarrow");
d("\\lang", "\\langle");
d("\\rang", "\\rangle");
d("\\uarr", "\\uparrow");
d("\\uArr", "\\Uparrow");
d("\\Uarr", "\\Uparrow");
d("\\N", "\\mathbb{N}");
d("\\R", "\\mathbb{R}");
d("\\Z", "\\mathbb{Z}");
d("\\alef", "\\aleph");
d("\\alefsym", "\\aleph");
d("\\Alpha", "\\mathrm{A}");
d("\\Beta", "\\mathrm{B}");
d("\\bull", "\\bullet");
d("\\Chi", "\\mathrm{X}");
d("\\clubs", "\\clubsuit");
d("\\cnums", "\\mathbb{C}");
d("\\Complex", "\\mathbb{C}");
d("\\Dagger", "\\ddagger");
d("\\diamonds", "\\diamondsuit");
d("\\empty", "\\emptyset");
d("\\Epsilon", "\\mathrm{E}");
d("\\Eta", "\\mathrm{H}");
d("\\exist", "\\exists");
d("\\harr", "\\leftrightarrow");
d("\\hArr", "\\Leftrightarrow");
d("\\Harr", "\\Leftrightarrow");
d("\\hearts", "\\heartsuit");
d("\\image", "\\Im");
d("\\infin", "\\infty");
d("\\Iota", "\\mathrm{I}");
d("\\isin", "\\in");
d("\\Kappa", "\\mathrm{K}");
d("\\larr", "\\leftarrow");
d("\\lArr", "\\Leftarrow");
d("\\Larr", "\\Leftarrow");
d("\\lrarr", "\\leftrightarrow");
d("\\lrArr", "\\Leftrightarrow");
d("\\Lrarr", "\\Leftrightarrow");
d("\\Mu", "\\mathrm{M}");
d("\\natnums", "\\mathbb{N}");
d("\\Nu", "\\mathrm{N}");
d("\\Omicron", "\\mathrm{O}");
d("\\plusmn", "\\pm");
d("\\rarr", "\\rightarrow");
d("\\rArr", "\\Rightarrow");
d("\\Rarr", "\\Rightarrow");
d("\\real", "\\Re");
d("\\reals", "\\mathbb{R}");
d("\\Reals", "\\mathbb{R}");
d("\\Rho", "\\mathrm{P}");
d("\\sdot", "\\cdot");
d("\\sect", "\\S");
d("\\spades", "\\spadesuit");
d("\\sub", "\\subset");
d("\\sube", "\\subseteq");
d("\\supe", "\\supseteq");
d("\\Tau", "\\mathrm{T}");
d("\\thetasym", "\\vartheta");
d("\\weierp", "\\wp");
d("\\Zeta", "\\mathrm{Z}");
d("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
d("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
d("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
d("\\bra", "\\mathinner{\\langle{#1}|}");
d("\\ket", "\\mathinner{|{#1}\\rangle}");
d("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
d("\\Bra", "\\left\\langle#1\\right|");
d("\\Ket", "\\left|#1\\right\\rangle");
var yl = (r) => (e) => {
  var t = e.consumeArg().tokens, a = e.consumeArg().tokens, n = e.consumeArg().tokens, i = e.consumeArg().tokens, l = e.macros.get("|"), s = e.macros.get("\\|");
  e.macros.beginGroup();
  var o = (p) => (g) => {
    r && (g.macros.set("|", l), n.length && g.macros.set("\\|", s));
    var w = p;
    if (!p && n.length) {
      var F = g.future();
      F.text === "|" && (g.popToken(), w = !0);
    }
    return {
      tokens: w ? n : a,
      numArgs: 0
    };
  };
  e.macros.set("|", o(!1)), n.length && e.macros.set("\\|", o(!0));
  var m = e.consumeArg().tokens, f = e.expandTokens([
    ...i,
    ...m,
    ...t
    // reversed
  ]);
  return e.macros.endGroup(), {
    tokens: f.reverse(),
    numArgs: 0
  };
};
d("\\bra@ket", yl(!1));
d("\\bra@set", yl(!0));
d("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
d("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
d("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
d("\\angln", "{\\angl n}");
d("\\blue", "\\textcolor{##6495ed}{#1}");
d("\\orange", "\\textcolor{##ffa500}{#1}");
d("\\pink", "\\textcolor{##ff00af}{#1}");
d("\\red", "\\textcolor{##df0030}{#1}");
d("\\green", "\\textcolor{##28ae7b}{#1}");
d("\\gray", "\\textcolor{gray}{#1}");
d("\\purple", "\\textcolor{##9d38bd}{#1}");
d("\\blueA", "\\textcolor{##ccfaff}{#1}");
d("\\blueB", "\\textcolor{##80f6ff}{#1}");
d("\\blueC", "\\textcolor{##63d9ea}{#1}");
d("\\blueD", "\\textcolor{##11accd}{#1}");
d("\\blueE", "\\textcolor{##0c7f99}{#1}");
d("\\tealA", "\\textcolor{##94fff5}{#1}");
d("\\tealB", "\\textcolor{##26edd5}{#1}");
d("\\tealC", "\\textcolor{##01d1c1}{#1}");
d("\\tealD", "\\textcolor{##01a995}{#1}");
d("\\tealE", "\\textcolor{##208170}{#1}");
d("\\greenA", "\\textcolor{##b6ffb0}{#1}");
d("\\greenB", "\\textcolor{##8af281}{#1}");
d("\\greenC", "\\textcolor{##74cf70}{#1}");
d("\\greenD", "\\textcolor{##1fab54}{#1}");
d("\\greenE", "\\textcolor{##0d923f}{#1}");
d("\\goldA", "\\textcolor{##ffd0a9}{#1}");
d("\\goldB", "\\textcolor{##ffbb71}{#1}");
d("\\goldC", "\\textcolor{##ff9c39}{#1}");
d("\\goldD", "\\textcolor{##e07d10}{#1}");
d("\\goldE", "\\textcolor{##a75a05}{#1}");
d("\\redA", "\\textcolor{##fca9a9}{#1}");
d("\\redB", "\\textcolor{##ff8482}{#1}");
d("\\redC", "\\textcolor{##f9685d}{#1}");
d("\\redD", "\\textcolor{##e84d39}{#1}");
d("\\redE", "\\textcolor{##bc2612}{#1}");
d("\\maroonA", "\\textcolor{##ffbde0}{#1}");
d("\\maroonB", "\\textcolor{##ff92c6}{#1}");
d("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
d("\\maroonD", "\\textcolor{##ca337c}{#1}");
d("\\maroonE", "\\textcolor{##9e034e}{#1}");
d("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
d("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
d("\\purpleC", "\\textcolor{##aa87ff}{#1}");
d("\\purpleD", "\\textcolor{##7854ab}{#1}");
d("\\purpleE", "\\textcolor{##543b78}{#1}");
d("\\mintA", "\\textcolor{##f5f9e8}{#1}");
d("\\mintB", "\\textcolor{##edf2df}{#1}");
d("\\mintC", "\\textcolor{##e0e5cc}{#1}");
d("\\grayA", "\\textcolor{##f6f7f7}{#1}");
d("\\grayB", "\\textcolor{##f0f1f2}{#1}");
d("\\grayC", "\\textcolor{##e3e5e6}{#1}");
d("\\grayD", "\\textcolor{##d6d8da}{#1}");
d("\\grayE", "\\textcolor{##babec2}{#1}");
d("\\grayF", "\\textcolor{##888d93}{#1}");
d("\\grayG", "\\textcolor{##626569}{#1}");
d("\\grayH", "\\textcolor{##3b3e40}{#1}");
d("\\grayI", "\\textcolor{##21242c}{#1}");
d("\\kaBlue", "\\textcolor{##314453}{#1}");
d("\\kaGreen", "\\textcolor{##71B307}{#1}");
typeof document < "u" && document.compatMode !== "CSS1Compat" && typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype.");
function Ha() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let kt = Ha();
function wl(r) {
  kt = r;
}
const kl = /[&<>"']/, V1 = new RegExp(kl.source, "g"), Dl = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, W1 = new RegExp(Dl.source, "g"), Y1 = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Un = (r) => Y1[r];
function d0(r, e) {
  if (e) {
    if (kl.test(r))
      return r.replace(V1, Un);
  } else if (Dl.test(r))
    return r.replace(W1, Un);
  return r;
}
const j1 = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function X1(r) {
  return r.replace(j1, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const Z1 = /(^|[^\[])\^/g;
function ye(r, e) {
  let t = typeof r == "string" ? r : r.source;
  e = e || "";
  const a = {
    replace: (n, i) => {
      let l = typeof i == "string" ? i : i.source;
      return l = l.replace(Z1, "$1"), t = t.replace(n, l), a;
    },
    getRegex: () => new RegExp(t, e)
  };
  return a;
}
function Gn(r) {
  try {
    r = encodeURI(r).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return r;
}
const Jt = { exec: () => null };
function Vn(r, e) {
  const t = r.replace(/\|/g, (i, l, s) => {
    let o = !1, m = l;
    for (; --m >= 0 && s[m] === "\\"; )
      o = !o;
    return o ? "|" : " |";
  }), a = t.split(/ \|/);
  let n = 0;
  if (a[0].trim() || a.shift(), a.length > 0 && !a[a.length - 1].trim() && a.pop(), e)
    if (a.length > e)
      a.splice(e);
    else
      for (; a.length < e; )
        a.push("");
  for (; n < a.length; n++)
    a[n] = a[n].trim().replace(/\\\|/g, "|");
  return a;
}
function yr(r, e, t) {
  const a = r.length;
  if (a === 0)
    return "";
  let n = 0;
  for (; n < a; ) {
    const i = r.charAt(a - n - 1);
    if (i === e && !t)
      n++;
    else if (i !== e && t)
      n++;
    else
      break;
  }
  return r.slice(0, a - n);
}
function K1(r, e) {
  if (r.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let a = 0; a < r.length; a++)
    if (r[a] === "\\")
      a++;
    else if (r[a] === e[0])
      t++;
    else if (r[a] === e[1] && (t--, t < 0))
      return a;
  return -1;
}
function Wn(r, e, t, a) {
  const n = e.href, i = e.title ? d0(e.title) : null, l = r[1].replace(/\\([\[\]])/g, "$1");
  if (r[0].charAt(0) !== "!") {
    a.state.inLink = !0;
    const s = {
      type: "link",
      raw: t,
      href: n,
      title: i,
      text: l,
      tokens: a.inlineTokens(l)
    };
    return a.state.inLink = !1, s;
  }
  return {
    type: "image",
    raw: t,
    href: n,
    title: i,
    text: d0(l)
  };
}
function Q1(r, e) {
  const t = r.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const a = t[1];
  return e.split(`
`).map((n) => {
    const i = n.match(/^\s+/);
    if (i === null)
      return n;
    const [l] = i;
    return l.length >= a.length ? n.slice(a.length) : n;
  }).join(`
`);
}
class Br {
  // set by the lexer
  constructor(e) {
    _e(this, "options");
    _e(this, "rules");
    // set by the lexer
    _e(this, "lexer");
    this.options = e || kt;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const a = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? a : yr(a, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const a = t[0], n = Q1(a, t[3] || "");
      return {
        type: "code",
        raw: a,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: n
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let a = t[2].trim();
      if (/#$/.test(a)) {
        const n = yr(a, "#");
        (this.options.pedantic || !n || / $/.test(n)) && (a = n.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: a,
        tokens: this.lexer.inline(a)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let a = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      a = yr(a.replace(/^ *>[ \t]?/gm, ""), `
`);
      const n = this.lexer.state.top;
      this.lexer.state.top = !0;
      const i = this.lexer.blockTokens(a);
      return this.lexer.state.top = n, {
        type: "blockquote",
        raw: t[0],
        tokens: i,
        text: a
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let a = t[1].trim();
      const n = a.length > 1, i = {
        type: "list",
        raw: "",
        ordered: n,
        start: n ? +a.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      a = n ? `\\d{1,9}\\${a.slice(-1)}` : `\\${a}`, this.options.pedantic && (a = n ? a : "[*+-]");
      const l = new RegExp(`^( {0,3}${a})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let s = "", o = "", m = !1;
      for (; e; ) {
        let f = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        s = t[0], e = e.substring(s.length);
        let p = t[2].split(`
`, 1)[0].replace(/^\t+/, (S) => " ".repeat(3 * S.length)), g = e.split(`
`, 1)[0], w = 0;
        this.options.pedantic ? (w = 2, o = p.trimStart()) : (w = t[2].search(/[^ ]/), w = w > 4 ? 1 : w, o = p.slice(w), w += t[1].length);
        let F = !1;
        if (!p && /^ *$/.test(g) && (s += g + `
`, e = e.substring(g.length + 1), f = !0), !f) {
          const S = new RegExp(`^ {0,${Math.min(3, w - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), y = new RegExp(`^ {0,${Math.min(3, w - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), D = new RegExp(`^ {0,${Math.min(3, w - 1)}}(?:\`\`\`|~~~)`), _ = new RegExp(`^ {0,${Math.min(3, w - 1)}}#`);
          for (; e; ) {
            const C = e.split(`
`, 1)[0];
            if (g = C, this.options.pedantic && (g = g.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), D.test(g) || _.test(g) || S.test(g) || y.test(e))
              break;
            if (g.search(/[^ ]/) >= w || !g.trim())
              o += `
` + g.slice(w);
            else {
              if (F || p.search(/[^ ]/) >= 4 || D.test(p) || _.test(p) || y.test(p))
                break;
              o += `
` + g;
            }
            !F && !g.trim() && (F = !0), s += C + `
`, e = e.substring(C.length + 1), p = g.slice(w);
          }
        }
        i.loose || (m ? i.loose = !0 : /\n *\n *$/.test(s) && (m = !0));
        let E = null, k;
        this.options.gfm && (E = /^\[[ xX]\] /.exec(o), E && (k = E[0] !== "[ ] ", o = o.replace(/^\[[ xX]\] +/, ""))), i.items.push({
          type: "list_item",
          raw: s,
          task: !!E,
          checked: k,
          loose: !1,
          text: o,
          tokens: []
        }), i.raw += s;
      }
      i.items[i.items.length - 1].raw = s.trimEnd(), i.items[i.items.length - 1].text = o.trimEnd(), i.raw = i.raw.trimEnd();
      for (let f = 0; f < i.items.length; f++)
        if (this.lexer.state.top = !1, i.items[f].tokens = this.lexer.blockTokens(i.items[f].text, []), !i.loose) {
          const p = i.items[f].tokens.filter((w) => w.type === "space"), g = p.length > 0 && p.some((w) => /\n.*\n/.test(w.raw));
          i.loose = g;
        }
      if (i.loose)
        for (let f = 0; f < i.items.length; f++)
          i.items[f].loose = !0;
      return i;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const a = t[1].toLowerCase().replace(/\s+/g, " "), n = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", i = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: a,
        raw: t[0],
        href: n,
        title: i
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const a = Vn(t[1]), n = t[2].replace(/^\||\| *$/g, "").split("|"), i = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (a.length === n.length) {
      for (const s of n)
        /^ *-+: *$/.test(s) ? l.align.push("right") : /^ *:-+: *$/.test(s) ? l.align.push("center") : /^ *:-+ *$/.test(s) ? l.align.push("left") : l.align.push(null);
      for (const s of a)
        l.header.push({
          text: s,
          tokens: this.lexer.inline(s)
        });
      for (const s of i)
        l.rows.push(Vn(s, l.header.length).map((o) => ({
          text: o,
          tokens: this.lexer.inline(o)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const a = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: a,
        tokens: this.lexer.inline(a)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: d0(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const a = t[2].trim();
      if (!this.options.pedantic && /^</.test(a)) {
        if (!/>$/.test(a))
          return;
        const l = yr(a.slice(0, -1), "\\");
        if ((a.length - l.length) % 2 === 0)
          return;
      } else {
        const l = K1(t[2], "()");
        if (l > -1) {
          const o = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, o).trim(), t[3] = "";
        }
      }
      let n = t[2], i = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(n);
        l && (n = l[1], i = l[3]);
      } else
        i = t[3] ? t[3].slice(1, -1) : "";
      return n = n.trim(), /^</.test(n) && (this.options.pedantic && !/>$/.test(a) ? n = n.slice(1) : n = n.slice(1, -1)), Wn(t, {
        href: n && n.replace(this.rules.inline.anyPunctuation, "$1"),
        title: i && i.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let a;
    if ((a = this.rules.inline.reflink.exec(e)) || (a = this.rules.inline.nolink.exec(e))) {
      const n = (a[2] || a[1]).replace(/\s+/g, " "), i = t[n.toLowerCase()];
      if (!i) {
        const l = a[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return Wn(a, i, a[0], this.lexer);
    }
  }
  emStrong(e, t, a = "") {
    let n = this.rules.inline.emStrongLDelim.exec(e);
    if (!n || n[3] && a.match(/[\p{L}\p{N}]/u))
      return;
    if (!(n[1] || n[2] || "") || !a || this.rules.inline.punctuation.exec(a)) {
      const l = [...n[0]].length - 1;
      let s, o, m = l, f = 0;
      const p = n[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (p.lastIndex = 0, t = t.slice(-1 * e.length + l); (n = p.exec(t)) != null; ) {
        if (s = n[1] || n[2] || n[3] || n[4] || n[5] || n[6], !s)
          continue;
        if (o = [...s].length, n[3] || n[4]) {
          m += o;
          continue;
        } else if ((n[5] || n[6]) && l % 3 && !((l + o) % 3)) {
          f += o;
          continue;
        }
        if (m -= o, m > 0)
          continue;
        o = Math.min(o, o + m + f);
        const g = [...n[0]][0].length, w = e.slice(0, l + n.index + g + o);
        if (Math.min(l, o) % 2) {
          const E = w.slice(1, -1);
          return {
            type: "em",
            raw: w,
            text: E,
            tokens: this.lexer.inlineTokens(E)
          };
        }
        const F = w.slice(2, -2);
        return {
          type: "strong",
          raw: w,
          text: F,
          tokens: this.lexer.inlineTokens(F)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let a = t[2].replace(/\n/g, " ");
      const n = /[^ ]/.test(a), i = /^ /.test(a) && / $/.test(a);
      return n && i && (a = a.substring(1, a.length - 1)), a = d0(a, !0), {
        type: "codespan",
        raw: t[0],
        text: a
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let a, n;
      return t[2] === "@" ? (a = d0(t[1]), n = "mailto:" + a) : (a = d0(t[1]), n = a), {
        type: "link",
        raw: t[0],
        text: a,
        href: n,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  url(e) {
    var a;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let n, i;
      if (t[2] === "@")
        n = d0(t[0]), i = "mailto:" + n;
      else {
        let l;
        do
          l = t[0], t[0] = ((a = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : a[0]) ?? "";
        while (l !== t[0]);
        n = d0(t[0]), t[1] === "www." ? i = "http://" + t[0] : i = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: n,
        href: i,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let a;
      return this.lexer.state.inRawBlock ? a = t[0] : a = d0(t[0]), {
        type: "text",
        raw: t[0],
        text: a
      };
    }
  }
}
const J1 = /^(?: *(?:\n|$))+/, $1 = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, eu = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, nr = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, tu = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, xl = /(?:[*+-]|\d{1,9}[.)])/, Al = ye(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, xl).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Ua = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, ru = /^[^\n]+/, Ga = /(?!\s*\])(?:\\.|[^\[\]\\])+/, au = ye(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Ga).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), nu = ye(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, xl).getRegex(), Yr = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Va = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, iu = ye("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Va).replace("tag", Yr).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Sl = ye(Ua).replace("hr", nr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Yr).getRegex(), lu = ye(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Sl).getRegex(), Wa = {
  blockquote: lu,
  code: $1,
  def: au,
  fences: eu,
  heading: tu,
  hr: nr,
  html: iu,
  lheading: Al,
  list: nu,
  newline: J1,
  paragraph: Sl,
  table: Jt,
  text: ru
}, Yn = ye("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", nr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Yr).getRegex(), su = {
  ...Wa,
  table: Yn,
  paragraph: ye(Ua).replace("hr", nr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Yn).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Yr).getRegex()
}, uu = {
  ...Wa,
  html: ye(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Va).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Jt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: ye(Ua).replace("hr", nr).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Al).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Fl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, ou = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, _l = /^( {2,}|\\)\n(?!\s*$)/, cu = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, ir = "\\p{P}\\p{S}", hu = ye(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, ir).getRegex(), mu = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, fu = ye(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, ir).getRegex(), du = ye("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, ir).getRegex(), pu = ye("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, ir).getRegex(), gu = ye(/\\([punct])/, "gu").replace(/punct/g, ir).getRegex(), vu = ye(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), bu = ye(Va).replace("(?:-->|$)", "-->").getRegex(), yu = ye("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", bu).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), zr = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, wu = ye(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", zr).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), El = ye(/^!?\[(label)\]\[(ref)\]/).replace("label", zr).replace("ref", Ga).getRegex(), Tl = ye(/^!?\[(ref)\](?:\[\])?/).replace("ref", Ga).getRegex(), ku = ye("reflink|nolink(?!\\()", "g").replace("reflink", El).replace("nolink", Tl).getRegex(), Ya = {
  _backpedal: Jt,
  // only used for GFM url
  anyPunctuation: gu,
  autolink: vu,
  blockSkip: mu,
  br: _l,
  code: ou,
  del: Jt,
  emStrongLDelim: fu,
  emStrongRDelimAst: du,
  emStrongRDelimUnd: pu,
  escape: Fl,
  link: wu,
  nolink: Tl,
  punctuation: hu,
  reflink: El,
  reflinkSearch: ku,
  tag: yu,
  text: cu,
  url: Jt
}, Du = {
  ...Ya,
  link: ye(/^!?\[(label)\]\((.*?)\)/).replace("label", zr).getRegex(),
  reflink: ye(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", zr).getRegex()
}, ya = {
  ...Ya,
  escape: ye(Fl).replace("])", "~|])").getRegex(),
  url: ye(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, xu = {
  ...ya,
  br: ye(_l).replace("{2,}", "*").getRegex(),
  text: ye(ya.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, wr = {
  normal: Wa,
  gfm: su,
  pedantic: uu
}, Gt = {
  normal: Ya,
  gfm: ya,
  breaks: xu,
  pedantic: Du
};
class L0 {
  constructor(e) {
    _e(this, "tokens");
    _e(this, "options");
    _e(this, "state");
    _e(this, "tokenizer");
    _e(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || kt, this.options.tokenizer = this.options.tokenizer || new Br(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: wr.normal,
      inline: Gt.normal
    };
    this.options.pedantic ? (t.block = wr.pedantic, t.inline = Gt.pedantic) : this.options.gfm && (t.block = wr.gfm, this.options.breaks ? t.inline = Gt.breaks : t.inline = Gt.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: wr,
      inline: Gt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new L0(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new L0(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const a = this.inlineQueue[t];
      this.inlineTokens(a.src, a.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (s, o, m) => o + "    ".repeat(m.length));
    let a, n, i, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((s) => (a = s.call({ lexer: this }, e, t)) ? (e = e.substring(a.raw.length), t.push(a), !0) : !1))) {
        if (a = this.tokenizer.space(e)) {
          e = e.substring(a.raw.length), a.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(a);
          continue;
        }
        if (a = this.tokenizer.code(e)) {
          e = e.substring(a.raw.length), n = t[t.length - 1], n && (n.type === "paragraph" || n.type === "text") ? (n.raw += `
` + a.raw, n.text += `
` + a.text, this.inlineQueue[this.inlineQueue.length - 1].src = n.text) : t.push(a);
          continue;
        }
        if (a = this.tokenizer.fences(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.heading(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.hr(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.blockquote(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.list(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.html(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.def(e)) {
          e = e.substring(a.raw.length), n = t[t.length - 1], n && (n.type === "paragraph" || n.type === "text") ? (n.raw += `
` + a.raw, n.text += `
` + a.raw, this.inlineQueue[this.inlineQueue.length - 1].src = n.text) : this.tokens.links[a.tag] || (this.tokens.links[a.tag] = {
            href: a.href,
            title: a.title
          });
          continue;
        }
        if (a = this.tokenizer.table(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.lheading(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startBlock) {
          let s = 1 / 0;
          const o = e.slice(1);
          let m;
          this.options.extensions.startBlock.forEach((f) => {
            m = f.call({ lexer: this }, o), typeof m == "number" && m >= 0 && (s = Math.min(s, m));
          }), s < 1 / 0 && s >= 0 && (i = e.substring(0, s + 1));
        }
        if (this.state.top && (a = this.tokenizer.paragraph(i))) {
          n = t[t.length - 1], l && n.type === "paragraph" ? (n.raw += `
` + a.raw, n.text += `
` + a.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = n.text) : t.push(a), l = i.length !== e.length, e = e.substring(a.raw.length);
          continue;
        }
        if (a = this.tokenizer.text(e)) {
          e = e.substring(a.raw.length), n = t[t.length - 1], n && n.type === "text" ? (n.raw += `
` + a.raw, n.text += `
` + a.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = n.text) : t.push(a);
          continue;
        }
        if (e) {
          const s = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(s);
            break;
          } else
            throw new Error(s);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let a, n, i, l = e, s, o, m;
    if (this.tokens.links) {
      const f = Object.keys(this.tokens.links);
      if (f.length > 0)
        for (; (s = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          f.includes(s[0].slice(s[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (s = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (s = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, s.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (o || (m = ""), o = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((f) => (a = f.call({ lexer: this }, e, t)) ? (e = e.substring(a.raw.length), t.push(a), !0) : !1))) {
        if (a = this.tokenizer.escape(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.tag(e)) {
          e = e.substring(a.raw.length), n = t[t.length - 1], n && a.type === "text" && n.type === "text" ? (n.raw += a.raw, n.text += a.text) : t.push(a);
          continue;
        }
        if (a = this.tokenizer.link(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(a.raw.length), n = t[t.length - 1], n && a.type === "text" && n.type === "text" ? (n.raw += a.raw, n.text += a.text) : t.push(a);
          continue;
        }
        if (a = this.tokenizer.emStrong(e, l, m)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.codespan(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.br(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.del(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (a = this.tokenizer.autolink(e)) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (!this.state.inLink && (a = this.tokenizer.url(e))) {
          e = e.substring(a.raw.length), t.push(a);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startInline) {
          let f = 1 / 0;
          const p = e.slice(1);
          let g;
          this.options.extensions.startInline.forEach((w) => {
            g = w.call({ lexer: this }, p), typeof g == "number" && g >= 0 && (f = Math.min(f, g));
          }), f < 1 / 0 && f >= 0 && (i = e.substring(0, f + 1));
        }
        if (a = this.tokenizer.inlineText(i)) {
          e = e.substring(a.raw.length), a.raw.slice(-1) !== "_" && (m = a.raw.slice(-1)), o = !0, n = t[t.length - 1], n && n.type === "text" ? (n.raw += a.raw, n.text += a.text) : t.push(a);
          continue;
        }
        if (e) {
          const f = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(f);
            break;
          } else
            throw new Error(f);
        }
      }
    return t;
  }
}
class Rr {
  constructor(e) {
    _e(this, "options");
    this.options = e || kt;
  }
  code(e, t, a) {
    var i;
    const n = (i = (t || "").match(/^\S*/)) == null ? void 0 : i[0];
    return e = e.replace(/\n$/, "") + `
`, n ? '<pre><code class="language-' + d0(n) + '">' + (a ? e : d0(e, !0)) + `</code></pre>
` : "<pre><code>" + (a ? e : d0(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, a) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, a) {
    const n = t ? "ol" : "ul", i = t && a !== 1 ? ' start="' + a + '"' : "";
    return "<" + n + i + `>
` + e + "</" + n + `>
`;
  }
  listitem(e, t, a) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const a = t.header ? "th" : "td";
    return (t.align ? `<${a} align="${t.align}">` : `<${a}>`) + e + `</${a}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, a) {
    const n = Gn(e);
    if (n === null)
      return a;
    e = n;
    let i = '<a href="' + e + '"';
    return t && (i += ' title="' + t + '"'), i += ">" + a + "</a>", i;
  }
  image(e, t, a) {
    const n = Gn(e);
    if (n === null)
      return a;
    e = n;
    let i = `<img src="${e}" alt="${a}"`;
    return t && (i += ` title="${t}"`), i += ">", i;
  }
  text(e) {
    return e;
  }
}
class ja {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, a) {
    return "" + a;
  }
  image(e, t, a) {
    return "" + a;
  }
  br() {
    return "";
  }
}
class O0 {
  constructor(e) {
    _e(this, "options");
    _e(this, "renderer");
    _e(this, "textRenderer");
    this.options = e || kt, this.options.renderer = this.options.renderer || new Rr(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new ja();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new O0(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new O0(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let a = "";
    for (let n = 0; n < e.length; n++) {
      const i = e[n];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = i, s = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (s !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          a += s || "";
          continue;
        }
      }
      switch (i.type) {
        case "space":
          continue;
        case "hr": {
          a += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = i;
          a += this.renderer.heading(this.parseInline(l.tokens), l.depth, X1(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = i;
          a += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = i;
          let s = "", o = "";
          for (let f = 0; f < l.header.length; f++)
            o += this.renderer.tablecell(this.parseInline(l.header[f].tokens), { header: !0, align: l.align[f] });
          s += this.renderer.tablerow(o);
          let m = "";
          for (let f = 0; f < l.rows.length; f++) {
            const p = l.rows[f];
            o = "";
            for (let g = 0; g < p.length; g++)
              o += this.renderer.tablecell(this.parseInline(p[g].tokens), { header: !1, align: l.align[g] });
            m += this.renderer.tablerow(o);
          }
          a += this.renderer.table(s, m);
          continue;
        }
        case "blockquote": {
          const l = i, s = this.parse(l.tokens);
          a += this.renderer.blockquote(s);
          continue;
        }
        case "list": {
          const l = i, s = l.ordered, o = l.start, m = l.loose;
          let f = "";
          for (let p = 0; p < l.items.length; p++) {
            const g = l.items[p], w = g.checked, F = g.task;
            let E = "";
            if (g.task) {
              const k = this.renderer.checkbox(!!w);
              m ? g.tokens.length > 0 && g.tokens[0].type === "paragraph" ? (g.tokens[0].text = k + " " + g.tokens[0].text, g.tokens[0].tokens && g.tokens[0].tokens.length > 0 && g.tokens[0].tokens[0].type === "text" && (g.tokens[0].tokens[0].text = k + " " + g.tokens[0].tokens[0].text)) : g.tokens.unshift({
                type: "text",
                text: k + " "
              }) : E += k + " ";
            }
            E += this.parse(g.tokens, m), f += this.renderer.listitem(E, F, !!w);
          }
          a += this.renderer.list(f, s, o);
          continue;
        }
        case "html": {
          const l = i;
          a += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = i;
          a += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = i, s = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; n + 1 < e.length && e[n + 1].type === "text"; )
            l = e[++n], s += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          a += t ? this.renderer.paragraph(s) : s;
          continue;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return a;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let a = "";
    for (let n = 0; n < e.length; n++) {
      const i = e[n];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const l = this.options.extensions.renderers[i.type].call({ parser: this }, i);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type)) {
          a += l || "";
          continue;
        }
      }
      switch (i.type) {
        case "escape": {
          const l = i;
          a += t.text(l.text);
          break;
        }
        case "html": {
          const l = i;
          a += t.html(l.text);
          break;
        }
        case "link": {
          const l = i;
          a += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = i;
          a += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = i;
          a += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = i;
          a += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = i;
          a += t.codespan(l.text);
          break;
        }
        case "br": {
          a += t.br();
          break;
        }
        case "del": {
          const l = i;
          a += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = i;
          a += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return a;
  }
}
class $t {
  constructor(e) {
    _e(this, "options");
    this.options = e || kt;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
_e($t, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var yt, wa, Cl;
class Au {
  constructor(...e) {
    on(this, yt);
    _e(this, "defaults", Ha());
    _e(this, "options", this.setOptions);
    _e(this, "parse", mr(this, yt, wa).call(this, L0.lex, O0.parse));
    _e(this, "parseInline", mr(this, yt, wa).call(this, L0.lexInline, O0.parseInline));
    _e(this, "Parser", O0);
    _e(this, "Renderer", Rr);
    _e(this, "TextRenderer", ja);
    _e(this, "Lexer", L0);
    _e(this, "Tokenizer", Br);
    _e(this, "Hooks", $t);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var n, i;
    let a = [];
    for (const l of e)
      switch (a = a.concat(t.call(this, l)), l.type) {
        case "table": {
          const s = l;
          for (const o of s.header)
            a = a.concat(this.walkTokens(o.tokens, t));
          for (const o of s.rows)
            for (const m of o)
              a = a.concat(this.walkTokens(m.tokens, t));
          break;
        }
        case "list": {
          const s = l;
          a = a.concat(this.walkTokens(s.items, t));
          break;
        }
        default: {
          const s = l;
          (i = (n = this.defaults.extensions) == null ? void 0 : n.childTokens) != null && i[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((o) => {
            const m = s[o].flat(1 / 0);
            a = a.concat(this.walkTokens(m, t));
          }) : s.tokens && (a = a.concat(this.walkTokens(s.tokens, t)));
        }
      }
    return a;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((a) => {
      const n = { ...a };
      if (n.async = this.defaults.async || n.async || !1, a.extensions && (a.extensions.forEach((i) => {
        if (!i.name)
          throw new Error("extension name required");
        if ("renderer" in i) {
          const l = t.renderers[i.name];
          l ? t.renderers[i.name] = function(...s) {
            let o = i.renderer.apply(this, s);
            return o === !1 && (o = l.apply(this, s)), o;
          } : t.renderers[i.name] = i.renderer;
        }
        if ("tokenizer" in i) {
          if (!i.level || i.level !== "block" && i.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[i.level];
          l ? l.unshift(i.tokenizer) : t[i.level] = [i.tokenizer], i.start && (i.level === "block" ? t.startBlock ? t.startBlock.push(i.start) : t.startBlock = [i.start] : i.level === "inline" && (t.startInline ? t.startInline.push(i.start) : t.startInline = [i.start]));
        }
        "childTokens" in i && i.childTokens && (t.childTokens[i.name] = i.childTokens);
      }), n.extensions = t), a.renderer) {
        const i = this.defaults.renderer || new Rr(this.defaults);
        for (const l in a.renderer) {
          if (!(l in i))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const s = l, o = a.renderer[s], m = i[s];
          i[s] = (...f) => {
            let p = o.apply(i, f);
            return p === !1 && (p = m.apply(i, f)), p || "";
          };
        }
        n.renderer = i;
      }
      if (a.tokenizer) {
        const i = this.defaults.tokenizer || new Br(this.defaults);
        for (const l in a.tokenizer) {
          if (!(l in i))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const s = l, o = a.tokenizer[s], m = i[s];
          i[s] = (...f) => {
            let p = o.apply(i, f);
            return p === !1 && (p = m.apply(i, f)), p;
          };
        }
        n.tokenizer = i;
      }
      if (a.hooks) {
        const i = this.defaults.hooks || new $t();
        for (const l in a.hooks) {
          if (!(l in i))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const s = l, o = a.hooks[s], m = i[s];
          $t.passThroughHooks.has(l) ? i[s] = (f) => {
            if (this.defaults.async)
              return Promise.resolve(o.call(i, f)).then((g) => m.call(i, g));
            const p = o.call(i, f);
            return m.call(i, p);
          } : i[s] = (...f) => {
            let p = o.apply(i, f);
            return p === !1 && (p = m.apply(i, f)), p;
          };
        }
        n.hooks = i;
      }
      if (a.walkTokens) {
        const i = this.defaults.walkTokens, l = a.walkTokens;
        n.walkTokens = function(s) {
          let o = [];
          return o.push(l.call(this, s)), i && (o = o.concat(i.call(this, s))), o;
        };
      }
      this.defaults = { ...this.defaults, ...n };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return L0.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return O0.parse(e, t ?? this.defaults);
  }
}
yt = new WeakSet(), wa = function(e, t) {
  return (a, n) => {
    const i = { ...n }, l = { ...this.defaults, ...i };
    this.defaults.async === !0 && i.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const s = mr(this, yt, Cl).call(this, !!l.silent, !!l.async);
    if (typeof a > "u" || a === null)
      return s(new Error("marked(): input parameter is undefined or null"));
    if (typeof a != "string")
      return s(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(a) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(a) : a).then((o) => e(o, l)).then((o) => l.hooks ? l.hooks.processAllTokens(o) : o).then((o) => l.walkTokens ? Promise.all(this.walkTokens(o, l.walkTokens)).then(() => o) : o).then((o) => t(o, l)).then((o) => l.hooks ? l.hooks.postprocess(o) : o).catch(s);
    try {
      l.hooks && (a = l.hooks.preprocess(a));
      let o = e(a, l);
      l.hooks && (o = l.hooks.processAllTokens(o)), l.walkTokens && this.walkTokens(o, l.walkTokens);
      let m = t(o, l);
      return l.hooks && (m = l.hooks.postprocess(m)), m;
    } catch (o) {
      return s(o);
    }
  };
}, Cl = function(e, t) {
  return (a) => {
    if (a.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const n = "<p>An error occurred:</p><pre>" + d0(a.message + "", !0) + "</pre>";
      return t ? Promise.resolve(n) : n;
    }
    if (t)
      return Promise.reject(a);
    throw a;
  };
};
const vt = new Au();
function be(r, e) {
  return vt.parse(r, e);
}
be.options = be.setOptions = function(r) {
  return vt.setOptions(r), be.defaults = vt.defaults, wl(be.defaults), be;
};
be.getDefaults = Ha;
be.defaults = kt;
be.use = function(...r) {
  return vt.use(...r), be.defaults = vt.defaults, wl(be.defaults), be;
};
be.walkTokens = function(r, e) {
  return vt.walkTokens(r, e);
};
be.parseInline = vt.parseInline;
be.Parser = O0;
be.parser = O0.parse;
be.Renderer = Rr;
be.TextRenderer = ja;
be.Lexer = L0;
be.lexer = L0.lex;
be.Tokenizer = Br;
be.Hooks = $t;
be.parse = be;
be.options;
be.setOptions;
be.use;
be.walkTokens;
be.parseInline;
O0.parse;
L0.lex;
const Su = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Fu = Object.hasOwnProperty;
class Ml {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const a = this;
    let n = _u(e, t === !0);
    const i = n;
    for (; Fu.call(a.occurrences, n); )
      a.occurrences[i]++, n = i + "-" + a.occurrences[i];
    return a.occurrences[n] = 0, n;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function _u(r, e) {
  return typeof r != "string" ? "" : (e || (r = r.toLowerCase()), r.replace(Su, "").replace(/ /g, "-"));
}
new Ml();
var jn = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, Eu = { exports: {} };
(function(r) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(a) {
    var n = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, i = 0, l = {}, s = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: a.Prism && a.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: a.Prism && a.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function y(D) {
          return D instanceof o ? new o(D.type, y(D.content), D.alias) : Array.isArray(D) ? D.map(y) : D.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(y) {
          return Object.prototype.toString.call(y).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(y) {
          return y.__id || Object.defineProperty(y, "__id", { value: ++i }), y.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function y(D, _) {
          _ = _ || {};
          var C, M;
          switch (s.util.type(D)) {
            case "Object":
              if (M = s.util.objId(D), _[M])
                return _[M];
              C = /** @type {Record<string, any>} */
              {}, _[M] = C;
              for (var R in D)
                D.hasOwnProperty(R) && (C[R] = y(D[R], _));
              return (
                /** @type {any} */
                C
              );
            case "Array":
              return M = s.util.objId(D), _[M] ? _[M] : (C = [], _[M] = C, /** @type {Array} */
              /** @type {any} */
              D.forEach(function(U, I) {
                C[I] = y(U, _);
              }), /** @type {any} */
              C);
            default:
              return D;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(y) {
          for (; y; ) {
            var D = n.exec(y.className);
            if (D)
              return D[1].toLowerCase();
            y = y.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(y, D) {
          y.className = y.className.replace(RegExp(n, "gi"), ""), y.classList.add("language-" + D);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (C) {
            var y = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(C.stack) || [])[1];
            if (y) {
              var D = document.getElementsByTagName("script");
              for (var _ in D)
                if (D[_].src == y)
                  return D[_];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(y, D, _) {
          for (var C = "no-" + D; y; ) {
            var M = y.classList;
            if (M.contains(D))
              return !0;
            if (M.contains(C))
              return !1;
            y = y.parentElement;
          }
          return !!_;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(y, D) {
          var _ = s.util.clone(s.languages[y]);
          for (var C in D)
            _[C] = D[C];
          return _;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(y, D, _, C) {
          C = C || /** @type {any} */
          s.languages;
          var M = C[y], R = {};
          for (var U in M)
            if (M.hasOwnProperty(U)) {
              if (U == D)
                for (var I in _)
                  _.hasOwnProperty(I) && (R[I] = _[I]);
              _.hasOwnProperty(U) || (R[U] = M[U]);
            }
          var O = C[y];
          return C[y] = R, s.languages.DFS(s.languages, function(J, le) {
            le === O && J != y && (this[J] = R);
          }), R;
        },
        // Traverse a language definition with Depth First Search
        DFS: function y(D, _, C, M) {
          M = M || {};
          var R = s.util.objId;
          for (var U in D)
            if (D.hasOwnProperty(U)) {
              _.call(D, U, D[U], C || U);
              var I = D[U], O = s.util.type(I);
              O === "Object" && !M[R(I)] ? (M[R(I)] = !0, y(I, _, null, M)) : O === "Array" && !M[R(I)] && (M[R(I)] = !0, y(I, _, U, M));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(y, D) {
        s.highlightAllUnder(document, y, D);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(y, D, _) {
        var C = {
          callback: _,
          container: y,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        s.hooks.run("before-highlightall", C), C.elements = Array.prototype.slice.apply(C.container.querySelectorAll(C.selector)), s.hooks.run("before-all-elements-highlight", C);
        for (var M = 0, R; R = C.elements[M++]; )
          s.highlightElement(R, D === !0, C.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(y, D, _) {
        var C = s.util.getLanguage(y), M = s.languages[C];
        s.util.setLanguage(y, C);
        var R = y.parentElement;
        R && R.nodeName.toLowerCase() === "pre" && s.util.setLanguage(R, C);
        var U = y.textContent, I = {
          element: y,
          language: C,
          grammar: M,
          code: U
        };
        function O(le) {
          I.highlightedCode = le, s.hooks.run("before-insert", I), I.element.innerHTML = I.highlightedCode, s.hooks.run("after-highlight", I), s.hooks.run("complete", I), _ && _.call(I.element);
        }
        if (s.hooks.run("before-sanity-check", I), R = I.element.parentElement, R && R.nodeName.toLowerCase() === "pre" && !R.hasAttribute("tabindex") && R.setAttribute("tabindex", "0"), !I.code) {
          s.hooks.run("complete", I), _ && _.call(I.element);
          return;
        }
        if (s.hooks.run("before-highlight", I), !I.grammar) {
          O(s.util.encode(I.code));
          return;
        }
        if (D && a.Worker) {
          var J = new Worker(s.filename);
          J.onmessage = function(le) {
            O(le.data);
          }, J.postMessage(JSON.stringify({
            language: I.language,
            code: I.code,
            immediateClose: !0
          }));
        } else
          O(s.highlight(I.code, I.grammar, I.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(y, D, _) {
        var C = {
          code: y,
          grammar: D,
          language: _
        };
        if (s.hooks.run("before-tokenize", C), !C.grammar)
          throw new Error('The language "' + C.language + '" has no grammar.');
        return C.tokens = s.tokenize(C.code, C.grammar), s.hooks.run("after-tokenize", C), o.stringify(s.util.encode(C.tokens), C.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(y, D) {
        var _ = D.rest;
        if (_) {
          for (var C in _)
            D[C] = _[C];
          delete D.rest;
        }
        var M = new p();
        return g(M, M.head, y), f(y, M, D, M.head, 0), F(M);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(y, D) {
          var _ = s.hooks.all;
          _[y] = _[y] || [], _[y].push(D);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(y, D) {
          var _ = s.hooks.all[y];
          if (!(!_ || !_.length))
            for (var C = 0, M; M = _[C++]; )
              M(D);
        }
      },
      Token: o
    };
    a.Prism = s;
    function o(y, D, _, C) {
      this.type = y, this.content = D, this.alias = _, this.length = (C || "").length | 0;
    }
    o.stringify = function y(D, _) {
      if (typeof D == "string")
        return D;
      if (Array.isArray(D)) {
        var C = "";
        return D.forEach(function(O) {
          C += y(O, _);
        }), C;
      }
      var M = {
        type: D.type,
        content: y(D.content, _),
        tag: "span",
        classes: ["token", D.type],
        attributes: {},
        language: _
      }, R = D.alias;
      R && (Array.isArray(R) ? Array.prototype.push.apply(M.classes, R) : M.classes.push(R)), s.hooks.run("wrap", M);
      var U = "";
      for (var I in M.attributes)
        U += " " + I + '="' + (M.attributes[I] || "").replace(/"/g, "&quot;") + '"';
      return "<" + M.tag + ' class="' + M.classes.join(" ") + '"' + U + ">" + M.content + "</" + M.tag + ">";
    };
    function m(y, D, _, C) {
      y.lastIndex = D;
      var M = y.exec(_);
      if (M && C && M[1]) {
        var R = M[1].length;
        M.index += R, M[0] = M[0].slice(R);
      }
      return M;
    }
    function f(y, D, _, C, M, R) {
      for (var U in _)
        if (!(!_.hasOwnProperty(U) || !_[U])) {
          var I = _[U];
          I = Array.isArray(I) ? I : [I];
          for (var O = 0; O < I.length; ++O) {
            if (R && R.cause == U + "," + O)
              return;
            var J = I[O], le = J.inside, se = !!J.lookbehind, Te = !!J.greedy, Ue = J.alias;
            if (Te && !J.pattern.global) {
              var Ze = J.pattern.toString().match(/[imsuy]*$/)[0];
              J.pattern = RegExp(J.pattern.source, Ze + "g");
            }
            for (var a0 = J.pattern || J, ge = C.next, Le = M; ge !== D.tail && !(R && Le >= R.reach); Le += ge.value.length, ge = ge.next) {
              var ve = ge.value;
              if (D.length > y.length)
                return;
              if (!(ve instanceof o)) {
                var te = 1, me;
                if (Te) {
                  if (me = m(a0, Le, y, se), !me || me.index >= y.length)
                    break;
                  var Ge = me.index, $ = me.index + me[0].length, Me = Le;
                  for (Me += ge.value.length; Ge >= Me; )
                    ge = ge.next, Me += ge.value.length;
                  if (Me -= ge.value.length, Le = Me, ge.value instanceof o)
                    continue;
                  for (var re = ge; re !== D.tail && (Me < $ || typeof re.value == "string"); re = re.next)
                    te++, Me += re.value.length;
                  te--, ve = y.slice(Le, Me), me.index -= Le;
                } else if (me = m(a0, 0, ve, se), !me)
                  continue;
                var Ge = me.index, xe = me[0], Ke = ve.slice(0, Ge), ce = ve.slice(Ge + xe.length), Ve = Le + ve.length;
                R && Ve > R.reach && (R.reach = Ve);
                var c0 = ge.prev;
                Ke && (c0 = g(D, c0, Ke), Le += Ke.length), w(D, c0, te);
                var Re = new o(U, le ? s.tokenize(xe, le) : xe, Ue, xe);
                if (ge = g(D, c0, Re), ce && g(D, ge, ce), te > 1) {
                  var n0 = {
                    cause: U + "," + O,
                    reach: Ve
                  };
                  f(y, D, _, ge.prev, Le, n0), R && n0.reach > R.reach && (R.reach = n0.reach);
                }
              }
            }
          }
        }
    }
    function p() {
      var y = { value: null, prev: null, next: null }, D = { value: null, prev: y, next: null };
      y.next = D, this.head = y, this.tail = D, this.length = 0;
    }
    function g(y, D, _) {
      var C = D.next, M = { value: _, prev: D, next: C };
      return D.next = M, C.prev = M, y.length++, M;
    }
    function w(y, D, _) {
      for (var C = D.next, M = 0; M < _ && C !== y.tail; M++)
        C = C.next;
      D.next = C, C.prev = D, y.length -= M;
    }
    function F(y) {
      for (var D = [], _ = y.head.next; _ !== y.tail; )
        D.push(_.value), _ = _.next;
      return D;
    }
    if (!a.document)
      return a.addEventListener && (s.disableWorkerMessageHandler || a.addEventListener("message", function(y) {
        var D = JSON.parse(y.data), _ = D.language, C = D.code, M = D.immediateClose;
        a.postMessage(s.highlight(C, s.languages[_], _)), M && a.close();
      }, !1)), s;
    var E = s.util.currentScript();
    E && (s.filename = E.src, E.hasAttribute("data-manual") && (s.manual = !0));
    function k() {
      s.manual || s.highlightAll();
    }
    if (!s.manual) {
      var S = document.readyState;
      S === "loading" || S === "interactive" && E && E.defer ? document.addEventListener("DOMContentLoaded", k) : window.requestAnimationFrame ? window.requestAnimationFrame(k) : window.setTimeout(k, 16);
    }
    return s;
  }(e);
  r.exports && (r.exports = t), typeof jn < "u" && (jn.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(a) {
    a.type === "entity" && (a.attributes.title = a.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(n, i) {
      var l = {};
      l["language-" + i] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[i]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var s = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      s["language-" + i] = {
        pattern: /[\s\S]+/,
        inside: t.languages[i]
      };
      var o = {};
      o[n] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return n;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: s
      }, t.languages.insertBefore("markup", "cdata", o);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(a, n) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + a + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [n, "language-" + n],
                inside: t.languages[n]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(a) {
    var n = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    a.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + n.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + n.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + n.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + n.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: n,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, a.languages.css.atrule.inside.rest = a.languages.css;
    var i = a.languages.markup;
    i && (i.tag.addInlined("style", "css"), i.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var a = "Loading…", n = function(E, k) {
      return "✖ Error " + E + " while fetching file: " + k;
    }, i = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, s = "data-src-status", o = "loading", m = "loaded", f = "failed", p = "pre[data-src]:not([" + s + '="' + m + '"]):not([' + s + '="' + o + '"])';
    function g(E, k, S) {
      var y = new XMLHttpRequest();
      y.open("GET", E, !0), y.onreadystatechange = function() {
        y.readyState == 4 && (y.status < 400 && y.responseText ? k(y.responseText) : y.status >= 400 ? S(n(y.status, y.statusText)) : S(i));
      }, y.send(null);
    }
    function w(E) {
      var k = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(E || "");
      if (k) {
        var S = Number(k[1]), y = k[2], D = k[3];
        return y ? D ? [S, Number(D)] : [S, void 0] : [S, S];
      }
    }
    t.hooks.add("before-highlightall", function(E) {
      E.selector += ", " + p;
    }), t.hooks.add("before-sanity-check", function(E) {
      var k = (
        /** @type {HTMLPreElement} */
        E.element
      );
      if (k.matches(p)) {
        E.code = "", k.setAttribute(s, o);
        var S = k.appendChild(document.createElement("CODE"));
        S.textContent = a;
        var y = k.getAttribute("data-src"), D = E.language;
        if (D === "none") {
          var _ = (/\.(\w+)$/.exec(y) || [, "none"])[1];
          D = l[_] || _;
        }
        t.util.setLanguage(S, D), t.util.setLanguage(k, D);
        var C = t.plugins.autoloader;
        C && C.loadLanguages(D), g(
          y,
          function(M) {
            k.setAttribute(s, m);
            var R = w(k.getAttribute("data-range"));
            if (R) {
              var U = M.split(/\r\n?|\n/g), I = R[0], O = R[1] == null ? U.length : R[1];
              I < 0 && (I += U.length), I = Math.max(0, Math.min(I - 1, U.length)), O < 0 && (O += U.length), O = Math.max(0, Math.min(O, U.length)), M = U.slice(I, O).join(`
`), k.hasAttribute("data-start") || k.setAttribute("data-start", String(I + 1));
            }
            S.textContent = M, t.highlightElement(S);
          },
          function(M) {
            k.setAttribute(s, f), S.textContent = M;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(k) {
        for (var S = (k || document).querySelectorAll(p), y = 0, D; D = S[y++]; )
          t.highlightElement(D);
      }
    };
    var F = !1;
    t.fileHighlight = function() {
      F || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), F = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Eu);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(r) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  r.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, r.languages.tex = r.languages.latex, r.languages.context = r.languages.latex;
})(Prism);
(function(r) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, a = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  r.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: a
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: a
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: a.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: a.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = r.languages.bash;
  for (var n = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], i = a.variable[1].inside, l = 0; l < n.length; l++)
    i[n[l]] = r.languages.bash[n[l]];
  r.languages.sh = r.languages.bash, r.languages.shell = r.languages.bash;
})(Prism);
new Ml();
const Tu = (r) => {
  const e = {};
  for (let t = 0, a = r.length; t < a; t++) {
    const n = r[t];
    for (const i in n)
      e[i] ? e[i] = e[i].concat(n[i]) : e[i] = n[i];
  }
  return e;
}, Cu = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], Mu = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], Bu = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], zu = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], Ru = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Nu = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
[
  ...Cu,
  ...Mu.map((r) => `svg:${r}`),
  ...Bu.map((r) => `math:${r}`)
], Tu([
  Object.fromEntries(zu.map((r) => [r, ["*"]])),
  Object.fromEntries(Ru.map((r) => [r, ["svg:*"]])),
  Object.fromEntries(Nu.map((r) => [r, ["math:*"]]))
]);
const Iu = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Xn = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Iu.reduce(
  (r, { color: e, primary: t, secondary: a }) => ({
    ...r,
    [e]: {
      primary: Xn[e][t],
      secondary: Xn[e][a]
    }
  }),
  {}
);
/*! @license DOMPurify 3.1.7 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.1.7/LICENSE */
const {
  entries: Bl,
  setPrototypeOf: Zn,
  isFrozen: Lu,
  getPrototypeOf: Ou,
  getOwnPropertyDescriptor: qu
} = Object;
let {
  freeze: t0,
  seal: A0,
  create: zl
} = Object, {
  apply: ka,
  construct: Da
} = typeof Reflect < "u" && Reflect;
t0 || (t0 = function(e) {
  return e;
});
A0 || (A0 = function(e) {
  return e;
});
ka || (ka = function(e, t, a) {
  return e.apply(t, a);
});
Da || (Da = function(e, t) {
  return new e(...t);
});
const kr = g0(Array.prototype.forEach), Kn = g0(Array.prototype.pop), Vt = g0(Array.prototype.push), Fr = g0(String.prototype.toLowerCase), ia = g0(String.prototype.toString), Qn = g0(String.prototype.match), Wt = g0(String.prototype.replace), Pu = g0(String.prototype.indexOf), Hu = g0(String.prototype.trim), E0 = g0(Object.prototype.hasOwnProperty), $e = g0(RegExp.prototype.test), Yt = Uu(TypeError);
function g0(r) {
  return function(e) {
    for (var t = arguments.length, a = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
      a[n - 1] = arguments[n];
    return ka(r, e, a);
  };
}
function Uu(r) {
  return function() {
    for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++)
      t[a] = arguments[a];
    return Da(r, t);
  };
}
function ue(r, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Fr;
  Zn && Zn(r, null);
  let a = e.length;
  for (; a--; ) {
    let n = e[a];
    if (typeof n == "string") {
      const i = t(n);
      i !== n && (Lu(e) || (e[a] = i), n = i);
    }
    r[n] = !0;
  }
  return r;
}
function Gu(r) {
  for (let e = 0; e < r.length; e++)
    E0(r, e) || (r[e] = null);
  return r;
}
function pt(r) {
  const e = zl(null);
  for (const [t, a] of Bl(r))
    E0(r, t) && (Array.isArray(a) ? e[t] = Gu(a) : a && typeof a == "object" && a.constructor === Object ? e[t] = pt(a) : e[t] = a);
  return e;
}
function jt(r, e) {
  for (; r !== null; ) {
    const a = qu(r, e);
    if (a) {
      if (a.get)
        return g0(a.get);
      if (typeof a.value == "function")
        return g0(a.value);
    }
    r = Ou(r);
  }
  function t() {
    return null;
  }
  return t;
}
const Jn = t0(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), la = t0(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), sa = t0(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), Vu = t0(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), ua = t0(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Wu = t0(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), $n = t0(["#text"]), ei = t0(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), oa = t0(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), ti = t0(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Dr = t0(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), Yu = A0(/\{\{[\w\W]*|[\w\W]*\}\}/gm), ju = A0(/<%[\w\W]*|[\w\W]*%>/gm), Xu = A0(/\${[\w\W]*}/gm), Zu = A0(/^data-[\-\w.\u00B7-\uFFFF]/), Ku = A0(/^aria-[\-\w]+$/), Rl = A0(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Qu = A0(/^(?:\w+script|data):/i), Ju = A0(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Nl = A0(/^html$/i), $u = A0(/^[a-z][.\w]*(-[.\w]+)+$/i);
var ri = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  MUSTACHE_EXPR: Yu,
  ERB_EXPR: ju,
  TMPLIT_EXPR: Xu,
  DATA_ATTR: Zu,
  ARIA_ATTR: Ku,
  IS_ALLOWED_URI: Rl,
  IS_SCRIPT_OR_DATA: Qu,
  ATTR_WHITESPACE: Ju,
  DOCTYPE_NAME: Nl,
  CUSTOM_ELEMENT: $u
});
const Xt = {
  element: 1,
  attribute: 2,
  text: 3,
  cdataSection: 4,
  entityReference: 5,
  // Deprecated
  entityNode: 6,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9,
  documentType: 10,
  documentFragment: 11,
  notation: 12
  // Deprecated
}, eo = function() {
  return typeof window > "u" ? null : window;
}, to = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let a = null;
  const n = "data-tt-policy-suffix";
  t && t.hasAttribute(n) && (a = t.getAttribute(n));
  const i = "dompurify" + (a ? "#" + a : "");
  try {
    return e.createPolicy(i, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + i + " could not be created."), null;
  }
};
function Il() {
  let r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : eo();
  const e = (V) => Il(V);
  if (e.version = "3.1.7", e.removed = [], !r || !r.document || r.document.nodeType !== Xt.document)
    return e.isSupported = !1, e;
  let {
    document: t
  } = r;
  const a = t, n = a.currentScript, {
    DocumentFragment: i,
    HTMLTemplateElement: l,
    Node: s,
    Element: o,
    NodeFilter: m,
    NamedNodeMap: f = r.NamedNodeMap || r.MozNamedAttrMap,
    HTMLFormElement: p,
    DOMParser: g,
    trustedTypes: w
  } = r, F = o.prototype, E = jt(F, "cloneNode"), k = jt(F, "remove"), S = jt(F, "nextSibling"), y = jt(F, "childNodes"), D = jt(F, "parentNode");
  if (typeof l == "function") {
    const V = t.createElement("template");
    V.content && V.content.ownerDocument && (t = V.content.ownerDocument);
  }
  let _, C = "";
  const {
    implementation: M,
    createNodeIterator: R,
    createDocumentFragment: U,
    getElementsByTagName: I
  } = t, {
    importNode: O
  } = a;
  let J = {};
  e.isSupported = typeof Bl == "function" && typeof D == "function" && M && M.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: le,
    ERB_EXPR: se,
    TMPLIT_EXPR: Te,
    DATA_ATTR: Ue,
    ARIA_ATTR: Ze,
    IS_SCRIPT_OR_DATA: a0,
    ATTR_WHITESPACE: ge,
    CUSTOM_ELEMENT: Le
  } = ri;
  let {
    IS_ALLOWED_URI: ve
  } = ri, te = null;
  const me = ue({}, [...Jn, ...la, ...sa, ...ua, ...$n]);
  let $ = null;
  const Me = ue({}, [...ei, ...oa, ...ti, ...Dr]);
  let re = Object.seal(zl(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Ge = null, xe = null, Ke = !0, ce = !0, Ve = !1, c0 = !0, Re = !1, n0 = !0, Pe = !1, F0 = !1, h0 = !1, i0 = !1, m0 = !1, f0 = !1, qt = !0, xt = !1;
  const lr = "user-content-";
  let At = !0, mt = !1, J0 = {}, $0 = null;
  const sr = ue({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let ur = null;
  const or = ue({}, ["audio", "video", "img", "source", "image", "track"]);
  let Pt = null;
  const cr = ue({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), St = "http://www.w3.org/1998/Math/MathML", Ft = "http://www.w3.org/2000/svg", _0 = "http://www.w3.org/1999/xhtml";
  let et = _0, Ht = !1, B = null;
  const K = ue({}, [St, Ft, _0], ia);
  let ee = null;
  const oe = ["application/xhtml+xml", "text/html"], pe = "text/html";
  let ne = null, Ne = null;
  const _t = t.createElement("form"), z0 = function(A) {
    return A instanceof RegExp || A instanceof Function;
  }, V0 = function() {
    let A = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Ne && Ne === A)) {
      if ((!A || typeof A != "object") && (A = {}), A = pt(A), ee = // eslint-disable-next-line unicorn/prefer-includes
      oe.indexOf(A.PARSER_MEDIA_TYPE) === -1 ? pe : A.PARSER_MEDIA_TYPE, ne = ee === "application/xhtml+xml" ? ia : Fr, te = E0(A, "ALLOWED_TAGS") ? ue({}, A.ALLOWED_TAGS, ne) : me, $ = E0(A, "ALLOWED_ATTR") ? ue({}, A.ALLOWED_ATTR, ne) : Me, B = E0(A, "ALLOWED_NAMESPACES") ? ue({}, A.ALLOWED_NAMESPACES, ia) : K, Pt = E0(A, "ADD_URI_SAFE_ATTR") ? ue(
        pt(cr),
        // eslint-disable-line indent
        A.ADD_URI_SAFE_ATTR,
        // eslint-disable-line indent
        ne
        // eslint-disable-line indent
      ) : cr, ur = E0(A, "ADD_DATA_URI_TAGS") ? ue(
        pt(or),
        // eslint-disable-line indent
        A.ADD_DATA_URI_TAGS,
        // eslint-disable-line indent
        ne
        // eslint-disable-line indent
      ) : or, $0 = E0(A, "FORBID_CONTENTS") ? ue({}, A.FORBID_CONTENTS, ne) : sr, Ge = E0(A, "FORBID_TAGS") ? ue({}, A.FORBID_TAGS, ne) : {}, xe = E0(A, "FORBID_ATTR") ? ue({}, A.FORBID_ATTR, ne) : {}, J0 = E0(A, "USE_PROFILES") ? A.USE_PROFILES : !1, Ke = A.ALLOW_ARIA_ATTR !== !1, ce = A.ALLOW_DATA_ATTR !== !1, Ve = A.ALLOW_UNKNOWN_PROTOCOLS || !1, c0 = A.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Re = A.SAFE_FOR_TEMPLATES || !1, n0 = A.SAFE_FOR_XML !== !1, Pe = A.WHOLE_DOCUMENT || !1, i0 = A.RETURN_DOM || !1, m0 = A.RETURN_DOM_FRAGMENT || !1, f0 = A.RETURN_TRUSTED_TYPE || !1, h0 = A.FORCE_BODY || !1, qt = A.SANITIZE_DOM !== !1, xt = A.SANITIZE_NAMED_PROPS || !1, At = A.KEEP_CONTENT !== !1, mt = A.IN_PLACE || !1, ve = A.ALLOWED_URI_REGEXP || Rl, et = A.NAMESPACE || _0, re = A.CUSTOM_ELEMENT_HANDLING || {}, A.CUSTOM_ELEMENT_HANDLING && z0(A.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (re.tagNameCheck = A.CUSTOM_ELEMENT_HANDLING.tagNameCheck), A.CUSTOM_ELEMENT_HANDLING && z0(A.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (re.attributeNameCheck = A.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), A.CUSTOM_ELEMENT_HANDLING && typeof A.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (re.allowCustomizedBuiltInElements = A.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), Re && (ce = !1), m0 && (i0 = !0), J0 && (te = ue({}, $n), $ = [], J0.html === !0 && (ue(te, Jn), ue($, ei)), J0.svg === !0 && (ue(te, la), ue($, oa), ue($, Dr)), J0.svgFilters === !0 && (ue(te, sa), ue($, oa), ue($, Dr)), J0.mathMl === !0 && (ue(te, ua), ue($, ti), ue($, Dr))), A.ADD_TAGS && (te === me && (te = pt(te)), ue(te, A.ADD_TAGS, ne)), A.ADD_ATTR && ($ === Me && ($ = pt($)), ue($, A.ADD_ATTR, ne)), A.ADD_URI_SAFE_ATTR && ue(Pt, A.ADD_URI_SAFE_ATTR, ne), A.FORBID_CONTENTS && ($0 === sr && ($0 = pt($0)), ue($0, A.FORBID_CONTENTS, ne)), At && (te["#text"] = !0), Pe && ue(te, ["html", "head", "body"]), te.table && (ue(te, ["tbody"]), delete Ge.tbody), A.TRUSTED_TYPES_POLICY) {
        if (typeof A.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Yt('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof A.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Yt('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        _ = A.TRUSTED_TYPES_POLICY, C = _.createHTML("");
      } else
        _ === void 0 && (_ = to(w, n)), _ !== null && typeof C == "string" && (C = _.createHTML(""));
      t0 && t0(A), Ne = A;
    }
  }, y0 = ue({}, ["mi", "mo", "mn", "ms", "mtext"]), Et = ue({}, ["annotation-xml"]), ql = ue({}, ["title", "style", "font", "a", "script"]), Za = ue({}, [...la, ...sa, ...Vu]), Ka = ue({}, [...ua, ...Wu]), Pl = function(A) {
    let L = D(A);
    (!L || !L.tagName) && (L = {
      namespaceURI: et,
      tagName: "template"
    });
    const G = Fr(A.tagName), Ae = Fr(L.tagName);
    return B[A.namespaceURI] ? A.namespaceURI === Ft ? L.namespaceURI === _0 ? G === "svg" : L.namespaceURI === St ? G === "svg" && (Ae === "annotation-xml" || y0[Ae]) : !!Za[G] : A.namespaceURI === St ? L.namespaceURI === _0 ? G === "math" : L.namespaceURI === Ft ? G === "math" && Et[Ae] : !!Ka[G] : A.namespaceURI === _0 ? L.namespaceURI === Ft && !Et[Ae] || L.namespaceURI === St && !y0[Ae] ? !1 : !Ka[G] && (ql[G] || !Za[G]) : !!(ee === "application/xhtml+xml" && B[A.namespaceURI]) : !1;
  }, R0 = function(A) {
    Vt(e.removed, {
      element: A
    });
    try {
      D(A).removeChild(A);
    } catch {
      k(A);
    }
  }, hr = function(A, L) {
    try {
      Vt(e.removed, {
        attribute: L.getAttributeNode(A),
        from: L
      });
    } catch {
      Vt(e.removed, {
        attribute: null,
        from: L
      });
    }
    if (L.removeAttribute(A), A === "is" && !$[A])
      if (i0 || m0)
        try {
          R0(L);
        } catch {
        }
      else
        try {
          L.setAttribute(A, "");
        } catch {
        }
  }, Qa = function(A) {
    let L = null, G = null;
    if (h0)
      A = "<remove></remove>" + A;
    else {
      const We = Qn(A, /^[\r\n\t ]+/);
      G = We && We[0];
    }
    ee === "application/xhtml+xml" && et === _0 && (A = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + A + "</body></html>");
    const Ae = _ ? _.createHTML(A) : A;
    if (et === _0)
      try {
        L = new g().parseFromString(Ae, ee);
      } catch {
      }
    if (!L || !L.documentElement) {
      L = M.createDocument(et, "template", null);
      try {
        L.documentElement.innerHTML = Ht ? C : Ae;
      } catch {
      }
    }
    const Xe = L.body || L.documentElement;
    return A && G && Xe.insertBefore(t.createTextNode(G), Xe.childNodes[0] || null), et === _0 ? I.call(L, Pe ? "html" : "body")[0] : Pe ? L.documentElement : Xe;
  }, Ja = function(A) {
    return R.call(
      A.ownerDocument || A,
      A,
      // eslint-disable-next-line no-bitwise
      m.SHOW_ELEMENT | m.SHOW_COMMENT | m.SHOW_TEXT | m.SHOW_PROCESSING_INSTRUCTION | m.SHOW_CDATA_SECTION,
      null
    );
  }, $a = function(A) {
    return A instanceof p && (typeof A.nodeName != "string" || typeof A.textContent != "string" || typeof A.removeChild != "function" || !(A.attributes instanceof f) || typeof A.removeAttribute != "function" || typeof A.setAttribute != "function" || typeof A.namespaceURI != "string" || typeof A.insertBefore != "function" || typeof A.hasChildNodes != "function");
  }, en = function(A) {
    return typeof s == "function" && A instanceof s;
  }, W0 = function(A, L, G) {
    J[A] && kr(J[A], (Ae) => {
      Ae.call(e, L, G, Ne);
    });
  }, tn = function(A) {
    let L = null;
    if (W0("beforeSanitizeElements", A, null), $a(A))
      return R0(A), !0;
    const G = ne(A.nodeName);
    if (W0("uponSanitizeElement", A, {
      tagName: G,
      allowedTags: te
    }), A.hasChildNodes() && !en(A.firstElementChild) && $e(/<[/\w]/g, A.innerHTML) && $e(/<[/\w]/g, A.textContent) || A.nodeType === Xt.progressingInstruction || n0 && A.nodeType === Xt.comment && $e(/<[/\w]/g, A.data))
      return R0(A), !0;
    if (!te[G] || Ge[G]) {
      if (!Ge[G] && an(G) && (re.tagNameCheck instanceof RegExp && $e(re.tagNameCheck, G) || re.tagNameCheck instanceof Function && re.tagNameCheck(G)))
        return !1;
      if (At && !$0[G]) {
        const Ae = D(A) || A.parentNode, Xe = y(A) || A.childNodes;
        if (Xe && Ae) {
          const We = Xe.length;
          for (let l0 = We - 1; l0 >= 0; --l0) {
            const N0 = E(Xe[l0], !0);
            N0.__removalCount = (A.__removalCount || 0) + 1, Ae.insertBefore(N0, S(A));
          }
        }
      }
      return R0(A), !0;
    }
    return A instanceof o && !Pl(A) || (G === "noscript" || G === "noembed" || G === "noframes") && $e(/<\/no(script|embed|frames)/i, A.innerHTML) ? (R0(A), !0) : (Re && A.nodeType === Xt.text && (L = A.textContent, kr([le, se, Te], (Ae) => {
      L = Wt(L, Ae, " ");
    }), A.textContent !== L && (Vt(e.removed, {
      element: A.cloneNode()
    }), A.textContent = L)), W0("afterSanitizeElements", A, null), !1);
  }, rn = function(A, L, G) {
    if (qt && (L === "id" || L === "name") && (G in t || G in _t))
      return !1;
    if (!(ce && !xe[L] && $e(Ue, L))) {
      if (!(Ke && $e(Ze, L))) {
        if (!$[L] || xe[L]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(an(A) && (re.tagNameCheck instanceof RegExp && $e(re.tagNameCheck, A) || re.tagNameCheck instanceof Function && re.tagNameCheck(A)) && (re.attributeNameCheck instanceof RegExp && $e(re.attributeNameCheck, L) || re.attributeNameCheck instanceof Function && re.attributeNameCheck(L)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            L === "is" && re.allowCustomizedBuiltInElements && (re.tagNameCheck instanceof RegExp && $e(re.tagNameCheck, G) || re.tagNameCheck instanceof Function && re.tagNameCheck(G)))
          ) return !1;
        } else if (!Pt[L]) {
          if (!$e(ve, Wt(G, ge, ""))) {
            if (!((L === "src" || L === "xlink:href" || L === "href") && A !== "script" && Pu(G, "data:") === 0 && ur[A])) {
              if (!(Ve && !$e(a0, Wt(G, ge, "")))) {
                if (G)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, an = function(A) {
    return A !== "annotation-xml" && Qn(A, Le);
  }, nn = function(A) {
    W0("beforeSanitizeAttributes", A, null);
    const {
      attributes: L
    } = A;
    if (!L)
      return;
    const G = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: $
    };
    let Ae = L.length;
    for (; Ae--; ) {
      const Xe = L[Ae], {
        name: We,
        namespaceURI: l0,
        value: N0
      } = Xe, Ut = ne(We);
      let Qe = We === "value" ? N0 : Hu(N0);
      if (G.attrName = Ut, G.attrValue = Qe, G.keepAttr = !0, G.forceKeepAttr = void 0, W0("uponSanitizeAttribute", A, G), Qe = G.attrValue, G.forceKeepAttr || (hr(We, A), !G.keepAttr))
        continue;
      if (!c0 && $e(/\/>/i, Qe)) {
        hr(We, A);
        continue;
      }
      Re && kr([le, se, Te], (sn) => {
        Qe = Wt(Qe, sn, " ");
      });
      const ln = ne(A.nodeName);
      if (rn(ln, Ut, Qe)) {
        if (xt && (Ut === "id" || Ut === "name") && (hr(We, A), Qe = lr + Qe), n0 && $e(/((--!?|])>)|<\/(style|title)/i, Qe)) {
          hr(We, A);
          continue;
        }
        if (_ && typeof w == "object" && typeof w.getAttributeType == "function" && !l0)
          switch (w.getAttributeType(ln, Ut)) {
            case "TrustedHTML": {
              Qe = _.createHTML(Qe);
              break;
            }
            case "TrustedScriptURL": {
              Qe = _.createScriptURL(Qe);
              break;
            }
          }
        try {
          l0 ? A.setAttributeNS(l0, We, Qe) : A.setAttribute(We, Qe), $a(A) ? R0(A) : Kn(e.removed);
        } catch {
        }
      }
    }
    W0("afterSanitizeAttributes", A, null);
  }, Hl = function V(A) {
    let L = null;
    const G = Ja(A);
    for (W0("beforeSanitizeShadowDOM", A, null); L = G.nextNode(); )
      W0("uponSanitizeShadowNode", L, null), !tn(L) && (L.content instanceof i && V(L.content), nn(L));
    W0("afterSanitizeShadowDOM", A, null);
  };
  return e.sanitize = function(V) {
    let A = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, L = null, G = null, Ae = null, Xe = null;
    if (Ht = !V, Ht && (V = "<!-->"), typeof V != "string" && !en(V))
      if (typeof V.toString == "function") {
        if (V = V.toString(), typeof V != "string")
          throw Yt("dirty is not a string, aborting");
      } else
        throw Yt("toString is not a function");
    if (!e.isSupported)
      return V;
    if (F0 || V0(A), e.removed = [], typeof V == "string" && (mt = !1), mt) {
      if (V.nodeName) {
        const N0 = ne(V.nodeName);
        if (!te[N0] || Ge[N0])
          throw Yt("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (V instanceof s)
      L = Qa("<!---->"), G = L.ownerDocument.importNode(V, !0), G.nodeType === Xt.element && G.nodeName === "BODY" || G.nodeName === "HTML" ? L = G : L.appendChild(G);
    else {
      if (!i0 && !Re && !Pe && // eslint-disable-next-line unicorn/prefer-includes
      V.indexOf("<") === -1)
        return _ && f0 ? _.createHTML(V) : V;
      if (L = Qa(V), !L)
        return i0 ? null : f0 ? C : "";
    }
    L && h0 && R0(L.firstChild);
    const We = Ja(mt ? V : L);
    for (; Ae = We.nextNode(); )
      tn(Ae) || (Ae.content instanceof i && Hl(Ae.content), nn(Ae));
    if (mt)
      return V;
    if (i0) {
      if (m0)
        for (Xe = U.call(L.ownerDocument); L.firstChild; )
          Xe.appendChild(L.firstChild);
      else
        Xe = L;
      return ($.shadowroot || $.shadowrootmode) && (Xe = O.call(a, Xe, !0)), Xe;
    }
    let l0 = Pe ? L.outerHTML : L.innerHTML;
    return Pe && te["!doctype"] && L.ownerDocument && L.ownerDocument.doctype && L.ownerDocument.doctype.name && $e(Nl, L.ownerDocument.doctype.name) && (l0 = "<!DOCTYPE " + L.ownerDocument.doctype.name + `>
` + l0), Re && kr([le, se, Te], (N0) => {
      l0 = Wt(l0, N0, " ");
    }), _ && f0 ? _.createHTML(l0) : l0;
  }, e.setConfig = function() {
    let V = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    V0(V), F0 = !0;
  }, e.clearConfig = function() {
    Ne = null, F0 = !1;
  }, e.isValidAttribute = function(V, A, L) {
    Ne || V0({});
    const G = ne(V), Ae = ne(A);
    return rn(G, Ae, L);
  }, e.addHook = function(V, A) {
    typeof A == "function" && (J[V] = J[V] || [], Vt(J[V], A));
  }, e.removeHook = function(V) {
    if (J[V])
      return Kn(J[V]);
  }, e.removeHooks = function(V) {
    J[V] && (J[V] = []);
  }, e.removeAllHooks = function() {
    J = {};
  }, e;
}
Il();
const {
  SvelteComponent: ro,
  add_iframe_resize_listener: ao,
  add_render_callback: no,
  append_hydration: io,
  attr: lo,
  binding_callbacks: so,
  children: uo,
  claim_element: oo,
  claim_text: co,
  detach: ai,
  element: ho,
  init: mo,
  insert_hydration: fo,
  noop: ni,
  safe_not_equal: po,
  set_data: go,
  text: vo,
  toggle_class: Ct
} = window.__gradio__svelte__internal, { onMount: bo } = window.__gradio__svelte__internal;
function yo(r) {
  let e, t = (
    /*value*/
    (r[0] ? (
      /*value*/
      r[0]
    ) : "") + ""
  ), a, n;
  return {
    c() {
      e = ho("div"), a = vo(t), this.h();
    },
    l(i) {
      e = oo(i, "DIV", { class: !0 });
      var l = uo(e);
      a = co(l, t), l.forEach(ai), this.h();
    },
    h() {
      lo(e, "class", "svelte-84cxb8"), no(() => (
        /*div_elementresize_handler*/
        r[5].call(e)
      )), Ct(
        e,
        "table",
        /*type*/
        r[1] === "table"
      ), Ct(
        e,
        "gallery",
        /*type*/
        r[1] === "gallery"
      ), Ct(
        e,
        "selected",
        /*selected*/
        r[2]
      );
    },
    m(i, l) {
      fo(i, e, l), io(e, a), n = ao(
        e,
        /*div_elementresize_handler*/
        r[5].bind(e)
      ), r[6](e);
    },
    p(i, [l]) {
      l & /*value*/
      1 && t !== (t = /*value*/
      (i[0] ? (
        /*value*/
        i[0]
      ) : "") + "") && go(a, t), l & /*type*/
      2 && Ct(
        e,
        "table",
        /*type*/
        i[1] === "table"
      ), l & /*type*/
      2 && Ct(
        e,
        "gallery",
        /*type*/
        i[1] === "gallery"
      ), l & /*selected*/
      4 && Ct(
        e,
        "selected",
        /*selected*/
        i[2]
      );
    },
    i: ni,
    o: ni,
    d(i) {
      i && ai(e), n(), r[6](null);
    }
  };
}
function wo(r, e, t) {
  let { value: a } = e, { type: n } = e, { selected: i = !1 } = e, l, s;
  function o(p, g) {
    !p || !g || (s.style.setProperty("--local-text-width", `${g < 150 ? g : 200}px`), t(4, s.style.whiteSpace = "unset", s));
  }
  bo(() => {
    o(s, l);
  });
  function m() {
    l = this.clientWidth, t(3, l);
  }
  function f(p) {
    so[p ? "unshift" : "push"](() => {
      s = p, t(4, s);
    });
  }
  return r.$$set = (p) => {
    "value" in p && t(0, a = p.value), "type" in p && t(1, n = p.type), "selected" in p && t(2, i = p.selected);
  }, [a, n, i, l, s, m, f];
}
class ko extends ro {
  constructor(e) {
    super(), mo(this, e, wo, yo, po, { value: 0, type: 1, selected: 2 });
  }
}
const {
  SvelteComponent: Do,
  append_hydration: xr,
  attr: Mt,
  children: ii,
  claim_element: ca,
  claim_space: xo,
  claim_text: Ao,
  detach: ha,
  element: ma,
  init: So,
  insert_hydration: Fo,
  listen: fa,
  noop: li,
  run_all: _o,
  safe_not_equal: Eo,
  set_data: To,
  space: Co,
  text: Mo,
  toggle_class: si
} = window.__gradio__svelte__internal, { createEventDispatcher: Bo } = window.__gradio__svelte__internal;
function zo(r) {
  let e, t, a, n, i, l, s;
  return {
    c() {
      e = ma("label"), t = ma("input"), a = Co(), n = ma("span"), i = Mo(
        /*label*/
        r[1]
      ), this.h();
    },
    l(o) {
      e = ca(o, "LABEL", { class: !0 });
      var m = ii(e);
      t = ca(m, "INPUT", {
        type: !0,
        name: !0,
        "data-testid": !0,
        class: !0
      }), a = xo(m), n = ca(m, "SPAN", { class: !0 });
      var f = ii(n);
      i = Ao(
        f,
        /*label*/
        r[1]
      ), f.forEach(ha), m.forEach(ha), this.h();
    },
    h() {
      t.disabled = /*disabled*/
      r[2], Mt(t, "type", "checkbox"), Mt(t, "name", "test"), Mt(t, "data-testid", "checkbox"), Mt(t, "class", "svelte-15y2hcz"), Mt(n, "class", "ml-2 svelte-15y2hcz"), Mt(e, "class", "svelte-15y2hcz"), si(
        e,
        "disabled",
        /*disabled*/
        r[2]
      );
    },
    m(o, m) {
      Fo(o, e, m), xr(e, t), t.checked = /*value*/
      r[0], xr(e, a), xr(e, n), xr(n, i), l || (s = [
        fa(
          t,
          "change",
          /*input_change_handler*/
          r[6]
        ),
        fa(
          t,
          "keydown",
          /*handle_enter*/
          r[3]
        ),
        fa(
          t,
          "input",
          /*handle_input*/
          r[4]
        )
      ], l = !0);
    },
    p(o, [m]) {
      m & /*disabled*/
      4 && (t.disabled = /*disabled*/
      o[2]), m & /*value*/
      1 && (t.checked = /*value*/
      o[0]), m & /*label*/
      2 && To(
        i,
        /*label*/
        o[1]
      ), m & /*disabled*/
      4 && si(
        e,
        "disabled",
        /*disabled*/
        o[2]
      );
    },
    i: li,
    o: li,
    d(o) {
      o && ha(e), l = !1, _o(s);
    }
  };
}
function Ro(r, e, t) {
  let a;
  var n = this && this.__awaiter || function(g, w, F, E) {
    function k(S) {
      return S instanceof F ? S : new F(function(y) {
        y(S);
      });
    }
    return new (F || (F = Promise))(function(S, y) {
      function D(M) {
        try {
          C(E.next(M));
        } catch (R) {
          y(R);
        }
      }
      function _(M) {
        try {
          C(E.throw(M));
        } catch (R) {
          y(R);
        }
      }
      function C(M) {
        M.done ? S(M.value) : k(M.value).then(D, _);
      }
      C((E = E.apply(g, w || [])).next());
    });
  };
  let { value: i = !1 } = e, { label: l = "Checkbox" } = e, { interactive: s } = e;
  const o = Bo();
  function m(g) {
    return n(this, void 0, void 0, function* () {
      g.key === "Enter" && (t(0, i = !i), o("select", {
        index: 0,
        value: g.currentTarget.checked,
        selected: g.currentTarget.checked
      }));
    });
  }
  function f(g) {
    return n(this, void 0, void 0, function* () {
      t(0, i = g.currentTarget.checked), o("select", {
        index: 0,
        value: g.currentTarget.checked,
        selected: g.currentTarget.checked
      });
    });
  }
  function p() {
    i = this.checked, t(0, i);
  }
  return r.$$set = (g) => {
    "value" in g && t(0, i = g.value), "label" in g && t(1, l = g.label), "interactive" in g && t(5, s = g.interactive);
  }, r.$$.update = () => {
    r.$$.dirty & /*value*/
    1 && o("change", i), r.$$.dirty & /*interactive*/
    32 && t(2, a = !s);
  }, [
    i,
    l,
    a,
    m,
    f,
    s,
    p
  ];
}
class Ll extends Do {
  constructor(e) {
    super(), So(this, e, Ro, zo, Eo, { value: 0, label: 1, interactive: 5 });
  }
}
const {
  HtmlTagHydration: No,
  SvelteComponent: Io,
  append_hydration: fe,
  assign: Nr,
  attr: ie,
  check_outros: M0,
  children: Ee,
  claim_component: Ot,
  claim_element: we,
  claim_html_tag: Lo,
  claim_space: u0,
  claim_svg_element: ui,
  claim_text: ct,
  construct_svelte_component: Ir,
  create_component: lt,
  destroy_component: st,
  destroy_each: Nt,
  detach: X,
  element: ke,
  empty: S0,
  ensure_array_like: D0,
  get_spread_object: Lr,
  get_spread_update: Or,
  get_svelte_dataset: Xa,
  group_outros: B0,
  init: Oo,
  insert_hydration: Se,
  listen: q0,
  mount_component: ut,
  noop: bt,
  run_all: Ol,
  safe_not_equal: qo,
  set_data: Dt,
  set_style: p0,
  space: o0,
  src_url_equal: oi,
  stop_propagation: Po,
  svg_element: ci,
  text: ht,
  toggle_class: hi,
  transition_in: de,
  transition_out: Fe
} = window.__gradio__svelte__internal;
function mi(r, e, t) {
  const a = r.slice();
  return a[72] = e[t], a;
}
function fi(r, e, t) {
  const a = r.slice();
  return a[75] = e[t], a[77] = t, a;
}
function di(r, e, t) {
  const a = r.slice();
  return a[79] = e[t], a;
}
function pi(r, e, t) {
  const a = r.slice();
  return a[82] = e[t], a[84] = t, a;
}
function gi(r, e, t) {
  const a = r.slice();
  return a[85] = e[t], a[87] = t, a;
}
function vi(r, e, t) {
  const a = r.slice();
  return a[75] = e[t], a[77] = t, a;
}
function Ho(r) {
  let e, t, a, n, i, l, s, o, m = D0(
    /*column_headers*/
    r[8]
  ), f = [];
  for (let k = 0; k < m.length; k += 1)
    f[k] = yi(gi(r, m, k));
  const p = (k) => Fe(f[k], 1, 1, () => {
    f[k] = null;
  });
  let g = (
    /*menu_choices*/
    r[21].length > 0 && wi()
  ), w = D0(
    /*selected_samples*/
    r[28]
  ), F = [];
  for (let k = 0; k < w.length; k += 1)
    F[k] = Si(fi(r, w, k));
  const E = (k) => Fe(F[k], 1, 1, () => {
    F[k] = null;
  });
  return {
    c() {
      e = ke("div"), t = ke("table"), a = ke("thead"), n = ke("tr");
      for (let k = 0; k < f.length; k += 1)
        f[k].c();
      i = o0(), g && g.c(), l = o0(), s = ke("tbody");
      for (let k = 0; k < F.length; k += 1)
        F[k].c();
      this.h();
    },
    l(k) {
      e = we(k, "DIV", { class: !0 });
      var S = Ee(e);
      t = we(S, "TABLE", { tabindex: !0, role: !0 });
      var y = Ee(t);
      a = we(y, "THEAD", {});
      var D = Ee(a);
      n = we(D, "TR", { class: !0 });
      var _ = Ee(n);
      for (let M = 0; M < f.length; M += 1)
        f[M].l(_);
      i = u0(_), g && g.l(_), _.forEach(X), D.forEach(X), l = u0(y), s = we(y, "TBODY", {});
      var C = Ee(s);
      for (let M = 0; M < F.length; M += 1)
        F[M].l(C);
      C.forEach(X), y.forEach(X), S.forEach(X), this.h();
    },
    h() {
      ie(n, "class", "tr-head"), ie(t, "tabindex", "0"), ie(t, "role", "grid"), ie(e, "class", "table-wrap");
    },
    m(k, S) {
      Se(k, e, S), fe(e, t), fe(t, a), fe(a, n);
      for (let y = 0; y < f.length; y += 1)
        f[y] && f[y].m(n, null);
      fe(n, i), g && g.m(n, null), fe(t, l), fe(t, s);
      for (let y = 0; y < F.length; y += 1)
        F[y] && F[y].m(s, null);
      o = !0;
    },
    p(k, S) {
      if (S[0] & /*column_widths, header_aligns, headerChecked, column_headers, components, sort_order, sort_column, header_sort, manual_sort*/
      1098909067 | S[1] & /*handleHeaderCheckbox, handleSort*/
      3072) {
        m = D0(
          /*column_headers*/
          k[8]
        );
        let y;
        for (y = 0; y < m.length; y += 1) {
          const D = gi(k, m, y);
          f[y] ? (f[y].p(D, S), de(f[y], 1)) : (f[y] = yi(D), f[y].c(), de(f[y], 1), f[y].m(n, i));
        }
        for (B0(), y = m.length; y < f.length; y += 1)
          p(y);
        M0();
      }
      if (/*menu_choices*/
      k[21].length > 0 ? g || (g = wi(), g.c(), g.m(n, null)) : g && (g.d(1), g = null), S[0] & /*menu_choices, menu_choices_style, menu_icon, selected_samples, data_aligns, components, page, samples_per_page, column_headers, external_index, gradio, component_props, root*/
      376636188 | S[1] & /*handle_mouseenter, handle_mouseleave, component_meta, handle_menu_click, active_menu, default_menu_icon, isProcessingBatchSelection, isRowSelected, handleCheckboxChange, samples_dir, current_hover*/
      13295) {
        w = D0(
          /*selected_samples*/
          k[28]
        );
        let y;
        for (y = 0; y < w.length; y += 1) {
          const D = fi(k, w, y);
          F[y] ? (F[y].p(D, S), de(F[y], 1)) : (F[y] = Si(D), F[y].c(), de(F[y], 1), F[y].m(s, null));
        }
        for (B0(), y = w.length; y < F.length; y += 1)
          E(y);
        M0();
      }
    },
    i(k) {
      if (!o) {
        for (let S = 0; S < m.length; S += 1)
          de(f[S]);
        for (let S = 0; S < w.length; S += 1)
          de(F[S]);
        o = !0;
      }
    },
    o(k) {
      f = f.filter(Boolean);
      for (let S = 0; S < f.length; S += 1)
        Fe(f[S]);
      F = F.filter(Boolean);
      for (let S = 0; S < F.length; S += 1)
        Fe(F[S]);
      o = !1;
    },
    d(k) {
      k && X(e), Nt(f, k), g && g.d(), Nt(F, k);
    }
  };
}
function Uo(r) {
  let e, t, a = D0(
    /*selected_samples*/
    r[28]
  ), n = [];
  for (let l = 0; l < a.length; l += 1)
    n[l] = _i(vi(r, a, l));
  const i = (l) => Fe(n[l], 1, 1, () => {
    n[l] = null;
  });
  return {
    c() {
      e = ke("div");
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      this.h();
    },
    l(l) {
      e = we(l, "DIV", { class: !0 });
      var s = Ee(e);
      for (let o = 0; o < n.length; o += 1)
        n[o].l(s);
      s.forEach(X), this.h();
    },
    h() {
      ie(e, "class", "gallery");
    },
    m(l, s) {
      Se(l, e, s);
      for (let o = 0; o < n.length; o += 1)
        n[o] && n[o].m(e, null);
      t = !0;
    },
    p(l, s) {
      if (s[0] & /*page, samples_per_page, selected_samples, gradio, value, sample_labels, component_props, root, component_map, components*/
      369330232 | s[1] & /*handle_mouseenter, handle_mouseleave, current_hover, component_meta, samples_dir*/
      906) {
        a = D0(
          /*selected_samples*/
          l[28]
        );
        let o;
        for (o = 0; o < a.length; o += 1) {
          const m = vi(l, a, o);
          n[o] ? (n[o].p(m, s), de(n[o], 1)) : (n[o] = _i(m), n[o].c(), de(n[o], 1), n[o].m(e, null));
        }
        for (B0(), o = a.length; o < n.length; o += 1)
          i(o);
        M0();
      }
    },
    i(l) {
      if (!t) {
        for (let s = 0; s < a.length; s += 1)
          de(n[s]);
        t = !0;
      }
    },
    o(l) {
      n = n.filter(Boolean);
      for (let s = 0; s < n.length; s += 1)
        Fe(n[s]);
      t = !1;
    },
    d(l) {
      l && X(e), Nt(n, l);
    }
  };
}
function Go(r) {
  let e = (
    /*header*/
    r[85] + ""
  ), t;
  return {
    c() {
      t = ht(e);
    },
    l(a) {
      t = ct(a, e);
    },
    m(a, n) {
      Se(a, t, n);
    },
    p(a, n) {
      n[0] & /*column_headers*/
      256 && e !== (e = /*header*/
      a[85] + "") && Dt(t, e);
    },
    i: bt,
    o: bt,
    d(a) {
      a && X(t);
    }
  };
}
function Vo(r) {
  let e, t, a = (
    /*header*/
    r[85] + ""
  ), n, i, l, s, o = (
    /*sort_column*/
    r[0] === /*index*/
    r[87] && /*components*/
    r[3][
      /*index*/
      r[87]
    ] !== "checkbox" && bi(r)
  );
  function m() {
    return (
      /*click_handler_1*/
      r[58](
        /*index*/
        r[87]
      )
    );
  }
  return {
    c() {
      e = ke("button"), t = ke("span"), n = ht(a), i = o0(), o && o.c(), this.h();
    },
    l(f) {
      e = we(f, "BUTTON", { style: !0, class: !0 });
      var p = Ee(e);
      t = we(p, "SPAN", { class: !0 });
      var g = Ee(t);
      n = ct(g, a), g.forEach(X), i = u0(p), o && o.l(p), p.forEach(X), this.h();
    },
    h() {
      ie(t, "class", "header-text"), p0(
        e,
        "justify-content",
        /*header_aligns*/
        r[10][
          /*index*/
          r[87]
        ]
      ), ie(e, "class", "sort-button");
    },
    m(f, p) {
      Se(f, e, p), fe(e, t), fe(t, n), fe(e, i), o && o.m(e, null), l || (s = q0(e, "click", m), l = !0);
    },
    p(f, p) {
      r = f, p[0] & /*column_headers*/
      256 && a !== (a = /*header*/
      r[85] + "") && Dt(n, a), /*sort_column*/
      r[0] === /*index*/
      r[87] && /*components*/
      r[3][
        /*index*/
        r[87]
      ] !== "checkbox" ? o ? o.p(r, p) : (o = bi(r), o.c(), o.m(e, null)) : o && (o.d(1), o = null), p[0] & /*header_aligns*/
      1024 && p0(
        e,
        "justify-content",
        /*header_aligns*/
        r[10][
          /*index*/
          r[87]
        ]
      );
    },
    i: bt,
    o: bt,
    d(f) {
      f && X(e), o && o.d(), l = !1, s();
    }
  };
}
function Wo(r) {
  let e, t, a = (
    /*header*/
    r[85] + ""
  ), n, i, l, s, o;
  return s = new Ll({
    props: {
      value: (
        /*headerChecked*/
        r[30]
      ),
      label: "",
      interactive: !0
    }
  }), s.$on(
    "change",
    /*change_handler*/
    r[57]
  ), {
    c() {
      e = ke("p"), t = ke("span"), n = ht(a), i = o0(), l = ke("span"), lt(s.$$.fragment), this.h();
    },
    l(m) {
      e = we(m, "P", { style: !0, class: !0 });
      var f = Ee(e);
      t = we(f, "SPAN", { class: !0 });
      var p = Ee(t);
      n = ct(p, a), p.forEach(X), i = u0(f), l = we(f, "SPAN", { class: !0, "aria-hidden": !0 });
      var g = Ee(l);
      Ot(s.$$.fragment, g), g.forEach(X), f.forEach(X), this.h();
    },
    h() {
      ie(t, "class", "header-text"), ie(l, "class", "check-head"), ie(l, "aria-hidden", "false"), p0(
        e,
        "justify-content",
        /*header_aligns*/
        r[10][
          /*index*/
          r[87]
        ]
      ), ie(e, "class", "sort-button checkbox-header");
    },
    m(m, f) {
      Se(m, e, f), fe(e, t), fe(t, n), fe(e, i), fe(e, l), ut(s, l, null), o = !0;
    },
    p(m, f) {
      (!o || f[0] & /*column_headers*/
      256) && a !== (a = /*header*/
      m[85] + "") && Dt(n, a);
      const p = {};
      f[0] & /*headerChecked*/
      1073741824 && (p.value = /*headerChecked*/
      m[30]), s.$set(p), (!o || f[0] & /*header_aligns*/
      1024) && p0(
        e,
        "justify-content",
        /*header_aligns*/
        m[10][
          /*index*/
          m[87]
        ]
      );
    },
    i(m) {
      o || (de(s.$$.fragment, m), o = !0);
    },
    o(m) {
      Fe(s.$$.fragment, m), o = !1;
    },
    d(m) {
      m && X(e), st(s);
    }
  };
}
function bi(r) {
  let e, t = (
    /*sort_order*/
    r[1] === "ascending" ? "▲" : "▼"
  ), a;
  return {
    c() {
      e = ke("span"), a = ht(t), this.h();
    },
    l(n) {
      e = we(n, "SPAN", { class: !0, "aria-hidden": !0 });
      var i = Ee(e);
      a = ct(i, t), i.forEach(X), this.h();
    },
    h() {
      ie(e, "class", "sort-icon"), ie(e, "aria-hidden", "true");
    },
    m(n, i) {
      Se(n, e, i), fe(e, a);
    },
    p(n, i) {
      i[0] & /*sort_order*/
      2 && t !== (t = /*sort_order*/
      n[1] === "ascending" ? "▲" : "▼") && Dt(a, t);
    },
    d(n) {
      n && X(e);
    }
  };
}
function yi(r) {
  let e, t, a, n;
  const i = [Wo, Vo, Go], l = [];
  function s(o, m) {
    return (
      /*components*/
      o[3][
        /*index*/
        o[87]
      ] === "checkbox" ? 0 : (
        /*header_sort*/
        o[23] || /*manual_sort*/
        o[24] ? 1 : 2
      )
    );
  }
  return t = s(r), a = l[t] = i[t](r), {
    c() {
      e = ke("th"), a.c(), this.h();
    },
    l(o) {
      e = we(o, "TH", { style: !0 });
      var m = Ee(e);
      a.l(m), m.forEach(X), this.h();
    },
    h() {
      p0(
        e,
        "width",
        /*column_widths*/
        r[7][
          /*index*/
          r[87]
        ]
      );
    },
    m(o, m) {
      Se(o, e, m), l[t].m(e, null), n = !0;
    },
    p(o, m) {
      let f = t;
      t = s(o), t === f ? l[t].p(o, m) : (B0(), Fe(l[f], 1, 1, () => {
        l[f] = null;
      }), M0(), a = l[t], a ? a.p(o, m) : (a = l[t] = i[t](o), a.c()), de(a, 1), a.m(e, null)), (!n || m[0] & /*column_widths*/
      128) && p0(
        e,
        "width",
        /*column_widths*/
        o[7][
          /*index*/
          o[87]
        ]
      );
    },
    i(o) {
      n || (de(a), n = !0);
    },
    o(o) {
      Fe(a), n = !1;
    },
    d(o) {
      o && X(e), l[t].d();
    }
  };
}
function wi(r) {
  let e, t = "Actions";
  return {
    c() {
      e = ke("th"), e.textContent = t, this.h();
    },
    l(a) {
      e = we(a, "TH", { style: !0, "data-svelte-h": !0 }), Xa(e) !== "svelte-1alb1t5" && (e.textContent = t), this.h();
    },
    h() {
      p0(e, "width", "0%}");
    },
    m(a, n) {
      Se(a, e, n);
    },
    d(a) {
      a && X(e);
    }
  };
}
function Yo(r) {
  let e, t = (
    /*cell*/
    r[82] + ""
  ), a;
  return {
    c() {
      e = new No(!1), a = S0(), this.h();
    },
    l(n) {
      e = Lo(n, !1), a = S0(), this.h();
    },
    h() {
      e.a = a;
    },
    m(n, i) {
      e.m(t, n, i), Se(n, a, i);
    },
    p(n, i) {
      i[0] & /*selected_samples*/
      268435456 && t !== (t = /*cell*/
      n[82] + "") && e.p(t);
    },
    i: bt,
    o: bt,
    d(n) {
      n && (X(a), e.d());
    }
  };
}
function jo(r) {
  let e, t;
  function a(...n) {
    return (
      /*change_handler_1*/
      r[59](
        /*sample_row*/
        r[75],
        /*i*/
        r[77],
        /*j*/
        r[84],
        ...n
      )
    );
  }
  return e = new Ll({
    props: {
      value: (
        /*isRowSelected*/
        r[37](
          /*sample_row*/
          r[75],
          /*i*/
          r[77] + /*page*/
          r[26] * /*samples_per_page*/
          r[17]
        )
      ),
      label: "",
      interactive: !0
    }
  }), e.$on("change", a), {
    c() {
      lt(e.$$.fragment);
    },
    l(n) {
      Ot(e.$$.fragment, n);
    },
    m(n, i) {
      ut(e, n, i), t = !0;
    },
    p(n, i) {
      r = n;
      const l = {};
      i[0] & /*selected_samples, page, samples_per_page*/
      335675392 && (l.value = /*isRowSelected*/
      r[37](
        /*sample_row*/
        r[75],
        /*i*/
        r[77] + /*page*/
        r[26] * /*samples_per_page*/
        r[17]
      )), e.$set(l);
    },
    i(n) {
      t || (de(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Fe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      st(e, n);
    }
  };
}
function Xo(r) {
  let e, t, a;
  const n = [
    /*component_props*/
    r[4][
      /*j*/
      r[84]
    ] || {},
    { value: (
      /*cell*/
      r[82]
    ) },
    { samples_dir: (
      /*samples_dir*/
      r[38]
    ) },
    { type: "table" },
    {
      selected: (
        /*current_hover*/
        r[32] === /*i*/
        r[77]
      )
    },
    { index: (
      /*i*/
      r[77]
    ) },
    { root: (
      /*root*/
      r[16]
    ) }
  ];
  var i = (
    /*component_meta*/
    r[34][
      /*i*/
      r[77]
    ][
      /*j*/
      r[84]
    ].component
  );
  function l(s, o) {
    let m = {};
    for (let f = 0; f < n.length; f += 1)
      m = Nr(m, n[f]);
    return o !== void 0 && o[0] & /*component_props, selected_samples, root*/
    268501008 | o[1] & /*samples_dir, current_hover*/
    130 && (m = Nr(m, Or(n, [
      o[0] & /*component_props*/
      16 && Lr(
        /*component_props*/
        s[4][
          /*j*/
          s[84]
        ] || {}
      ),
      o[0] & /*selected_samples*/
      268435456 && { value: (
        /*cell*/
        s[82]
      ) },
      o[1] & /*samples_dir*/
      128 && { samples_dir: (
        /*samples_dir*/
        s[38]
      ) },
      n[3],
      o[1] & /*current_hover*/
      2 && {
        selected: (
          /*current_hover*/
          s[32] === /*i*/
          s[77]
        )
      },
      n[5],
      o[0] & /*root*/
      65536 && { root: (
        /*root*/
        s[16]
      ) }
    ]))), { props: m };
  }
  return i && (e = Ir(i, l(r))), {
    c() {
      e && lt(e.$$.fragment), t = S0();
    },
    l(s) {
      e && Ot(e.$$.fragment, s), t = S0();
    },
    m(s, o) {
      e && ut(e, s, o), Se(s, t, o), a = !0;
    },
    p(s, o) {
      if (o[1] & /*component_meta*/
      8 && i !== (i = /*component_meta*/
      s[34][
        /*i*/
        s[77]
      ][
        /*j*/
        s[84]
      ].component)) {
        if (e) {
          B0();
          const m = e;
          Fe(m.$$.fragment, 1, 0, () => {
            st(m, 1);
          }), M0();
        }
        i ? (e = Ir(i, l(s, o)), lt(e.$$.fragment), de(e.$$.fragment, 1), ut(e, t.parentNode, t)) : e = null;
      } else if (i) {
        const m = o[0] & /*component_props, selected_samples, root*/
        268501008 | o[1] & /*samples_dir, current_hover*/
        130 ? Or(n, [
          o[0] & /*component_props*/
          16 && Lr(
            /*component_props*/
            s[4][
              /*j*/
              s[84]
            ] || {}
          ),
          o[0] & /*selected_samples*/
          268435456 && { value: (
            /*cell*/
            s[82]
          ) },
          o[1] & /*samples_dir*/
          128 && { samples_dir: (
            /*samples_dir*/
            s[38]
          ) },
          n[3],
          o[1] & /*current_hover*/
          2 && {
            selected: (
              /*current_hover*/
              s[32] === /*i*/
              s[77]
            )
          },
          n[5],
          o[0] & /*root*/
          65536 && { root: (
            /*root*/
            s[16]
          ) }
        ]) : {};
        e.$set(m);
      }
    },
    i(s) {
      a || (e && de(e.$$.fragment, s), a = !0);
    },
    o(s) {
      e && Fe(e.$$.fragment, s), a = !1;
    },
    d(s) {
      s && X(t), e && st(e, s);
    }
  };
}
function ki(r) {
  let e, t, a, n, i, l, s;
  const o = [Xo, jo, Yo], m = [];
  function f(g, w) {
    var F;
    return (
      /*component_meta*/
      g[34][
        /*i*/
        g[77]
      ] && /*component_meta*/
      ((F = g[34][
        /*i*/
        g[77]
      ][
        /*j*/
        g[84]
      ]) != null && F.component) ? 0 : (
        /*components*/
        g[3][
          /*j*/
          g[84]
        ] === "checkbox" ? 1 : 2
      )
    );
  }
  t = f(r), a = m[t] = o[t](r);
  function p() {
    return (
      /*click_handler_2*/
      r[60](
        /*i*/
        r[77],
        /*sample_row*/
        r[75],
        /*j*/
        r[84],
        /*cell*/
        r[82]
      )
    );
  }
  return {
    c() {
      e = ke("td"), a.c(), this.h();
    },
    l(g) {
      e = we(g, "TD", { style: !0, class: !0 });
      var w = Ee(e);
      a.l(w), w.forEach(X), this.h();
    },
    h() {
      p0(
        e,
        "justify-items",
        /*data_aligns*/
        r[9][
          /*j*/
          r[84]
        ]
      ), p0(
        e,
        "text-align",
        /*data_aligns*/
        r[9][
          /*j*/
          r[84]
        ]
      ), ie(e, "class", n = /*components*/
      r[3][
        /*j*/
        r[84]
      ] || "");
    },
    m(g, w) {
      Se(g, e, w), m[t].m(e, null), i = !0, l || (s = q0(e, "click", p), l = !0);
    },
    p(g, w) {
      r = g;
      let F = t;
      t = f(r), t === F ? m[t].p(r, w) : (B0(), Fe(m[F], 1, 1, () => {
        m[F] = null;
      }), M0(), a = m[t], a ? a.p(r, w) : (a = m[t] = o[t](r), a.c()), de(a, 1), a.m(e, null)), (!i || w[0] & /*data_aligns*/
      512) && p0(
        e,
        "justify-items",
        /*data_aligns*/
        r[9][
          /*j*/
          r[84]
        ]
      ), (!i || w[0] & /*data_aligns*/
      512) && p0(
        e,
        "text-align",
        /*data_aligns*/
        r[9][
          /*j*/
          r[84]
        ]
      ), (!i || w[0] & /*components*/
      8 && n !== (n = /*components*/
      r[3][
        /*j*/
        r[84]
      ] || "")) && ie(e, "class", n);
    },
    i(g) {
      i || (de(a), i = !0);
    },
    o(g) {
      Fe(a), i = !1;
    },
    d(g) {
      g && X(e), m[t].d(), l = !1, s();
    }
  };
}
function Di(r) {
  let e, t, a, n, i, l, s;
  function o() {
    return (
      /*click_handler_3*/
      r[61](
        /*i*/
        r[77]
      )
    );
  }
  let m = (
    /*active_menu*/
    r[33] === /*i*/
    r[77] && xi(r)
  );
  return {
    c() {
      e = ke("td"), t = ke("button"), a = ke("img"), i = o0(), m && m.c(), this.h();
    },
    l(f) {
      e = we(f, "TD", { class: !0 });
      var p = Ee(e);
      t = we(p, "BUTTON", { class: !0 });
      var g = Ee(t);
      a = we(g, "IMG", {
        src: !0,
        alt: !0,
        class: !0,
        style: !0
      }), g.forEach(X), i = u0(p), m && m.l(p), p.forEach(X), this.h();
    },
    h() {
      oi(a.src, n = /*menu_icon*/
      r[20] ? (
        /*menu_icon*/
        r[20]
      ) : (
        /*default_menu_icon*/
        r[36]
      )) || ie(a, "src", n), ie(a, "alt", "Menu"), ie(a, "class", "menu-icon"), p0(
        a,
        "transform",
        /*menu_icon*/
        r[20] ? "none" : "rotate(90deg)"
      ), ie(t, "class", "menu-button"), ie(e, "class", "menu-cell");
    },
    m(f, p) {
      Se(f, e, p), fe(e, t), fe(t, a), fe(e, i), m && m.m(e, null), l || (s = q0(t, "click", Po(o)), l = !0);
    },
    p(f, p) {
      r = f, p[0] & /*menu_icon*/
      1048576 | p[1] & /*default_menu_icon*/
      32 && !oi(a.src, n = /*menu_icon*/
      r[20] ? (
        /*menu_icon*/
        r[20]
      ) : (
        /*default_menu_icon*/
        r[36]
      )) && ie(a, "src", n), p[0] & /*menu_icon*/
      1048576 && p0(
        a,
        "transform",
        /*menu_icon*/
        r[20] ? "none" : "rotate(90deg)"
      ), /*active_menu*/
      r[33] === /*i*/
      r[77] ? m ? m.p(r, p) : (m = xi(r), m.c(), m.m(e, null)) : m && (m.d(1), m = null);
    },
    d(f) {
      f && X(e), m && m.d(), l = !1, s();
    }
  };
}
function xi(r) {
  let e, t, a = D0(
    /*menu_choices*/
    r[21]
  ), n = [];
  for (let i = 0; i < a.length; i += 1)
    n[i] = Ai(di(r, a, i));
  return {
    c() {
      e = ke("div");
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      this.h();
    },
    l(i) {
      e = we(i, "DIV", { class: !0 });
      var l = Ee(e);
      for (let s = 0; s < n.length; s += 1)
        n[s].l(l);
      l.forEach(X), this.h();
    },
    h() {
      ie(e, "class", t = `menu-popup ${/*component_meta*/
      r[34].length - 1 === /*i*/
      r[77] ? "last-item" : ""}`);
    },
    m(i, l) {
      Se(i, e, l);
      for (let s = 0; s < n.length; s += 1)
        n[s] && n[s].m(e, null);
    },
    p(i, l) {
      if (l[0] & /*menu_choices_style, menu_choices*/
      6291456 | l[1] & /*handle_menu_click*/
      8192) {
        a = D0(
          /*menu_choices*/
          i[21]
        );
        let s;
        for (s = 0; s < a.length; s += 1) {
          const o = di(i, a, s);
          n[s] ? n[s].p(o, l) : (n[s] = Ai(o), n[s].c(), n[s].m(e, null));
        }
        for (; s < n.length; s += 1)
          n[s].d(1);
        n.length = a.length;
      }
      l[1] & /*component_meta*/
      8 && t !== (t = `menu-popup ${/*component_meta*/
      i[34].length - 1 === /*i*/
      i[77] ? "last-item" : ""}`) && ie(e, "class", t);
    },
    d(i) {
      i && X(e), Nt(n, i);
    }
  };
}
function Ai(r) {
  let e, t = (
    /*choice*/
    r[79] + ""
  ), a, n, i, l, s;
  function o(...m) {
    return (
      /*click_handler_4*/
      r[62](
        /*i*/
        r[77],
        /*choice*/
        r[79],
        ...m
      )
    );
  }
  return {
    c() {
      e = ke("button"), a = ht(t), n = o0(), this.h();
    },
    l(m) {
      e = we(m, "BUTTON", { class: !0, style: !0 });
      var f = Ee(e);
      a = ct(f, t), n = u0(f), f.forEach(X), this.h();
    },
    h() {
      ie(e, "class", "menu-item"), ie(e, "style", i = `
                        background-color: ${/*menu_choices_style*/
      r[22].bg_color};
                        color: ${/*menu_choices_style*/
      r[22].text_color};
                        background-image: linear-gradient(to right, ${/*menu_choices_style*/
      r[22].transform_color}, ${/*menu_choices_style*/
      r[22].transform_color});
                      `);
    },
    m(m, f) {
      Se(m, e, f), fe(e, a), fe(e, n), l || (s = q0(e, "click", o), l = !0);
    },
    p(m, f) {
      r = m, f[0] & /*menu_choices*/
      2097152 && t !== (t = /*choice*/
      r[79] + "") && Dt(a, t), f[0] & /*menu_choices_style*/
      4194304 && i !== (i = `
                        background-color: ${/*menu_choices_style*/
      r[22].bg_color};
                        color: ${/*menu_choices_style*/
      r[22].text_color};
                        background-image: linear-gradient(to right, ${/*menu_choices_style*/
      r[22].transform_color}, ${/*menu_choices_style*/
      r[22].transform_color});
                      `) && ie(e, "style", i);
    },
    d(m) {
      m && X(e), l = !1, s();
    }
  };
}
function Si(r) {
  var E;
  let e, t, a = "console.log(components)", n, i, l, s, o, m, f = D0(/*sample_row*/
  r[75]), p = [];
  for (let k = 0; k < f.length; k += 1)
    p[k] = ki(pi(r, f, k));
  const g = (k) => Fe(p[k], 1, 1, () => {
    p[k] = null;
  });
  let w = (
    /*menu_choices*/
    ((E = r[21]) == null ? void 0 : E.length) > 0 && Di(r)
  );
  function F() {
    return (
      /*mouseenter_handler_1*/
      r[63](
        /*i*/
        r[77]
      )
    );
  }
  return {
    c() {
      e = ke("tr"), t = ke("script"), t.textContent = a, n = o0();
      for (let k = 0; k < p.length; k += 1)
        p[k].c();
      i = o0(), w && w.c(), l = o0(), this.h();
    },
    l(k) {
      e = we(k, "TR", { class: !0 });
      var S = Ee(e);
      t = we(S, "SCRIPT", { "data-svelte-h": !0 }), Xa(t) !== "svelte-uk52s" && (t.textContent = a), n = u0(S);
      for (let y = 0; y < p.length; y += 1)
        p[y].l(S);
      i = u0(S), w && w.l(S), l = u0(S), S.forEach(X), this.h();
    },
    h() {
      ie(e, "class", "tr-body");
    },
    m(k, S) {
      Se(k, e, S), fe(e, t), fe(e, n);
      for (let y = 0; y < p.length; y += 1)
        p[y] && p[y].m(e, null);
      fe(e, i), w && w.m(e, null), fe(e, l), s = !0, o || (m = [
        q0(e, "mouseenter", F),
        q0(
          e,
          "mouseleave",
          /*mouseleave_handler_1*/
          r[64]
        )
      ], o = !0);
    },
    p(k, S) {
      var y;
      if (r = k, S[0] & /*data_aligns, components, page, samples_per_page, selected_samples, column_headers, external_index, gradio, component_props, root*/
      369296156 | S[1] & /*isProcessingBatchSelection, isRowSelected, handleCheckboxChange, component_meta, samples_dir, current_hover*/
      4299) {
        f = D0(/*sample_row*/
        r[75]);
        let D;
        for (D = 0; D < f.length; D += 1) {
          const _ = pi(r, f, D);
          p[D] ? (p[D].p(_, S), de(p[D], 1)) : (p[D] = ki(_), p[D].c(), de(p[D], 1), p[D].m(e, i));
        }
        for (B0(), D = f.length; D < p.length; D += 1)
          g(D);
        M0();
      }
      /*menu_choices*/
      ((y = r[21]) == null ? void 0 : y.length) > 0 ? w ? w.p(r, S) : (w = Di(r), w.c(), w.m(e, l)) : w && (w.d(1), w = null);
    },
    i(k) {
      if (!s) {
        for (let S = 0; S < f.length; S += 1)
          de(p[S]);
        s = !0;
      }
    },
    o(k) {
      p = p.filter(Boolean);
      for (let S = 0; S < p.length; S += 1)
        Fe(p[S]);
      s = !1;
    },
    d(k) {
      k && X(e), Nt(p, k), w && w.d(), o = !1, Ol(m);
    }
  };
}
function Fi(r) {
  let e, t, a, n, i, l, s, o;
  const m = [Ko, Zo], f = [];
  function p(F, E) {
    return E[0] & /*component_map, components*/
    40 | E[1] & /*component_meta*/
    8 && (t = null), /*sample_labels*/
    F[11] ? 0 : (t == null && (t = !!/*component_meta*/
    (F[34].length && /*component_map*/
    F[5].get(
      /*components*/
      F[3][0]
    ))), t ? 1 : -1);
  }
  ~(a = p(r, [-1, -1, -1])) && (n = f[a] = m[a](r));
  function g() {
    return (
      /*click_handler*/
      r[54](
        /*i*/
        r[77],
        /*sample_row*/
        r[75]
      )
    );
  }
  function w() {
    return (
      /*mouseenter_handler*/
      r[55](
        /*i*/
        r[77]
      )
    );
  }
  return {
    c() {
      e = ke("button"), n && n.c(), i = o0(), this.h();
    },
    l(F) {
      e = we(F, "BUTTON", { class: !0 });
      var E = Ee(e);
      n && n.l(E), i = u0(E), E.forEach(X), this.h();
    },
    h() {
      ie(e, "class", "gallery-item");
    },
    m(F, E) {
      Se(F, e, E), ~a && f[a].m(e, null), fe(e, i), l = !0, s || (o = [
        q0(e, "click", g),
        q0(e, "mouseenter", w),
        q0(
          e,
          "mouseleave",
          /*mouseleave_handler*/
          r[56]
        )
      ], s = !0);
    },
    p(F, E) {
      r = F;
      let k = a;
      a = p(r, E), a === k ? ~a && f[a].p(r, E) : (n && (B0(), Fe(f[k], 1, 1, () => {
        f[k] = null;
      }), M0()), ~a ? (n = f[a], n ? n.p(r, E) : (n = f[a] = m[a](r), n.c()), de(n, 1), n.m(e, i)) : n = null);
    },
    i(F) {
      l || (de(n), l = !0);
    },
    o(F) {
      Fe(n), l = !1;
    },
    d(F) {
      F && X(e), ~a && f[a].d(), s = !1, Ol(o);
    }
  };
}
function Zo(r) {
  let e, t, a;
  const n = [
    /*component_props*/
    r[4][0],
    { value: (
      /*sample_row*/
      r[75][0]
    ) },
    { samples_dir: (
      /*samples_dir*/
      r[38]
    ) },
    { type: "gallery" },
    {
      selected: (
        /*current_hover*/
        r[32] === /*i*/
        r[77]
      )
    },
    { index: (
      /*i*/
      r[77]
    ) },
    { root: (
      /*root*/
      r[16]
    ) }
  ];
  var i = (
    /*component_meta*/
    r[34][0][0].component
  );
  function l(s, o) {
    let m = {};
    for (let f = 0; f < n.length; f += 1)
      m = Nr(m, n[f]);
    return o !== void 0 && o[0] & /*component_props, selected_samples, root*/
    268501008 | o[1] & /*samples_dir, current_hover*/
    130 && (m = Nr(m, Or(n, [
      o[0] & /*component_props*/
      16 && Lr(
        /*component_props*/
        s[4][0]
      ),
      o[0] & /*selected_samples*/
      268435456 && { value: (
        /*sample_row*/
        s[75][0]
      ) },
      o[1] & /*samples_dir*/
      128 && { samples_dir: (
        /*samples_dir*/
        s[38]
      ) },
      n[3],
      o[1] & /*current_hover*/
      2 && {
        selected: (
          /*current_hover*/
          s[32] === /*i*/
          s[77]
        )
      },
      n[5],
      o[0] & /*root*/
      65536 && { root: (
        /*root*/
        s[16]
      ) }
    ]))), { props: m };
  }
  return i && (e = Ir(i, l(r))), {
    c() {
      e && lt(e.$$.fragment), t = S0();
    },
    l(s) {
      e && Ot(e.$$.fragment, s), t = S0();
    },
    m(s, o) {
      e && ut(e, s, o), Se(s, t, o), a = !0;
    },
    p(s, o) {
      if (o[1] & /*component_meta*/
      8 && i !== (i = /*component_meta*/
      s[34][0][0].component)) {
        if (e) {
          B0();
          const m = e;
          Fe(m.$$.fragment, 1, 0, () => {
            st(m, 1);
          }), M0();
        }
        i ? (e = Ir(i, l(s, o)), lt(e.$$.fragment), de(e.$$.fragment, 1), ut(e, t.parentNode, t)) : e = null;
      } else if (i) {
        const m = o[0] & /*component_props, selected_samples, root*/
        268501008 | o[1] & /*samples_dir, current_hover*/
        130 ? Or(n, [
          o[0] & /*component_props*/
          16 && Lr(
            /*component_props*/
            s[4][0]
          ),
          o[0] & /*selected_samples*/
          268435456 && { value: (
            /*sample_row*/
            s[75][0]
          ) },
          o[1] & /*samples_dir*/
          128 && { samples_dir: (
            /*samples_dir*/
            s[38]
          ) },
          n[3],
          o[1] & /*current_hover*/
          2 && {
            selected: (
              /*current_hover*/
              s[32] === /*i*/
              s[77]
            )
          },
          n[5],
          o[0] & /*root*/
          65536 && { root: (
            /*root*/
            s[16]
          ) }
        ]) : {};
        e.$set(m);
      }
    },
    i(s) {
      a || (e && de(e.$$.fragment, s), a = !0);
    },
    o(s) {
      e && Fe(e.$$.fragment, s), a = !1;
    },
    d(s) {
      s && X(t), e && st(e, s);
    }
  };
}
function Ko(r) {
  let e, t;
  return e = new ko({
    props: {
      value: (
        /*sample_row*/
        r[75][0]
      ),
      selected: (
        /*current_hover*/
        r[32] === /*i*/
        r[77]
      ),
      type: "gallery"
    }
  }), {
    c() {
      lt(e.$$.fragment);
    },
    l(a) {
      Ot(e.$$.fragment, a);
    },
    m(a, n) {
      ut(e, a, n), t = !0;
    },
    p(a, n) {
      const i = {};
      n[0] & /*selected_samples*/
      268435456 && (i.value = /*sample_row*/
      a[75][0]), n[1] & /*current_hover*/
      2 && (i.selected = /*current_hover*/
      a[32] === /*i*/
      a[77]), e.$set(i);
    },
    i(a) {
      t || (de(e.$$.fragment, a), t = !0);
    },
    o(a) {
      Fe(e.$$.fragment, a), t = !1;
    },
    d(a) {
      st(e, a);
    }
  };
}
function _i(r) {
  let e, t, a = (
    /*sample_row*/
    r[75][0] && Fi(r)
  );
  return {
    c() {
      a && a.c(), e = S0();
    },
    l(n) {
      a && a.l(n), e = S0();
    },
    m(n, i) {
      a && a.m(n, i), Se(n, e, i), t = !0;
    },
    p(n, i) {
      /*sample_row*/
      n[75][0] ? a ? (a.p(n, i), i[0] & /*selected_samples*/
      268435456 && de(a, 1)) : (a = Fi(n), a.c(), de(a, 1), a.m(e.parentNode, e)) : a && (B0(), Fe(a, 1, 1, () => {
        a = null;
      }), M0());
    },
    i(n) {
      t || (de(a), t = !0);
    },
    o(n) {
      Fe(a), t = !1;
    },
    d(n) {
      n && X(e), a && a.d(n);
    }
  };
}
function Ei(r) {
  let e, t, a = D0(
    /*visible_pages*/
    r[29]
  ), n = [];
  for (let i = 0; i < a.length; i += 1)
    n[i] = Ti(mi(r, a, i));
  return {
    c() {
      e = ke("div"), t = ht(`Pages:
      `);
      for (let i = 0; i < n.length; i += 1)
        n[i].c();
      this.h();
    },
    l(i) {
      e = we(i, "DIV", { class: !0 });
      var l = Ee(e);
      t = ct(l, `Pages:
      `);
      for (let s = 0; s < n.length; s += 1)
        n[s].l(l);
      l.forEach(X), this.h();
    },
    h() {
      ie(e, "class", "paginate");
    },
    m(i, l) {
      Se(i, e, l), fe(e, t);
      for (let s = 0; s < n.length; s += 1)
        n[s] && n[s].m(e, null);
    },
    p(i, l) {
      if (l[0] & /*visible_pages, page*/
      603979776) {
        a = D0(
          /*visible_pages*/
          i[29]
        );
        let s;
        for (s = 0; s < a.length; s += 1) {
          const o = mi(i, a, s);
          n[s] ? n[s].p(o, l) : (n[s] = Ti(o), n[s].c(), n[s].m(e, null));
        }
        for (; s < n.length; s += 1)
          n[s].d(1);
        n.length = a.length;
      }
    },
    d(i) {
      i && X(e), Nt(n, i);
    }
  };
}
function Qo(r) {
  let e, t = (
    /*visible_page*/
    r[72] + 1 + ""
  ), a, n, i, l;
  function s() {
    return (
      /*click_handler_5*/
      r[65](
        /*visible_page*/
        r[72]
      )
    );
  }
  return {
    c() {
      e = ke("button"), a = ht(t), n = o0(), this.h();
    },
    l(o) {
      e = we(o, "BUTTON", {});
      var m = Ee(e);
      a = ct(m, t), n = u0(m), m.forEach(X), this.h();
    },
    h() {
      hi(
        e,
        "current-page",
        /*page*/
        r[26] === /*visible_page*/
        r[72]
      );
    },
    m(o, m) {
      Se(o, e, m), fe(e, a), fe(e, n), i || (l = q0(e, "click", s), i = !0);
    },
    p(o, m) {
      r = o, m[0] & /*visible_pages*/
      536870912 && t !== (t = /*visible_page*/
      r[72] + 1 + "") && Dt(a, t), m[0] & /*page, visible_pages*/
      603979776 && hi(
        e,
        "current-page",
        /*page*/
        r[26] === /*visible_page*/
        r[72]
      );
    },
    d(o) {
      o && X(e), i = !1, l();
    }
  };
}
function Jo(r) {
  let e, t = "...";
  return {
    c() {
      e = ke("div"), e.textContent = t;
    },
    l(a) {
      e = we(a, "DIV", { "data-svelte-h": !0 }), Xa(e) !== "svelte-12rhcfw" && (e.textContent = t);
    },
    m(a, n) {
      Se(a, e, n);
    },
    p: bt,
    d(a) {
      a && X(e);
    }
  };
}
function Ti(r) {
  let e;
  function t(i, l) {
    return (
      /*visible_page*/
      i[72] === -1 ? Jo : Qo
    );
  }
  let a = t(r), n = a(r);
  return {
    c() {
      n.c(), e = S0();
    },
    l(i) {
      n.l(i), e = S0();
    },
    m(i, l) {
      n.m(i, l), Se(i, e, l);
    },
    p(i, l) {
      a === (a = t(i)) && n ? n.p(i, l) : (n.d(1), n = a(i), n && (n.c(), n.m(e.parentNode, e)));
    },
    d(i) {
      i && X(e), n.d(i);
    }
  };
}
function $o(r) {
  let e, t, a, n, i, l, s, o, m, f, p;
  const g = [Uo, Ho], w = [];
  function F(k, S) {
    return (
      /*gallery*/
      k[35] ? 0 : 1
    );
  }
  s = F(r), o = w[s] = g[s](r);
  let E = (
    /*paginate*/
    r[27] && Ei(r)
  );
  return {
    c() {
      e = ke("div"), t = ci("svg"), a = ci("path"), n = o0(), i = ht(
        /*label*/
        r[6]
      ), l = o0(), o.c(), m = o0(), E && E.c(), f = S0(), this.h();
    },
    l(k) {
      e = we(k, "DIV", { class: !0 });
      var S = Ee(e);
      t = ui(S, "svg", {
        xmlns: !0,
        "xmlns:xlink": !0,
        "aria-hidden": !0,
        role: !0,
        width: !0,
        height: !0,
        preserveAspectRatio: !0,
        viewBox: !0
      });
      var y = Ee(t);
      a = ui(y, "path", { fill: !0, d: !0 }), Ee(a).forEach(X), y.forEach(X), n = u0(S), i = ct(
        S,
        /*label*/
        r[6]
      ), S.forEach(X), l = u0(k), o.l(k), m = u0(k), E && E.l(k), f = S0(), this.h();
    },
    h() {
      ie(a, "fill", "currentColor"), ie(a, "d", "M10 6h18v2H10zm0 18h18v2H10zm0-9h18v2H10zm-6 0h2v2H4zm0-9h2v2H4zm0 18h2v2H4z"), ie(t, "xmlns", "http://www.w3.org/2000/svg"), ie(t, "xmlns:xlink", "http://www.w3.org/1999/xlink"), ie(t, "aria-hidden", "true"), ie(t, "role", "img"), ie(t, "width", "1em"), ie(t, "height", "1em"), ie(t, "preserveAspectRatio", "xMidYMid meet"), ie(t, "viewBox", "0 0 32 32"), ie(e, "class", "label");
    },
    m(k, S) {
      Se(k, e, S), fe(e, t), fe(t, a), fe(e, n), fe(e, i), Se(k, l, S), w[s].m(k, S), Se(k, m, S), E && E.m(k, S), Se(k, f, S), p = !0;
    },
    p(k, S) {
      (!p || S[0] & /*label*/
      64) && Dt(
        i,
        /*label*/
        k[6]
      );
      let y = s;
      s = F(k), s === y ? w[s].p(k, S) : (B0(), Fe(w[y], 1, 1, () => {
        w[y] = null;
      }), M0(), o = w[s], o ? o.p(k, S) : (o = w[s] = g[s](k), o.c()), de(o, 1), o.m(m.parentNode, m)), /*paginate*/
      k[27] ? E ? E.p(k, S) : (E = Ei(k), E.c(), E.m(f.parentNode, f)) : E && (E.d(1), E = null);
    },
    i(k) {
      p || (de(o), p = !0);
    },
    o(k) {
      Fe(o), p = !1;
    },
    d(k) {
      k && (X(e), X(l), X(m), X(f)), w[s].d(k), E && E.d(k);
    }
  };
}
function e4(r) {
  let e, t;
  return e = new ss({
    props: {
      visible: (
        /*visible*/
        r[14]
      ),
      padding: !1,
      elem_id: (
        /*elem_id*/
        r[12]
      ),
      elem_classes: (
        /*elem_classes*/
        r[13]
      ),
      scale: (
        /*scale*/
        r[18]
      ),
      min_width: (
        /*min_width*/
        r[19]
      ),
      allow_overflow: !1,
      container: !1,
      $$slots: { default: [$o] },
      $$scope: { ctx: r }
    }
  }), {
    c() {
      lt(e.$$.fragment);
    },
    l(a) {
      Ot(e.$$.fragment, a);
    },
    m(a, n) {
      ut(e, a, n), t = !0;
    },
    p(a, n) {
      const i = {};
      n[0] & /*visible*/
      16384 && (i.visible = /*visible*/
      a[14]), n[0] & /*elem_id*/
      4096 && (i.elem_id = /*elem_id*/
      a[12]), n[0] & /*elem_classes*/
      8192 && (i.elem_classes = /*elem_classes*/
      a[13]), n[0] & /*scale*/
      262144 && (i.scale = /*scale*/
      a[18]), n[0] & /*min_width*/
      524288 && (i.min_width = /*min_width*/
      a[19]), n[0] & /*visible_pages, page, paginate, selected_samples, samples_per_page, gradio, value, sample_labels, component_props, root, component_map, components, menu_choices, menu_choices_style, menu_icon, data_aligns, column_headers, external_index, column_widths, header_aligns, headerChecked, sort_order, sort_column, header_sort, manual_sort, label*/
      2146668543 | n[1] & /*current_hover, component_meta, gallery, active_menu, default_menu_icon, isProcessingBatchSelection*/
      63 | n[2] & /*$$scope*/
      67108864 && (i.$$scope = { dirty: n, ctx: a }), e.$set(i);
    },
    i(a) {
      t || (de(e.$$.fragment, a), t = !0);
    },
    o(a) {
      Fe(e.$$.fragment, a), t = !1;
    },
    d(a) {
      st(e, a);
    }
  };
}
function Ar(r, e, t) {
  const a = e.reduce(
    (n, i, l) => {
      const s = r[l];
      return n[i] = typeof s == "object" && "value" in s ? s.value : s, n;
    },
    {}
  );
  return t !== void 0 && (a.external_index = t), a;
}
function t4(r) {
  return r.map((e) => e == null ? null : typeof e == "object" && "value" in e ? e.value : e);
}
function Ci(r) {
  return typeof r == "object" && "value" in r ? r.value : r;
}
function r4(r, e, t) {
  let a, n, i;
  var l = this && this.__awaiter || function(B, K, ee, oe) {
    function pe(ne) {
      return ne instanceof ee ? ne : new ee(function(Ne) {
        Ne(ne);
      });
    }
    return new (ee || (ee = Promise))(function(ne, Ne) {
      function _t(y0) {
        try {
          V0(oe.next(y0));
        } catch (Et) {
          Ne(Et);
        }
      }
      function z0(y0) {
        try {
          V0(oe.throw(y0));
        } catch (Et) {
          Ne(Et);
        }
      }
      function V0(y0) {
        y0.done ? ne(y0.value) : pe(y0.value).then(_t, z0);
      }
      V0((oe = oe.apply(B, K || [])).next());
    });
  };
  let { components: s } = e, { component_props: o } = e, { component_map: m = /* @__PURE__ */ new Map() } = e, f = !1, p = /* @__PURE__ */ new Map();
  function g(B, K) {
    const ee = $ ? $[K] : K;
    return `${JSON.stringify(B)}_${ee}`;
  }
  function w(B, K) {
    return p.get(g(B, K)) || !1;
  }
  let { label: F = "Examples" } = e, { column_widths: E = null } = e, { column_headers: k } = e, { data_aligns: S = [] } = e, { header_aligns: y = [] } = e, { default_sort: D = null } = e, { samples: _ = null } = e, C = null, { sample_labels: M = null } = e, { elem_id: R = "" } = e, { elem_classes: U = [] } = e, { visible: I = !0 } = e, { value: O = null } = e, { root: J } = e, { proxy_url: le } = e, { samples_per_page: se = 10 } = e, { scale: Te = null } = e, { min_width: Ue = void 0 } = e, { menu_icon: Ze = null } = e, { menu_choices: a0 = [] } = e, { menu_choices_style: ge = {
    bg_color: "white",
    text_color: "black",
    transform_color: "fff3eb"
  } } = e, { header_sort: Le = !1 } = e, { sort_column: ve = null } = e, { sort_order: te = null } = e, { manual_sort: me = !1 } = e, { external_index: $ = null } = e, Me = null, re = null, { per_load: Ge = 0 } = e, { gradio: xe } = e, Ke = le ? `/proxy=${le}file=` : `${J}/file=`, ce = 0, Ve = !1, c0 = _ ? _.length > se : !1, Re, n0, Pe = [], F0 = -1, h0 = null;
  function i0(B) {
    t(32, F0 = B);
  }
  function m0() {
    t(32, F0 = -1), setTimeout(
      () => {
        F0 !== h0 && t(33, h0 = null);
      },
      100
    );
  }
  function f0(B) {
    !Le && !me || (!Me && _ && (t(50, Me = [..._]), $ && t(51, re = [...$])), ve === B ? t(1, te = te === "ascending" ? "descending" : "ascending") : (t(0, ve = B), t(1, te = "ascending")), xe.dispatch("select", {
      index: ve,
      value: { column: ve, order: te }
    }));
  }
  function qt(B) {
    if (!Ve) {
      t(31, Ve = !0);
      try {
        const K = Re;
        t(30, f = B), K.forEach((ee, oe) => {
          const pe = oe + ce * se, ne = g(ee, pe);
          B ? p.set(ne, !0) : p.delete(ne);
        }), p = new Map(p), K.forEach((ee, oe) => {
          const pe = oe + ce * se, ne = s.findIndex((Ne) => Ne === "checkbox");
          if (ne >= 0) {
            const Ne = Ar(ee, k, $ ? $[pe] : void 0);
            xe.dispatch("select", {
              index: [pe, ne],
              value: { cell_value: B },
              row_value: Ne
            });
          }
        });
      } finally {
        setTimeout(
          () => {
            t(31, Ve = !1);
          },
          100
        );
      }
    }
  }
  function xt(B, K, ee, oe) {
    if (Ve) return;
    const pe = K + ce * se, ne = g(B, pe);
    ee ? p.set(ne, !0) : p.delete(ne), p = new Map(p);
    const Ne = Re.every((z0, V0) => {
      const y0 = V0 + ce * se;
      return w(z0, y0);
    });
    t(30, f = Ne);
    const _t = s.findIndex((z0) => z0 === "checkbox");
    if (_t >= 0) {
      const z0 = Ar(B, k, $ ? $[pe] : void 0);
      xe.dispatch("select", {
        index: [pe, _t],
        value: { cell_value: ee },
        row_value: z0
      });
    }
  }
  function lr(B, K, ee) {
    ee.stopPropagation();
    const oe = B + ce * se, pe = Ar(i[oe], k, $ ? $[oe] : void 0);
    xe.dispatch("select", {
      index: oe,
      value: { menu_choice: K },
      row_value: pe
    }), t(33, h0 = null);
  }
  let At = [];
  function mt(B) {
    return l(this, void 0, void 0, function* () {
      B && t(34, At = yield Promise.all(B.map((K) => l(this, void 0, void 0, function* () {
        return yield Promise.all(K.map((ee, oe) => l(this, void 0, void 0, function* () {
          var pe;
          const ne = s[oe] ? (pe = yield m.get(s[oe])) === null || pe === void 0 ? void 0 : pe.default : null;
          return { value: ee, component: ne };
        })));
      }))));
    });
  }
  const J0 = (B, K) => {
    const ee = B + ce * se, oe = t4(K);
    xe.dispatch("click", ee), xe.dispatch("select", {
      index: [ee, B],
      value: O,
      row_value: oe
    });
  }, $0 = (B) => i0(B), sr = () => m0(), ur = () => qt(!f), or = (B) => f0(B), Pt = (B, K, ee, oe) => xt(B, K, oe.detail, k[ee]), cr = (B, K, ee, oe) => {
    if (Ve) return;
    const pe = B + ce * se, ne = Ar(K, k, $ ? $[pe] : void 0);
    if (s[ee] === "checkbox") {
      const Ne = !w(K, pe);
      xt(K, B, Ne, k[ee]);
    } else
      xe.dispatch("click", pe), xe.dispatch("select", {
        index: [pe, ee],
        value: { cell_value: oe },
        row_value: ne
      });
  }, St = (B) => t(33, h0 = h0 === B ? null : B), Ft = (B, K, ee) => lr(B, K, ee), _0 = (B) => i0(B), et = () => m0(), Ht = (B) => t(26, ce = B);
  return r.$$set = (B) => {
    "components" in B && t(3, s = B.components), "component_props" in B && t(4, o = B.component_props), "component_map" in B && t(5, m = B.component_map), "label" in B && t(6, F = B.label), "column_widths" in B && t(7, E = B.column_widths), "column_headers" in B && t(8, k = B.column_headers), "data_aligns" in B && t(9, S = B.data_aligns), "header_aligns" in B && t(10, y = B.header_aligns), "default_sort" in B && t(47, D = B.default_sort), "samples" in B && t(45, _ = B.samples), "sample_labels" in B && t(11, M = B.sample_labels), "elem_id" in B && t(12, R = B.elem_id), "elem_classes" in B && t(13, U = B.elem_classes), "visible" in B && t(14, I = B.visible), "value" in B && t(15, O = B.value), "root" in B && t(16, J = B.root), "proxy_url" in B && t(48, le = B.proxy_url), "samples_per_page" in B && t(17, se = B.samples_per_page), "scale" in B && t(18, Te = B.scale), "min_width" in B && t(19, Ue = B.min_width), "menu_icon" in B && t(20, Ze = B.menu_icon), "menu_choices" in B && t(21, a0 = B.menu_choices), "menu_choices_style" in B && t(22, ge = B.menu_choices_style), "header_sort" in B && t(23, Le = B.header_sort), "sort_column" in B && t(0, ve = B.sort_column), "sort_order" in B && t(1, te = B.sort_order), "manual_sort" in B && t(24, me = B.manual_sort), "external_index" in B && t(2, $ = B.external_index), "per_load" in B && t(46, Ge = B.per_load), "gradio" in B && t(25, xe = B.gradio);
  }, r.$$.update = () => {
    if (r.$$.dirty[0] & /*components, sample_labels*/
    2056 && t(35, n = s.length < 2 || M !== null), r.$$.dirty[0] & /*column_headers*/
    256 | r.$$.dirty[1] & /*per_load, default_sort*/
    98304 && Ge <= 1 && D !== null && (t(1, te = D.order === "desc" ? "ascending" : "descending"), t(46, Ge += 1), f0(k.indexOf(D.column))), r.$$.dirty[0] & /*sample_labels, samples_per_page, paginate, page, visible_pages*/
    738330624 | r.$$.dirty[1] & /*samples, old_samples, page_count*/
    2375680 && (M ? t(45, _ = M.map((B) => [B])) : _ || t(45, _ = []), _ !== C && (t(26, ce = 0), t(49, C = _)), t(27, c0 = _.length > se), c0 ? (t(29, Pe = []), t(28, Re = _.slice(ce * se, (ce + 1) * se)), t(52, n0 = Math.ceil(_.length / se)), [0, ce, n0 - 1].forEach((B) => {
      for (let K = B - 2; K <= B + 2; K++)
        K >= 0 && K < n0 && !Pe.includes(K) && (Pe.length > 0 && K - Pe[Pe.length - 1] > 1 && Pe.push(-1), Pe.push(K));
    })) : t(28, Re = _.slice())), r.$$.dirty[1] & /*samples*/
    16384 && t(53, i = _ ? [..._] : []), r.$$.dirty[0] & /*header_sort, sort_column, sort_order, external_index, page, samples_per_page*/
    75628551 | r.$$.dirty[1] & /*samples, original_samples, original_external_index, sortedSamples*/
    5783552)
      if (_ && Le && ve !== null && te !== null && Me) {
        const B = Me.map((K, ee) => ({
          data: K,
          originalIndex: ee,
          externalIndex: re ? re[ee] : null,
          identifier: g(K, ee)
        }));
        B.sort((K, ee) => {
          const oe = Ci(K.data[ve]), pe = Ci(ee.data[ve]);
          if (typeof oe == "number" && typeof pe == "number")
            return te === "ascending" ? oe - pe : pe - oe;
          const ne = String(oe ?? "").toLowerCase(), Ne = String(pe ?? "").toLowerCase();
          return te === "ascending" ? ne.localeCompare(Ne) : Ne.localeCompare(ne);
        }), t(53, i = B.map((K) => K.data)), $ && t(2, $ = B.map((K) => K.externalIndex)), t(28, Re = i.slice(ce * se, (ce + 1) * se));
      } else
        Me && (t(53, i = [...Me]), re && t(2, $ = [...re])), t(28, Re = (_ == null ? void 0 : _.slice(ce * se, (ce + 1) * se)) || []);
    if (r.$$.dirty[0] & /*selected_samples, page, samples_per_page*/
    335675392 && Re) {
      const B = Re.every((K, ee) => {
        const oe = ee + ce * se;
        return w(K, oe);
      });
      (B || !Re.some((K, ee) => {
        const oe = ee + ce * se;
        return w(K, oe);
      })) && t(30, f = B);
    }
    r.$$.dirty[0] & /*component_map, page, samples_per_page*/
    67239968 | r.$$.dirty[1] & /*sortedSamples*/
    4194304 && mt(i.slice(ce * se, (ce + 1) * se)), r.$$.dirty[0] & /*selected_samples, external_index*/
    268435460 | r.$$.dirty[1] & /*original_external_index*/
    1048576 && (console.log("selected_samples", Re), console.log("origin external_index", re), console.log("external_index", $));
  }, t(36, a = "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.8.1/icons/three-dots-vertical.svg"), [
    ve,
    te,
    $,
    s,
    o,
    m,
    F,
    E,
    k,
    S,
    y,
    M,
    R,
    U,
    I,
    O,
    J,
    se,
    Te,
    Ue,
    Ze,
    a0,
    ge,
    Le,
    me,
    xe,
    ce,
    c0,
    Re,
    Pe,
    f,
    Ve,
    F0,
    h0,
    At,
    n,
    a,
    w,
    Ke,
    i0,
    m0,
    f0,
    qt,
    xt,
    lr,
    _,
    Ge,
    D,
    le,
    C,
    Me,
    re,
    n0,
    i,
    J0,
    $0,
    sr,
    ur,
    or,
    Pt,
    cr,
    St,
    Ft,
    _0,
    et,
    Ht
  ];
}
class n4 extends Io {
  constructor(e) {
    super(), Oo(
      this,
      e,
      r4,
      e4,
      qo,
      {
        components: 3,
        component_props: 4,
        component_map: 5,
        label: 6,
        column_widths: 7,
        column_headers: 8,
        data_aligns: 9,
        header_aligns: 10,
        default_sort: 47,
        samples: 45,
        sample_labels: 11,
        elem_id: 12,
        elem_classes: 13,
        visible: 14,
        value: 15,
        root: 16,
        proxy_url: 48,
        samples_per_page: 17,
        scale: 18,
        min_width: 19,
        menu_icon: 20,
        menu_choices: 21,
        menu_choices_style: 22,
        header_sort: 23,
        sort_column: 0,
        sort_order: 1,
        manual_sort: 24,
        external_index: 2,
        per_load: 46,
        gradio: 25
      },
      null,
      [-1, -1, -1]
    );
  }
}
export {
  n4 as default
};
